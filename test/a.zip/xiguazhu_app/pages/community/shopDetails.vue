<template>
	<view class="shopDetails-wrapper wrapperLayer">
		<titleBar :titleText='"店铺详情"'></titleBar>
		<image class="page-banner-pic" :src="pageInfo.pic"  mode="aspectFill"></image>
		<view class="page-content colCen borderBox">
			<view class="shoptitle">
				{{pageInfo.shopName}}
			</view>
			<view class="shopDesc">
				{{pageInfo.businessDistrict}}丨{{pageInfo.typeStr}}丨人均￥{{pageInfo.consumptionPerPerson}}
			</view>
			
			<view class="label-bar rowCenCen">
				<view class="label-options rowCen" v-if="pageInfo.authentication==1">
					认证商家
				</view>
			</view>
			
			<scroll-view class="shopimgs-container rowCenBet" scroll-x scroll-with-animation>
				<block v-for="(items,index) in imgList" :key="index">
					<image class="syn-pic" :src="items" mode="aspectFill"></image>
				</block>
			</scroll-view>
			
			<!-- <view class="backHome">
				<view class="back-btn rowCenCen">
					<image class="back-icon" src="../../static/images/community/home.png" mode=""></image>
					<view class="backTxt">
						去主页
					</view>
				</view>
			</view> -->
			
			<view class="working-time-bar rowCenBet">
				<view class="left-info">
					<view class="title-bar rowCen">
						<view class="states-box">
							营业时间 丨
						</view>
						<view class="work-time-box">
							{{pageInfo.businessHours}}
						</view>
					</view>
					
					<view class="label-content rowCen">
						<view class="labels-grey rowCen">
							新店入住
						</view>
					</view>
				</view>
				
				<image class="right-icon" src="../../static/images/goods/arrow.png" mode=""></image>
			</view>
			
			
			<view class="address-bar-container rowCenBet">
				<view class="l-address">
					<view class="ads-name">
						{{pageInfo.detailedAddress}}
					</view>
					<view class="distance-info">
						距您{{pageInfo.distance}}km
					</view>
				</view>
				
				<view class="right-box rowCen">
					<image class="navigait" src="../../static/images/community/distance.png" mode="" @tap="daohang()"></image>
					<view class="shu">
					</view>
					<image class="navigait" src="../../static/images/community/call.png" mode="" @tap="callphone()"></image>
				</view>
			</view>
			
			<view class="bot-content">
				
			</view>
			
			<view class="fixed-bottombar rowSta borderBox">
				<view class="bar-content rowCenBet">
					<view class="left-icon rowCen">
						<view class="icon-items colCen">
							<image class="icon-pic" src="../../static/images/community/wallet.png" mode=""></image>
							<view class="icon-txt">
								买单
							</view>
						</view>
						<view class="icon-items colCen">
							<image class="icon-pic" src="../../static/images/community/sign.png" mode=""></image>
							<view class="icon-txt">
								到店打卡
							</view>
						</view>
					</view>
					
					<view class="right-btn rowCenCen">
						<view>预约/预定</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import Map from '../../utils/openMap.js'
	export default {
		data(){
			return{
				id:'',
				pageInfo:'',
				imgList:[]
			}
		},
		onLoad(options) {
			this.id = options.id
			this.initData()
		},
		methods:{
			initData(){
				this.$http.post('bbc/shop/shopDetail/'+this.id).then(res=>{
					console.log(res);
					this.pageInfo = res
					this.imgList = res.merchantDetails.split(',')
				})
			},
			daohang(){
				Map.openMap(this.pageInfo.latitude, this.pageInfo.longitude, '', 'bd09')
			},
			callphone(){
				uni.makePhoneCall({
				    phoneNumber: this.pageInfo.telephone //仅为示例
				});
			}
		}
	}
</script>

<style lang="scss">
	.shopDetails-wrapper{
		width: 100%;
		display: flex;
		flex-direction: column;
		align-items: center;
		.page-banner-pic{
			width: 100%;
			height: 400rpx;
		}
		
		.page-content{
			width: 100%;
			background-color: #FFFFFF;
			padding: 43rpx 26rpx;
			margin-top: -1;
			.shoptitle{
				font-size: 40rpx;
				font-weight: 500;
				color: #333333;
				margin-bottom: 30rpx;
			}
			.shopDesc{
				font-size: 24rpx;
				font-weight: 500;
				color: #333333;
				margin-bottom: 20rpx;
			}
			.label-bar{
				width: 100%;
				margin-bottom: 30rpx;
				.label-options{
					height: 30rpx;
					padding: 0 8rpx;
					background: #108687;
					border-radius: 4rpx;
					font-size: 20rpx;
					font-weight: 500;
					color: #FFFFFF;
					margin:0 5rpx;
				}
			}
			
			.shopimgs-container{
				margin-bottom: 10rpx;
				width: 100%;
				height: 180rpx;
				white-space: nowrap;
				.syn-pic{
					width: 220rpx;
					height: 180rpx;
					border-radius: 8rpx;
					margin-right: 20rpx;
				}
			}
			
			.backHome{
				width: 100%;
				padding: 30rpx 0;
				border-bottom: 1rpx solid #F7f7f7;
				.back-btn{
					width: 210rpx;
					height: 70rpx;
					background: #FFFFFF;
					border: 1rpx solid #666666;
					border-radius: 8rpx;
					.back-icon{
						width: 42rpx;
						height: 42rpx;
					}
					
					.backTxt{
						font-size: 30rpx;
						font-weight: 500;
						color: #333333;
						margin-left: 20rpx;
					}
				}
			}
			
			.working-time-bar{
				width: 100%;
				padding: 30rpx 0;
				border-bottom: 1rpx solid #F7f7f7;
				.left-info{
					.title-bar{
						margin-bottom: 20rpx;
						.states-box{
							font-size: 24rpx;
							font-weight: 500;
							color: #333333;
						}
						.work-time-box{
							font-size: 24rpx;
							font-weight: 500;
							color: #666666;
						}
					}
					.label-content{
						.labels-grey{
							height: 30rpx;
							padding: 0 6rpx;
							font-size: 22rpx;
							font-weight: 500;
							color: #666666;
							background: #F7F7F7;
							border-radius: 4rpx;
						}
					}
				}
				
				.right-icon{
					width: 14rpx;
					height: 24rpx;
				}
			}
			
			.address-bar-container{
				width: 100%;
				padding: 30rpx 0;
				border-bottom: 1rpx solid #F7f7f7;
				.l-address{
					.ads-name{
						font-size: 24rpx;
						font-weight: 500;
						color: #333333;
						width: 360rpx;
						white-space: nowrap;
						overflow: hidden;
						text-overflow: ellipsis;
					}
					.distance-info{
						font-size: 22rpx;
						font-weight: 500;
						color: #666666;
						margin-top: 20rpx;
					}
				}
				
				.right-box{
					.navigait{
						width: 42rpx;
						height: 42rpx;
					}
					.shu{
						width: 1rpx;
						height: 34rpx;
						background-color: #A8A8A8;
						margin: 0 28rpx;
					}
				}
			}
		}
		.bot-content{
			width: 100%;
			height: 120rpx;
			height: calc(120rpx + constant(safe-area-inset-bottom));
			height: env(120rpx + constant(safe-area-inset-bottom));
		}
		
		.fixed-bottombar{
			width: 100%;
			height: 100rpx;
			height: calc(100rpx + constant(safe-area-inset-bottom));
			height: env(100rpx + constant(safe-area-inset-bottom));
			position: fixed;
			bottom: 0;
			left: 0;
			background-color: #FFFFFF;
			padding: 0 26rpx;
			.bar-content{
				width: 100%;
				height: 100rpx;
				.left-icon{
					.icon-items{
						margin-right: 60rpx;
						.icon-pic{
							width: 36rpx;
							height: 32rpx;
						}
						.icon-txt{
							font-size: 22rpx;
							font-weight: 500;
							color: #666666;
							margin-top: 10rpx;
						}
					}
				}
				
				.right-btn{
					width: 344rpx;
					height: 82rpx;
					background: #FF002C;
					border-radius: 10rpx;
					font-size: 30rpx;
					font-weight: 500;
					color: #FFFFFF;
				}
			}
		}
	}
</style>
