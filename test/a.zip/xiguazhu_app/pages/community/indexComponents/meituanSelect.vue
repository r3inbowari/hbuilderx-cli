<template>
	<view class="meituanSelect-wrapper wrapperLayer borderBox">
		<view class="bottom-goods-list-area rowCenBet">
			<block v-for="(items,index) in list" :key="index">
				<view class="goods-items colCen" @tap="toMiniProgram(items)">
					<image class="goods-pic" :src="items.pictUrl" mode="aspectFill"></image>
					<view class="goodsTitle borderBox">
						{{items.title}}
					</view>
					<view class="priceContent rowEnd borderBox">
						<view class="rmb">
							￥
						</view>
						<view class="price-num">
							{{items.promotionPrice}}
						</view>
					</view>
				</view>
			</block>
		</view>

		<aLoadMore :status="loadstate" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
	</view>
</template>

<script>
	export default {
		props: {
			lcInfo: {
				type: Object,
				default: '',
			}
		},
		data() {
			return {
				list: [],
				pageNum: 1,
				loadstate: 'loading',
				canLoad: false
			}
		},
		created() {
			console.log(this.lcInfo);
			this.getList()
		},
		methods: {
			getList() {
				this.$http.post('mtyouxuan/getList', {
					deviceType: getApp().globalData.platform == 'android' ? (getApp().globalData.systemLevel < 10 ?
						'IMEI' : 'OAID') : 'IDFA',
					latitude: this.lcInfo.latitude,
					longitude: this.lcInfo.longitude,
					pageNO: 1,
					pageSize: 10
				}, 'application/json').then(res => {
					if (res.length < 10) {
						this.canLoad = false
						this.loadstate = 'nomore'
					} else {
						this.canLoad = true
						this.loadstate = 'loading'
						this.pageNum++
					}
					this.list = this.list.concat(res)
				})
			},

			getNextpage() {
				if (this.canLoad) {
					this.$http.post('mtyouxuan/getList', {
						deviceType: getApp().globalData.platform == 'android' ? (getApp().globalData.systemLevel <
							10 ?
							'IMEI' : 'OAID') : 'IDFA',
						latitude: this.lcInfo.latitude,
						longitude: this.lcInfo.longitude,
						pageNO: this.pageNum,
						pageSize: 10
					}, 'application/json').then(res => {
						console.log(res);
						if (res.length < 10) {
							this.canLoad = false
							this.loadstate = 'nomore'
						} else {
							this.canLoad = true
							this.loadstate = 'loading'
							this.pageNum++
						}
						this.list = this.list.concat(res)
					})
				}
			},

			toMiniProgram(item) {
				console.log(JSON.stringify(item));
				plus.share.getServices(function(res) {
					var sweixin = null;
					for (var i = 0; i < res.length; i++) {
						var t = res[i];
						if (t.id == 'weixin') {
							sweixin = t;
						}
					}
					if (sweixin) {
						sweixin.launchMiniProgram({
							id: 'gh_84b9766b95bc',
							type: 0, //0 正式 1 测试 2 体验  小程序的版本
							path: item.itemWXLinkUrl //这里你要跳的路径，可以传值
						});
					}
				}, function(res) {
					console.log(JSON.stringify(res));
				});
/* 				console.log(item);
				
				var isAppletJump =  getApp().globalData.appinfo.isAppletJump;
				//console.log("==========="+isAppletJump)
				if(true){
					plus.share.getServices(function(res) {
						var sweixin = null;
						for (var i = 0; i < res.length; i++) {
							var t = res[i];
							if (t.id == 'weixin') {
								sweixin = t;
							}
						}
						if (sweixin) {
							sweixin.launchMiniProgram({
								id: 'gh_84b9766b95bc',
								type: 0, //0 正式 1 测试 2 体验  小程序的版本
								path: item.itemWXLinkUrl //这里你要跳的路径，可以传值
							});
						}
					}, function(res) {
						console.log(JSON.stringify(res));
					});
				}else{
					
					plus.runtime.openURL(item.itemDeepLinkUrl, res => {
						//console.log(res);
						uni.navigateTo({
							url: '../webView/webView?url=' + item.itemMiddlePageLinkUrl
						})
					});
				} */
				
				
			}
		}
	}
</script>

<style lang="scss">
	.meituanSelect-wrapper {
		width: 750rpx;
		padding: 0 26rpx;
		margin-top: 20rpx;

		.bottom-goods-list-area {
			width: 100%;
			flex-wrap: wrap;

			.goods-items {
				width: 340rpx;
				background: #FFFFFF;
				border-radius: 16rpx;
				margin-bottom: 20rpx;

				.goods-pic {
					width: 340rpx;
					height: 340rpx;
					border-radius: 16rpx 16rpx 0rpx 0rpx;
				}

				.goodsTitle {
					width: 100%;
					padding: 0 10rpx;
					height: 70rpx;
					font-size: 26rpx;
					font-weight: 500;
					color: #333333;
					line-height: 34rpx;
					overflow: hidden;
					display: -webkit-box;
					-webkit-box-orient: vertical;
					-webkit-line-clamp: 2;
					margin: 15rpx 0rpx;
				}

				.priceContent {
					width: 100%;
					padding: 0 10rpx;
					font-size: 24rpx;
					font-weight: bold;
					color: #FF002C;
					line-height: 30rpx;
					margin-bottom: 15rpx;

					.price-num {
						font-size: 28rpx;
						line-height: 34rpx;
					}
				}
			}
		}
	}
</style>
