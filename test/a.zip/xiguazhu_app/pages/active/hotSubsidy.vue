<template>
	<view class="hotSubsidy-wrapper wrapperLayer">
		<view class="top-bacolor"></view>
		<view class="fixed-content colCen">
			<view class="topbar-container colCen">
				<view class="topbarbox"></view>
				<view class="headerNavigationbar rowCenBet borderBox">
					<view class="backIcon rowCenSta" @click="backUrl()">
						<image src="../../static/images/home/returnWhite.png" mode="aspectFill"></image>
					</view>
					<view class="pageTitle">
						爆款补贴
					</view>
					<view class="emptybox rowCenEnd">
					</view>
				</view>
			</view>

			<view class="classification-container rowCen">
				<scroll-view class="scroll-container" scroll-x scroll-with-animation>
					<view class="scrollList-box">
						<block v-for="(items,index) in classificationList" :key="index">
							<view class="clasItems" @tap="clkNav(items.jingtuituiId)">
								<view class="items-container colCenCen">
									<image class="iconbox" :src="items.icon" mode="aspectFill"></image>
									<view class="txt-box" :style="'color:' + (nowCurrent==items.jingtuituiId?'#FD042B':'')">
										{{items.name}}
									</view>
								</view>
							</view>
						</block>
					</view>
				</scroll-view>
			</view>
		</view>
		<view class="page-content colCen pd20">
			<view class="topbarbox"></view>
			<view class="goodsList-container colCen">
				<block v-for="(items,index) in goodsList">
					<view class="goods-items-container rowCen borderBox" @click="goDetail(items)">
						<view class="left-imagecontent defIcon">
							<image :src="items.mainPic" mode="aspectFill"></image>
						</view>

						<view class="right-goodsinfo-container colCenBet borderBox">
							<view class="top-content-box colCen">
								<view class="goodsnameinfo-content rowSta">
									<view class="typeIcon-content defIcon">
										<image src="@/static/images/goods/jdtips.png" mode="heightFix"></image>
									</view>
									<view class="tradename">
										{{items.dtitle}}
									</view>
								</view>

								<view class="desc-box">
									{{items.desc}}
								</view>
							</view>

							<view class="btm-content-box colCen">
								<view class="discounts-container rowCen borderBox">
									<view class="coupon-box rowCenCen">
										<view>
											{{items.couponPrice}}元券
										</view>
									</view>


									<view class="back-box rowCenCen">
										<view>
											返{{items.fanli}}元
										</view>
									</view>
								</view>

								<view class="price-saleNums-container rowEndBet">
									<view class="left-price-box rowEnd">
										<view class="nowpirce rowEnd">
											<view class="rmb">
												￥
											</view>
											<view class="num">
												{{items.actualPrice}}
											</view>
										</view>
										
										<s class="original-price">
											￥{{items.originalPrice}}
										</s>
									</view>
									
									<view class="saleNum-content">
										已售{{items.monthSales}}
									</view>
								</view>
							</view>
						</view>
					</view>
				</block>
				<aLoadMore :status="loadstate" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				nowCurrent:'',
				classificationList: [],
				goodsList: [],
				
				loadstate: 'nomore',
				pageCurrent: 1,
				canload: false
			}
		},
		onLoad() {
			this.getNav()
		},
		onReachBottom() {
			if(this.canload){
				this.getData()
			}
		},
		methods:{
			getNav() {
				this.$http.post('jd/getTopCatList').then(res => {
					console.log(res);
					this.classificationList = res
					this.nowCurrent = res[0].jingtuituiId
					this.getData()
				})
			},
			getData() {
				this.$http.post('jd/subsidyGoods', {
					goodsNewType: this.nowCurrent,
					num: 10,
					page: this.pageCurrent
				}, 'application/json').then(res => {
					uni.stopPullDownRefresh();
					console.log(res);
					if(res.length<10){
						this.canload = false
						this.loadstate = 'nomore'
					}else{
						this.canload = true
						this.loadstate = 'loading'
						this.pageCurrent++
					}
					this.goodsList = this.goodsList.concat(res)
				})
			},
			clkNav(idx){
				this.nowCurrent = idx
				this.pageCurrent = 1
				this.canload = false
				this.loadstate = 'loading'
				this.goodsList = []
				this.getData()
			},
			
			goDetail(info) {
				uni.navigateTo({
					url: '../goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(info))
				})
			},
			
			
			backUrl(){
				uni.navigateBack({
					delta:1
				})
			}
		},
		onPullDownRefresh() {
			this.pageCurrent = 1
			this.loadstate = 'loading'
			this.canload = false
			this.goodsList = []
			this.getData()
		}
	}
</script>

<style lang="scss">
	.hotSubsidy-wrapper {
		width: 100%;
		min-height: 100vh;

		.top-bacolor {
			width: 200%;
			height: 522rpx;
			border-bottom-left-radius: 50%;
			border-bottom-right-radius: 50%;
			background: linear-gradient(-59deg, #FD1E0D, #FD002F);
			position: fixed;
			left: -50%;
			top: 0;
		}

		.fixed-content {
			width: 100%;
			position: fixed;
			background: linear-gradient(-59deg, #FD1E0D, #FD002F);
			top: 0;
			z-index: 100;

			.topbar-container {
				width: 100%;

				.headerNavigationbar {
					width: 100%;
					height: 90rpx;
					padding: 0 32rpx;
					z-index: 10;

					.backIcon {
						width: 60rpx;
						height: 32rpx;
						z-index: 1;

						image {
							width: 17rpx;
							height: 32rpx;
						}
					}

					.pageTitle {
						font-size: 34rpx;
						font-weight: 500;
						color: #FFFFFF;
					}

					.emptybox {
						width: 60rpx;
						height: 32rpx;
					}
				}
			}

			.classification-container {
				width: 100%;
				height: 156rpx;
				z-index: 10;
				margin: 20rpx 0;
				padding: 0 20rpx;

				.scroll-container {
					width: 100%;
					height: 100%;
					background: #FFFFFF;
					border-radius: 8rpx;

					.scrollList-box {
						height: 100%;
						margin-left: 40rpx;
						white-space: nowrap;

						.clasItems {
							display: inline-block;
							height: 100%;

							.items-container {
								height: 100%;
								margin-right: 40rpx;

								.iconbox {
									width: 66rpx;
									height: 66rpx;
								}

								.txt-box {
									font-size: 30rpx;
									font-weight: 500;
									color: #333333;
									margin-top: 10rpx;
								}
							}
						}
					}
				}
			}
		}

		.page-content {
			width: 100%;

			.goodsList-container {
				width: 100%;
				z-index: 50;
				margin-top: 290rpx;

				.goods-items-container {
					width: 100%;
					height: 260rpx;
					padding-left:10rpx;
					padding-right: 35rpx;
					background: #FFFFFF;
					border-radius: 16rpx;
					border-bottom: 1rpx solid #F0F1F7;
					margin-bottom: 20rpx;

					.left-imagecontent {
						width: 220rpx;
						height: 220rpx;
						border-radius: 8rpx;
						overflow: hidden;
					}

					.right-goodsinfo-container {
						margin-left: 20rpx;
						width: 420rpx;
						height: 220rpx;

						.top-content-box {
							width: 100%;

							.goodsnameinfo-content {
								width: 100%;
								margin-bottom: 12rpx;

								.typeIcon-content {
									width: 60rpx;
									height: 24rpx;
									margin-right: 5rpx;
									margin-top: 8rpx;
								}

								.tradename {
									width: 400rpx;
									overflow: hidden;
									text-overflow: ellipsis;
									white-space: nowrap;
									font-size: 28rpx;
									font-weight: 400;
									color: #333333;
								}
							}

							.desc-box {
								width: 100%;
								height: 60rpx;
								font-size: 24rpx;
								font-weight: 500;
								line-height: 30rpx;
								color: #999999;
								overflow: hidden;
								text-overflow: ellipsis;
								display: -webkit-box;
								-webkit-box-orient: vertical;
								-webkit-line-clamp: 2;
							}
						}

						.btm-content-box {
							width: 100%;

							.discounts-container {
								width: 100%;
								margin-bottom: 15rpx;

								.coupon-box {
									width: 102rpx;
									height: 30rpx;
									background: url(../../static/images/goods/couponbac.png)no-repeat;
									background-size: 100% 100%;
									font-size: 20rpx;
									font-weight: 500;
									color: #FF4242;
								}

								.back-box {
									height: 30rpx;
									padding: 0 10rpx;
									background: linear-gradient(-90deg, #7619EC, #A429F3);
									border-radius: 5rpx;
									margin-left: 8rpx;
									font-size: 20rpx;
									font-weight: 500;
									color: #FFFFFF;
								}
							}
							
							.price-saleNums-container {
								width: 100%;
							
								.left-price-box {
									.nowpirce{
										.rmb {
											font-size: 24rpx;
											font-weight: 600;
											color: #FF4242;
											line-height: 30rpx;
										}
										.num{
											font-size: 30rpx;
											line-height: 34rpx;
											font-weight: bold;
											color: #FF4242;
										}
									}
									.original-price {
										font-size: 24rpx;
										font-weight: 400;
										color: #999999;
										margin-left: 15rpx;
										line-height: 30rpx;
									}
								}
								
								.saleNum-content {
									font-size: 24rpx;
									font-weight: 500;
									color: #999999;
								}
							}
						}
					}
				}
			}
		}
	}
</style>
