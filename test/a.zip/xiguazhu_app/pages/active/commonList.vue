<template>
	<view class="searchResult wrapperLayer">
		<titleBar :titleText='pageName' :pageForm='"rank"'></titleBar>
		<view class="pageContent-container colCen">
			<view class="picbox rowCen">
				<view class="imgbox defIcon" @tap='goUrl( )'>
					<image :src="advert" mode="aspectFill"></image>
				</view>
			</view>

			<view class="goodsList-container">

				<!-- 竖排版 -->
				<view class="goods-content rowStaBet">
					<block v-for="(items,index) in goodsList" :key='index'>
						<view class="goods-items" @click="goDetail(items)">
							<colGoods :items="items"></colGoods>
						</view>
					</block>
				</view>
			</view>

			<aLoadMore :status="loadstatus" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
		</view>
	</view>
</template>

<script>
	import colGoods from '../../components/colGoods.vue'
	export default {
		components: {
			colGoods
		},
		data() {
			return {
				pageType:0,
				pageName: '',
				advert: '',
				goodsList: [],

				loadstatus: 'loading',
				pageCurrent: 1,
				canload: false
			}
		},
		onLoad(options) {
			this.pageType = options.type
			if (this.pageType == 0) {
				this.pageName = '实时热销榜'
			} else {
				this.pageName = '百亿补贴'
			}
			
			this.getList()
		},
		onReachBottom() {
			if(this.canload){
				this.getList()
			}
		},
		methods: {
			getList() {
				this.$http.post(this.pageType==0?'tb/getShiShiGoods':'tb/getBaiYi', {
					pageId: this.pageCurrent,
					pageSize: 10
				}, 'application/json').then(res => {
					uni.stopPullDownRefresh()
					if(res.goodsList.length<10){
						this.canload = false
						this.loadstatus = 'nomore'
					}else{
						this.canload = true
						this.loadstatus = 'loading'
						this.pageCurrent++
					}
					this.goodsList = this.goodsList.concat(res.goodsList)
					this.advert = res.img
				})
			},
			
			goDetail(info) {
				uni.navigateTo({
					url: '../goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(info))
				})
			}
		},
		onPullDownRefresh() {
			this.canload = false
			this.loadstatus = 'loading'
			this.pageCurrent = 1
			this.goodsList = []
			this.getList()
		}
	}
</script>

<style lang="scss">
	.searchResult {
		.pageContent-container {
			width: 100%;

			.picbox {
				width: 100%;
				height: 240rpx;
				background-color: #FFFFFF;
				box-shadow: 0px -1rpx 0px 0px #EFF1F7;
				padding: 0 32rpx;
				margin: 20rpx 0;

				.imgbox {
					width: 100%;
					height: 200rpx;
					border-radius: 12rpx;
					overflow: hidden;
				}
			}

			.goodsList-container {
				width: 100%;
				// background-color: #FFFFFF;

				.goods-content {
					width: 100%;
					padding: 0 20rpx;
					flex-wrap: wrap;

					.goods-items {
						width: 346rpx;
						height: 526rpx;
						margin-bottom: 20rpx;
					}
				}

				.colSetting-container {
					width: 100%;

					.listbox {
						width: 100%;

						.goods-items {
							width: 100%;
						}
					}
				}
			}
		}
	}
</style>
