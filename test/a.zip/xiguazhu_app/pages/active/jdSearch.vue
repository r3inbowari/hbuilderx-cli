<template>
	<view class="pddsearch-wrapper wrapperLayer borderBox">
		<view class="topbarbox"></view>
		<view class="fixed-container colCen">
			<view class="topbarbox"></view>
			<view class="headerBar-container rowCenBet">
				<view class="iconfont backicon" @tap="goback()">
					&#xe630;
				</view>
				<view class="titleBox rowCen" :style="'color:'+ (scrollTop<fiexdtop?'#DD2425;':'#ffffff;')">
					京东
				</view>
				<view class="rightEmpty">
				</view>
			</view>
		</view>
		<view class="pageContent-container colCen">
			<view class="search-region colCen">
				<view class="pageTitle-bar rowCenCen">
					<view class="leftIcon defIcon">
						<image src="../../static/images/active/jddog.png" mode="aspectFill"></image>
					</view>
					<view class="titleInfo colSta">
						<view class="topfont">
							京东优惠券大放送
						</view>
						<view class="bottomfont">
							先领东券 再购物 省千元
						</view>
					</view>
				</view>

				<view class="searchContent rowCenBet" @tap="gosearch()">
					<view class="leftcontent rowCen">
						<view class="search-icon iconfont">
							&#xe616;
						</view>
						<view class="tipsfont">
							输入商品名称或粘贴宝贝标题搜索
						</view>
					</view>
					<view class="right-btn rowCenCen">
						<view>搜索</view>
					</view>
				</view>
			</view>
			<view class="emptybar" :style="'width:100%;height:'+(scrollTop>fiexdtop?'90':'0')+'rpx;'">
			</view>

			<view class="rangeList-container rowCen" :class="scrollTop>fiexdtop?'tofixed':''" :style="'top:'+(scrollTop>fiexdtop?fiexdHeight:'0')+'px;'">
				<scroll-view class="scrollview-content" scroll-x scroll-with-animation="true">
					<block v-for="(items,index) in navList" :key="index">
						<view class="rangeItem" :class="nowCurrent==items.jingtuituiId?'rangeItem-active':''" @tap="changeRange(items.jingtuituiId)">
							<view class="boxcontent colCenCen">
								<view class="nameBox">
									{{items.name}}
								</view>
								<view class="border"></view>
							</view>
						</view>
					</block>
				</scroll-view>
			</view>

			<view class="goodsList-container colCen borderBox">
				<view class="goods-content rowStaBet">
					<view class="goods-items borderBox colCen" v-for="(items,index) in goodsList" :key='index' @click="goDetail(items)">
						<colGoods :items="items"></colGoods>
					</view>
					<aLoadMore :status="loadstatus" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import colGoods from '../../components/colGoods.vue'
	export default {
		components:{
			colGoods
		},
		data() {
			return {
				pageTop: 0,
				nowCurrent: 0,
				scrollTop: 0,
				navList: [],

				fiexdHeight: '',
				fiexdtop: '',
				goodsList: [],
				pageCurrent: 0,
				canloadmore: false,
				loadstatus: 'loading'
			}
		},
		onLoad() {
			this.getNav()
		},
		onPageScroll(e) {
			this.scrollTop = e.scrollTop
		},
		onReachBottom() {
			if (this.canloadmore) {
				this.getData()
			}
		},
		mounted() {
			uni.createSelectorQuery().in(this).select('.fixed-container').boundingClientRect(data => {
				console.log(data.top);
				this.fiexdHeight = data.height
			}).exec();
			uni.createSelectorQuery().in(this).select('.rangeList-container').boundingClientRect(data => {
				console.log(data.top);
				this.fiexdtop = data.top - this.fiexdHeight
			}).exec();
		},
		methods: {
			getNav() {
				this.$http.post('jd/getTopCatList').then(res => {
					console.log(res);
					this.navList = res
					this.nowCurrent = res[0].jingtuituiId
					this.getData()
				})
			},
			getData() {
				this.$http.post('jd/getGoodsList', {
					goodsType: this.nowCurrent,
					pageIndex: this.pageCurrent,
					pageSize: 10,
					offset: this.pageCurrent
				}, 'application/json').then(res => {
					uni.stopPullDownRefresh();
					console.log(res);
					if (res.length < 10) {
						this.pageCurrent ++
						this.canloadmore = false
						this.loadstatus = 'nomarl'
					} else {
						this.canloadmore = true
						this.loadstatus = 'loading'
						this.pageCurrent ++
					}
					this.goodsList = this.goodsList.concat(res)
				})
			},

			changeRange(id) {
				this.pageCurrent = 0
				this.canloadmore = false
				this.nowCurrent = id
				this.loadstatus = 'loading'
				this.goodsList = []
				this.getData()
			},

			goDetail(info) {
				console.log(info);
				uni.navigateTo({
					url: '../goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(info))
				})
			},

			goback() {
				uni.navigateBack({
					delta: 1
				})
			},

			gosearch() {
				uni.navigateTo({
					url: '../search/search?type=1'
				})
			}
		},
		onPullDownRefresh() {
			this.pageCurrent = 0;
			this.canloadmore = false;
			this.goodsList = [];
			this.loadstatus = 'loading';
			this.getData()
		}
	}
</script>

<style lang="scss">
	.pddsearch-wrapper {
		width: 100%;

		.fixed-container {
			width: 100%;
			position: fixed;
			top: 0;
			left: 0;
			z-index: 110;
			background: linear-gradient(266deg, #E7251C, #E7251C);

			.headerBar-container {
				width: 100%;
				height: 90rpx;
				padding: 0 32rpx;

				.backicon {
					font-size: 30rpx;
					color: #FFFFFF;
				}

				.titleBox {
					font-size: 32rpx;
					font-weight: 500;
					z-index: 10;
					transition: all 0.5s;
				}

				.rightEmpty {
					width: 32rpx;
					height: 32rpx;
				}
			}
		}

		.pageContent-container {
			width: 100%;

			.search-region {
				width: 100%;
				height: 340rpx;
				padding: 0 75rpx;
				background: linear-gradient(266deg, #E7251C, #E7251C);

				.pageTitle-bar {
					width: 100%;
					margin-top: 110rpx;

					.leftIcon {
						width: 75rpx;
						height: 75rpx;
					}

					.titleInfo {
						margin-left: 15rpx;

						.topfont {
							font-size: 36rpx;
							font-weight: 800;
							color: #FFFFFF;
						}

						.bottomfont {
							font-size: 26rpx;
							font-weight: 500;
							color: #FFFFFF;
						}
					}
				}

				.searchContent {
					width: 100%;
					height: 80rpx;
					border-radius: 40rpx;
					background-color: #FFFFFF;
					margin-top: 40rpx;
					padding: 0 10rpx;

					.leftcontent {
						margin-left: 25rpx;

						.search-icon {
							font-size: 32rpx;
							font-weight: 500;
							color: #999999;
							margin-right: 25rpx;
						}

						.tipsfont {
							font-size: 26rpx;
							font-weight: 500;
							color: #999999;
						}
					}

					.right-btn {
						width: 116rpx;
						height: 60rpx;
						background: linear-gradient(266deg, #FF012E, #FF1017);
						border-radius: 30rpx;
						font-size: 24rpx;
						font-weight: 500;
						color: #FFFFFF;
					}
				}
			}

			.rangeList-container {
				width: 100%;
				height: 80rpx;
				padding-left: 32rpx;
				z-index: 101;

				.scrollview-content {
					width: 100%;
					height: 100%;
					white-space: nowrap;

					.rangeItem {
						display: inline-flex;
						margin-right: 45rpx;
						height: 100%;

						.boxcontent {
							height: 100%;

							.nameBox {
								font-size: 30rpx;
								font-weight: 500;
								color: #333333;
							}

							.border {
								width: 60%;
								height: 2rpx;
								background: transparent;
							}
						}
					}

					.rangeItem-active {
						.boxcontent {
							.nameBox {
								font-size: 32rpx;
							}

							.border {
								background: #FF012E;
								margin-top: 8rpx;
							}
						}
					}
				}
			}

			.tofixed {
				position: fixed;
				z-index: 100;
				background-color: #FFFFFF;
			}

			.goodsList-container {
				z-index: 1;
				width: 100%;
				padding: 0 20rpx;
				margin-top: 10rpx;

				.goods-content {
					width: 100%;
					flex-wrap: wrap;
					
					.goods-items{
						margin-bottom: 20rpx;
					}
				}
			}
		}
	}
</style>
