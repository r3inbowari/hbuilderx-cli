<template>
	<view class="everydayRecommend-wrapper wrapperLayer">
		<view class="tbac">
			<view class="top-bacolor" :style="'background-color:'+pageColor"></view>
		</view>
		<view class="fixed-content colCen" :style="'background-color:'+pageColor">
			<view class="topbar-container colCen">
				<view class="topbarbox"></view>
				<view class="headerNavigationbar rowCenBet borderBox">
					<view class="backIcon rowCenSta" @click="backUrl()">
						<image src="../../static/images/home/returnWhite.png" mode="aspectFill"></image>
					</view>
					<view class="pageTitle">
						每日必推
					</view>
					<view class="emptybox rowCenEnd">
					</view>
				</view>
			</view>

			<view class="classification-container rowCenBet">
				<block v-for="(items,index) in navList" :key="index">
					<view class="nav-items-container colCen" :class="index==navCurrent?'nav-items-active':''"
						@tap="clkNav(items.type,items.color)">
						<view class="items-txt">
							{{items.val}}
						</view>
						<view class="border"></view>
					</view>
				</block>
			</view>
		</view>

		<view class="page-content colCen pd20">
			<view class="topbarbox"></view>
			<view class="goodsList-container colCen">
				<block v-for="(items,index) in goodsList" :key="index">
					<view class="goodsItems-container rowCen" @tap="goDetails(items)">
						<view class="leftpic defIcon">
							<image :src="items.mainPic" mode="aspectFill"></image>
						</view>
						<view class="right-info-container colCen">
							<view class="goodsnameinfo-content rowSta">
								<view class="typeIcon-content defIcon">
									<image src="../../static/images/goods/pddtips.png" mode="heightFix"></image>
								</view>
								<view class="tradename">
									{{items.dtitle}}
								</view>
							</view>

							<view class="saleNum-container">
								今日已售<span>{{items.monthSales}}</span>件
							</view>

							<view class="ori-price rowCen">
								<view class="tips">
									原价
								</view>

								<s class="original-price">
									￥{{items.originalPrice}}
								</s>
							</view>

							<view class="bottomInfo-container rowEndBet">
								<view class="left-price-box rowEnd">
									<view class="tips">
										券后价￥
									</view>
									<view class="price">
										{{items.actualPrice}}
									</view>
								</view>
								<view class="snapUp-btn rowCenCen" :style="'background-color:'+pageColor">
									<view>赚 {{items.fanli}}</view>
								</view>
							</view>
						</view>
					</view>
				</block>
				<aLoadMore :status="loadstate" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				pageColor: '#FF8810',
				navList: [{
						type: 0,
						val: '1.9包邮',
						color: '#FF8810'
					},
					{
						type: 1,
						val: '今日爆款',
						color: '#F2291A'
					},
					{
						type: 2,
						val: '品牌清仓',
						color: '#304975'
					},
					{
						type: 5,
						val: '实时热销',
						color: '#FE567A'
					}
				],
				navCurrent: 0,

				goodsList: [],
				loadstate: 'loading',
				pageCurrent: 0,
				canload: false,
				listId: ''
			}
		},
		onLoad(options) {
			this.getList()
		},
		onReachBottom() {
			if (this.canload) {
				this.getList()
			}
		},
		methods: {
			getList() {
				this.$http.post('pddgoods/ddjingxuan', {
					channelType: this.navCurrent,
					limit: 10,
					listId: this.listId,
					offset: this.pageCurrent
				}, 'application/json').then(res => {
					console.log(res);
					uni.stopPullDownRefresh()
					this.listId = res.listId
					if (res.length < 10) {
						this.loadstate = 'nomore'
						this.pageCurrent += 10
					} else {
						this.loadstate = 'loading'
						this.pageCurrent += 10
						this.canload = true
					}
					this.goodsList = this.goodsList.concat(res.goodsList)
				})
			},
			clkNav(idx, cor) {
				this.navCurrent = idx
				this.pageColor = cor
				this.pageCurrent = 0
				this.canload = false
				this.loadstate = 'loading'
				this.goodsList = []
				this.getList()
			},
			backUrl() {
				uni.navigateBack({
					delta: 1
				})
			},
			goDetails(info) {
				info.searchSource = 2
				uni.navigateTo({
					url: '../goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(info))
				})
			},
		},
		onPullDownRefresh() {
			this.pageCurrent = 0
			this.loadstate = 'loading'
			this.canload = false
			this.goodsList = []
			this.getList()
		}
	}
</script>

<style lang="scss">
	.everydayRecommend-wrapper {
		width: 100%;
		min-height: 100vh;
		overflow: hidden;

		.tbac {
			width: 100%;
			position: relative;
			.top-bacolor {
				width: 200%;
				height: 460rpx;
				border-bottom-left-radius: 50%;
				border-bottom-right-radius: 50%;
				position: absolute;
				left: -50%;
				top: 0;
			}
		}

		.fixed-content {
			width: 100%;
			position: fixed;
			top: 0;
			z-index: 100;

			.topbar-container {
				width: 100%;

				.headerNavigationbar {
					width: 100%;
					height: 90rpx;
					padding: 0 32rpx;
					z-index: 10;

					.backIcon {
						width: 60rpx;
						height: 32rpx;
						z-index: 1;

						image {
							width: 17rpx;
							height: 32rpx;
						}
					}

					.pageTitle {
						font-size: 34rpx;
						font-weight: 500;
						color: #FFFFFF;
					}

					.emptybox {
						width: 60rpx;
						height: 32rpx;
					}
				}
			}

			.classification-container {
				width: 100%;
				z-index: 10;
				padding: 0 50rpx;
				margin-top: 40rpx;
				margin-bottom: 20rpx;

				.nav-items-container {
					.items-txt {
						font-size: 30rpx;
						font-weight: 500;
						color: #FFFFFF;
					}

					.border {
						width: 94rpx;
						height: 4rpx;
						background: transparent;
						border-radius: 2rpx;
						margin-top: 15rpx;
					}
				}

				.nav-items-active {
					.items-txt {
						font-weight: bold;
					}

					.border {
						background: #F9EC7C;
					}
				}
			}
		}

		.page-content {
			width: 100%;

			.goodsList-container {
				width: 100%;
				z-index: 50;
				margin-top: 230rpx;

				.goodsItems-container {
					width: 100%;
					height: 262rpx;
					background: #FFFFFF;
					border-radius: 16rpx;
					padding: 0 10rpx;
					margin-bottom: 20rpx;

					.leftpic {
						width: 222rpx;
						height: 222rpx;
						border-radius: 8rpx;
						overflow: hidden;
					}

					.right-info-container {
						width: 450rpx;
						margin-left: 20rpx;

						.goodsnameinfo-content {
							width: 100%;
							margin-bottom: 15rpx;

							.typeIcon-content {
								width: 60rpx;
								height: 24rpx;
								margin-right: 5rpx;
								margin-top: 8rpx;
							}

							.tradename {
								width: 400rpx;
								overflow: hidden;
								text-overflow: ellipsis;
								white-space: nowrap;
								font-size: 28rpx;
								font-weight: 400;
								color: #333333;
							}
						}

						.saleNum-container {
							width: 100%;
							font-size: 28rpx;
							font-weight: 500;
							color: #888888;
							margin-bottom: 20rpx;

							span {
								color: #FE3738;
							}
						}

						.ori-price {
							width: 100%;
							font-size: 24rpx;
							font-weight: 500;
							color: #999999;
							margin-bottom: 20rpx;
						}

						.bottomInfo-container {
							width: 100%;

							.left-price-box {
								.tips {
									font-size: 24rpx;
									font-weight: 500;
									color: #FE3738;
									line-height: 38rpx;
								}

								.price {
									font-size: 30rpx;
									font-weight: bold;
									color: #FE3738;
								}
							}

							.snapUp-btn {
								height: 44rpx;
								padding: 0 10rpx;
								border-radius: 8rpx;
								font-size: 28rpx;
								font-weight: 500;
								color: #FFFFFF;
							}
						}
					}
				}
			}
		}
	}
</style>
