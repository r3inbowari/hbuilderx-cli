<template>
	<view class="everydayRecommend-wrapper wrapperLayer">
		<view class="top-bacolor"></view>
		<view class="fixed-content colCen">
			<view class="fixed-color"></view>
			<view class="topbar-container colCen">
				<view class="topbarbox"></view>
				<view class="headerNavigationbar rowCenBet borderBox">
					<view class="backIcon rowCenSta" @click="backUrl()">
						<image src="../../static/images/home/returnWhite.png" mode="aspectFill"></image>
					</view>
					<view class="pageTitle">
						京东秒杀
					</view>
					<view class="emptybox rowCenEnd">

					</view>
				</view>
			</view>

			<view class="timeSlot-container rowCenBet">
				<scroll-view class="scview" scroll-x scroll-with-animation @scroll='scrollfnc' :scroll-into-view='srollid'>
					<block v-for="(items,index) in navList" :key="index">
						<view class="nav-items-container" @tap="clkNav(items.h,index)" :id="tapNav==index+2?'nowScroll':''">
							<view class="clobox colCen" :class="navCurrent==items.h?'clobox-active':''" >
								<view class="time">
									{{items.name}}
								</view>

								<view class="state-box rowCenCen">
									<view>{{items.type=='1'?'已开抢':items.type=='2'?'抢购中':'即将开抢'}}</view>
								</view>
							</view>
						</view>
					</block>
				</scroll-view>
			</view>
		</view>

		<view class="page-content colCen pd20">
			<view class="topbarbox"></view>
			<view class="goodsList-container colCen">
				<block v-for="(items,index) in goodsList" :key="index">
					<view class="goodsItems-container rowCen" @tap="goDetails(items)">
						<view class="leftpic defIcon">
							<image :src="items.mainPic" mode="aspectFill"></image>
						</view>
						<view class="right-info-container colCen">
							<view class="goodsnameinfo-content rowSta">
								<view class="typeIcon-content defIcon">
									<image src="../../static/images/goods/jdtips.png" mode="heightFix"></image>
								</view>
								<view class="tradename">
									{{items.dtitle}}
								</view>
							</view>

							<view class="saleNum-container">
								今日已售<span>{{items.monthSales}}</span>件
							</view>

							<view class="ori-price rowCen">
								<view class="tips">
									原价
								</view>

								<s class="original-price">
									￥{{items.originalPrice}}
								</s>
							</view>

							<view class="bottomInfo-container rowEndBet">
								<view class="left-price-box rowEnd">
									<view class="tips">
										秒杀价￥
									</view>
									<view class="price">
										{{items.actualPrice}}
									</view>
								</view>
								<view class="snapUp-btn rowCenCen">
									<view>速度抢</view>
								</view>
							</view>
						</view>
					</view>
				</block>
				<aLoadMore :status="loadstate" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				navList: [],
				navCurrent: 0,
				tapNav:0,
				nowscLeft:0,
				sclft:0,
				srollid:'',

				goodsList: [],
				loadstate: 'loading',
				pageCurrent: 1,
				canload: false
			}
		},
		
		onLoad() {
			this.getTime()
		},
		onReachBottom() {
			if(this.canload){
				this.getList()
			}
		},
		methods: {
			scToview(idx){
				console.log(idx);
				this.srollid = ''
				this.$nextTick(()=>{
					this.srollid = 'nowScroll'
				})
				uni.upx2px(100)
			},
			scrollfnc(e){
				this.nowscLeft = e.detail.scrollLeft
				console.log(e);
			},
			getTime(){
				this.$http.post('jd/getSeckillTime').then(res=>{
					console.log(res);
					this.navList = res
					this.navList.forEach((items,index)=>{
						if(items.type=='2'){
							this.navCurrent = items.h
							this.tapNav = index
							this.getList()
							this.scToview(index)
						}
					})
				})
			},
			getList(){
				this.$http.post('jd/seckill',{
					h:this.navCurrent,
					num:10,
					page:this.pageCurrent
				},'application/json').then(res=>{
					console.log(res);
					uni.stopPullDownRefresh()
					if(res.length<10){
						this.loadstate = 'nomore'
						this.pageCurrent+=10
					}else{
						this.loadstate = 'loading'
						this.pageCurrent+=10
						this.canload = true
					}
					this.goodsList = this.goodsList.concat(res)
				})
			},
			goDetails(info) {
				info.searchSource = 3
				uni.navigateTo({
					url: '../goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(info))
				})
			},
			clkNav(h,idx) {
				this.navCurrent = h
				this.tapNav = idx
				this.goodsList = [];
				this.canload = false;
				this.pageCurrent = 1
				this.loadstate = 'loading'
				this.getList()
				this.scToview()
			},
			backUrl(){
				uni.navigateBack({
					delta:1
				})
			}
		},
		onPullDownRefresh() {
			this.goodsList = [];
			this.canload = false;
			this.goodsList = []
			this.pageCurrent = 1
			this.loadstate = 'loading'
			this.getTime()
		}
	}
</script>

<style lang="scss">
	.everydayRecommend-wrapper {
		width: 100%;
		min-height: 100vh;

		.top-bacolor {
			width: 200%;
			height: 460rpx;
			border-bottom-left-radius: 50%;
			border-bottom-right-radius: 50%;
			position: absolute;
			background: linear-gradient(4deg, #F6551F, #E00604);
			left: -50%;
			top: 0;
		}

		.fixed-content {
			width: 100%;
			overflow: hidden;
			background: linear-gradient(4deg, #F6551F, #E00604);
			position: fixed;
			top: 0;
			z-index: 100;
			.fixed-color{
				width: 200%;
				height: 460rpx;
				position: absolute;
				background: linear-gradient(4deg, #F6551F, #E00604);
				left: -50%;
				top: 0;
			}

			.topbar-container {
				width: 100%;

				.headerNavigationbar {
					width: 100%;
					height: 90rpx;
					padding: 0 32rpx;
					z-index: 10;

					.backIcon {
						width: 60rpx;
						height: 32rpx;
						z-index: 1;

						image {
							width: 17rpx;
							height: 32rpx;
						}
					}

					.pageTitle {
						font-size: 34rpx;
						font-weight: 500;
						color: #FFFFFF;
					}

					.emptybox {
						width: 60rpx;
						height: 32rpx;
					}
				}
			}

			.timeSlot-container {
				width: 100%;
				margin-top: 40rpx;
				margin-bottom: 20rpx;

				.scview {
					width: 100%;
					z-index: 10;
					white-space: nowrap;
					padding: 0 20rpx;

					.nav-items-container {
						display: inline-block;
						margin-right: 70rpx;

						.clobox {
							.time {
								font-size: 34rpx;
								font-weight: bold;
								color: #FFFFFF;
							}

							.state-box {
								height: 44rpx;
								font-size: 26rpx;
								font-weight: 500;
								color: #FFFFFF;
								margin-top: 20rpx;
							}
						}

						.clobox-active {
							.time {
								color: #F9EC7C;
							}

							.state-box {
								background: #F9EC7C;
								color: #FE3738;
								border-radius: 22rpx;
								padding: 0 10rpx;
							}
						}
					}
				}
			}
		}

		.page-content {
			width: 100%;

			.goodsList-container {
				width: 100%;
				z-index: 50;
				margin-top: 280rpx;

				.goodsItems-container {
					width: 100%;
					height: 262rpx;
					background: #FFFFFF;
					border-radius: 16rpx;
					padding: 0 10rpx;
					margin-bottom: 20rpx;

					.leftpic {
						width: 222rpx;
						height: 222rpx;
						border-radius: 8rpx;
						overflow: hidden;
					}

					.right-info-container {
						width: 450rpx;
						margin-left: 20rpx;

						.goodsnameinfo-content {
							width: 100%;
							margin-bottom: 15rpx;

							.typeIcon-content {
								width: 60rpx;
								height: 24rpx;
								margin-right: 5rpx;
								margin-top: 8rpx;
							}

							.tradename {
								width: 400rpx;
								overflow: hidden;
								text-overflow: ellipsis;
								white-space: nowrap;
								font-size: 28rpx;
								font-weight: 400;
								color: #333333;
							}
						}

						.saleNum-container {
							width: 100%;
							font-size: 28rpx;
							font-weight: 500;
							color: #888888;
							margin-bottom: 20rpx;

							span {
								color: #FE3738;
							}
						}

						.ori-price {
							width: 100%;
							font-size: 24rpx;
							font-weight: 500;
							color: #999999;
							margin-bottom: 20rpx;
						}

						.bottomInfo-container {
							width: 100%;

							.left-price-box {
								.tips {
									font-size: 24rpx;
									font-weight: 500;
									color: #FE3738;
									line-height: 38rpx;
								}

								.price {
									font-size: 30rpx;
									font-weight: bold;
									color: #FE3738;
								}
							}

							.snapUp-btn {
								height: 44rpx;
								padding: 0 10rpx;
								border-radius: 8rpx;
								font-size: 28rpx;
								font-weight: 500;
								color: #FFFFFF;
								background: linear-gradient(0deg, #E00604, #F85C21);
								opacity: 0.98;
							}
						}
					}
				}
			}
		}
	}
</style>
