<template>
	<view class="login-wrapper wrapperLayer colCen">
		<titleBar titleText='' :pageForm='"setInvite"' @backIndex="backHome"></titleBar>
		<view class="pageContent borderBox colCen">
			<view class="titleText">
				填写邀请码
			</view>

			<view class="input-container colCen">
				<view class="outSidebox rowCenBet" data-type='code' :class="selectedInput=='code'?'outSidebox-active':''">
					<input @focus="changeType" @blur="cleanActive" @confirm="searchCode" data-type='code' type="text" v-model="code"
					 placeholder="请输入邀请码" placeholder-class="input-placeHolder" />
				</view>
			</view>

			<view class="login-btn rowCenCen" :class="code?'colorfulbtn':''" @click="searchCode()">
				<view class="btn-font">
					确认
				</view>
			</view>
		</view>

		<u-popup v-model="show" mode="center" border-radius="14" width="500rpx">
			<view class="model-container colCen">
				<view class="title-box">
					请确认您的邀请人
				</view>
				<view class="subtitle-box">
					仅可填写一次，请核对邀请人信息
				</view>
				
				<view class="avatar-box defIcon">
					<image :src="inviterInfo.avatar" mode="aspectFill"></image>
				</view>
				
				<view class="username">
					{{inviterInfo.nickName}}
				</view>
				
				<view class="phoneInfo rowCenCen">
					<view>{{inviterInfo.account}}</view>
				</view>
				
				<view class="btn-bar rowCenBet">
					<view class="cancel rowCenCen" @tap="cancel()">
						<view>重新填写</view>
					</view>
					<view class="confirm rowCenCen" @tap="setinvite()">
						<view>确认添加</view>
					</view>
				</view>
			</view>
		</u-popup>
	</view>
</template>

<script>
	import titleBar from '../../components/backTitlebar.vue'
	export default {
		components: {
			titleBar
		},
		data() {
			return {
				code: '',
				selectedInput: '',
				show:false,
				inviterInfo:''
				
			};
		},
		onLoad() {},
		methods: {
			backHome() {
				uni.switchTab({
					url: '../index/index'
				})
			},
			changeType(e) {
				this.selectedInput = e.target.dataset.type
			},
			cleanActive() {
				this.selectedInput = ''
			},
			searchCode() {
				this.$http.get('member/getUserInfoByCode',{
					inviteCode:this.code
				}).then(res=>{
					this.show = true
					console.log(res);
					this.inviterInfo = res
				}).catch(res=>{
					console.log(res);
				})
			},
			cancel(){
				this.show = false
			},
			setinvite() {
				this.$http.get('member/bindInviteCode',{
					inviteCode:this.code
				}).then(res=>{
					this.show = false
					this.getuserInfo()
					uni.switchTab({
						url: '../index/index'
					})
				}).catch(res=>{
					console.log(res);
				})
			},
			getuserInfo() {
				this.$http.get('member/getInfo', {}, true).then((res) => {
					console.log(res, '========>获取用户信息');
					util.setCache('userData', res)
				})
			}
		}
	};
</script>

<style lang="scss">
	.login-wrapper {
		width: 100%;
		min-height: 100vh;
		background-color: #FFFFFF;

		.pageContent {
			width: 100%;
			padding: 0 60rpx;

			.titleText {
				width: 100%;
				font-size: 42rpx;
				font-weight: bold;
				color: #333333;
				margin: 60rpx 0;
			}

			.input-container {
				width: 100%;
				margin-bottom: 20rpx;

				.outSidebox {
					width: 100%;
					height: 85rpx;
					border-bottom: 2rpx solid #F1F1F1;

					.input-placeHolder {
						font-size: 34rpx;
						font-weight: 500;
						color: #CACACA;
					}

					input {
						font-size: 34rpx;
						font-weight: 500;
						color: #222222;
					}

					.hidepass {
						font-size: 32rpx;
						font-weight: 800;
						color: #CACACA;
					}

					.getcodebox {
						font-size: 28rpx;
						white-space: nowrap;
						font-weight: 400;
						color: #FF2851;
						pointer-events: none;
					}

					.colorTxt {
						pointer-events: auto;
					}
				}

				.outSidebox-active {
					border-bottom: 2rpx solid #FF2851;
				}
			}

			.txtTips {
				font-size: 26rpx;
				font-weight: 400;
				color: #999999;
				line-height: 38rpx;
			}

			.login-btn {
				width: 100%;
				height: 86rpx;
				background: #E2E2E2;
				border-radius: 43rpx;
				margin-top: 80rpx;
				pointer-events: none;

				.btn-font {
					font-size: 30rpx;
					font-weight: 500;
					color: #FFFFFF;
				}
			}

			.colorfulbtn {
				background: #FD002F;
				pointer-events: auto;
			}
		}
	}
	
	.model-container{
		width: 100%;
		height: 100%;
		padding: 30rpx 30rpx;
		.title-box{
			font-size: 30rpx;
			font-weight: bold;
			color: #333333;
			margin-top: 20rpx;
		}
		.subtitle-box{
			font-size: 24rpx;
			font-weight: 500;
			color: #333333;
			margin-top: 25rpx;
		}
		.avatar-box{
			width: 126rpx;
			height: 126rpx;
			overflow: hidden;
			border-radius: 50%;
			margin-top: 30rpx;
		}
		.username{
			font-size: 24rpx;
			font-weight: 500;
			color: #333333;
			margin-top: 20rpx;
		}
		.phoneInfo{
			width: 100%;
			height: 104rpx;
			background: #F7F7F7;
			border-radius: 8rpx;
			font-size: 36rpx;
			font-weight: bold;
			color: #333333;
			margin-top: 20rpx;
		}
		.btn-bar{
			width: 100%;
			margin-top: 30rpx;
			.cancel{
				width: 196rpx;
				height: 72rpx;
				background: #E5E5E5;
				font-size: 30rpx;
				font-weight: 500;
				color: #333333;
				border-radius: 36rpx;
			}
			.confirm{
				width: 196rpx;
				height: 72rpx;
				background: #FD002F;
				border-radius: 36rpx;
				font-size: 30rpx;
				font-weight: 500;
				color: #FFFFFF;
			}
		}
	}
</style>
