<template>
	<view class="wxlogin-wrapper wrapperLayer">
		<titleBar titleText='' :pageForm='"login"' @backIndex="backHome"></titleBar>
		<view class="pageContent borderBox colCen">
			<image class="applogo" :src="appInfo.logo" mode="aspectFill"></image>
			
			<view class="wxlogoBtn rowCenCen">
				<image class="logoIcon" src="../../static/images/mine/wxwhite.png" mode=""></image>
				<view>微信一键登录</view>
			</view>
			
			<view class="goaccount rowCenCen" @tap="goaccount()">
				<view>手机号登录/注册</view>
			</view>
		</view>
		
		<view class="bottom-fixed colCen">
			<view class="explain-text rowCen">
				<switch type="checkbox" @change="changeread" :checked='isread' style="transform:scale(0.6)" />
				登陆代表已详细阅读并同意<text @click="goPage('agreement')">《用户协议》</text>和<text @click="goPage('policy')">《隐私政策》</text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data(){
			return{
				appInfo:'',
				ifPasslogin:false
			}
		},
		onLoad() {
			this.appInfo = uni.getStorageSync('appInfo')
			console.log(this.appInfo);
		},
		methods:{
			backHome() {
				var pages = getCurrentPages();
				console.log(pages.length);
				if(pages.length==1){
					uni.switchTab({
						url: '../index/index'
					})
				}else{
					uni.navigateBack({
						delta:1
					})
				}
			},
			
			changeread(e) {
				console.log(e);
				this.isread = e.target.value
			},
			
			goPage(type) {
				uni.navigateTo({
					url: './policyAgreement?type=' + type
				})
			},
			
			goaccount(){
				uni.navigateTo({
					url:'./login'
				})
			}
		}
	}
</script>

<style lang="scss">
	.wxlogin-wrapper{
		width: 100%;
		min-height: 100vh;
		background-color: #FFFFFF;
		.pageContent{
			width: 100%;
			padding: 0 32rpx;
			.applogo{
				width: 168rpx;
				height: 168rpx;
				margin-top: 80rpx;
			}
			
			.wxlogoBtn{
				width: 100%;
				height: 100rpx;
				background: #32BD00;
				border-radius: 50rpx;
				font-size: 30rpx;
				font-weight: 500;
				color: #FFFFFF;
				margin-top: 140rpx;
				.logoIcon{
					width: 47rpx;
					height: 39rpx;
					margin-right: 20rpx;
				}
			}
			
			.goaccount{
				width: 100%;
				height: 100rpx;
				background: #FFFFFF;
				border: 1rpx solid #999999;
				border-radius: 50rpx;
				font-size: 30rpx;
				font-weight: 500;
				color: #333333;
				margin-top: 30rpx;
			}
		}
		
		.bottom-fixed {
			width: 100%;
			position: fixed;
			bottom: 100rpx;
			bottom: calc(100rpx + constant(safe-area-inset-bottom));
			bottom: env(100rpx + constant(safe-area-inset-bottom));
			left: 0;
			z-index: 1;
		
			.verification-Code {
				white-space: nowrap;
				font-size: 28rpx;
				font-weight: 500;
				color: #333333;
			}
		
			.explain-text {
				font-size: 22rpx;
				font-weight: 500;
				color: #999999;
				margin-top: 30rpx;
				white-space: nowrap;
			}
		}
	}
</style>
