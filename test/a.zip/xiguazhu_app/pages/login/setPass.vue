<template>
	<view class="login-wrapper wrapperLayer colCen">
		<titleBar titleText='' :pageForm='"setPass"' @backIndex="backHome"></titleBar>
		<view class="pageContent borderBox colCen">
			<view class="titleText">
				设置密码
			</view>

			<view class="input-container colCen">
				<view class="outSidebox rowCenBet" data-type='pass' :class="selectedInput=='pass'?'outSidebox-active':''">
					<input @focus="changeType" @blur="cleanActive" @confirm="setPass" data-type='pass' type="text" password v-model="pass"
					 placeholder="请输入密码" placeholder-class="input-placeHolder" />
				</view>
			</view>
			<view class="txtTips">
				密码由8-16个字符组成。必须包含字母和数字两种类型。
			</view>

			<view class="login-btn rowCenCen" :class="pass?'colorfulbtn':''" @click="setPass()">
				<view class="btn-font">
					完成
				</view>
			</view>
		</view>
		
		<u-popup v-model="inviteCodeShow" mode="center" border-radius="32" :mask-close-able='false'>
			<invite-code @closeModel='closeinvite' @confirm='nextStep'></invite-code>
		</u-popup>
		
		<u-popup v-model="inviterShow" mode="center" border-radius="32" v-if="inviterShow" :mask-close-able='false'>
			<inviter-model ref='invitermodel' @rewrite='rewriteCode' @setInvite='setCode'></inviter-model>
		</u-popup>
	</view>
</template>

<script>
	import titleBar from '../../components/backTitlebar.vue'
	import inviteCode from '../../components/inviteCode.vue'
	import inviterModel from '../../components/inviterModel.vue'
	export default {
		components: {
			titleBar,
			inviteCode,
			inviterModel
		},
		data() {
			return {
				pass: '',
				selectedInput: '',
				inviteCodeShow:false,
				inviterShow:false
				
			};
		},
		onLoad() {
		},
		methods: {
			backHome(){
				uni.switchTab({
					url:'../index/index'
				})
			},
			changeType(e) {
				this.selectedInput = e.target.dataset.type
			},
			cleanActive() {
				this.selectedInput = ''
			},
			setPass() {
				var str = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$/;
				if (str.test(this.pass)) {
					this.$http.post('member/updateMember', {
						pwd: this.pass
					}, 'application/json',true).then((res) => {
						console.log(res);
						if(res.inviteCode){
							uni.switchTab({
								url:'../index/index'
							})
						}else{
							this.inviteCodeShow = true
						}
					})
				} else {
					uni.showToast({
						title: '密码不符合要求，请输入8~16位的数字与字母的组合',
						icon: 'none',
						position: 'bottom',
						duration: 3000
					});
				}
			},
			
			closeinvite(){
				this.inviteCodeShow = false
				uni.switchTab({
					url:'../index/index'
				})
			},
			nextStep(e){
				uni.setStorageSync('inviterInfo',e)
				this.inviteCodeShow = false
				this.inviterShow = true
			},
			rewriteCode(){
				this.inviteCodeShow = true
				this.inviterShow = false
			},
			setCode(){
				this.getuserInfo()
			},
			getuserInfo() {
				this.$http.get('member/getInfo', {}, true).then((res) => {
					console.log(res, '========>获取用户信息');
					uni.setStorageSync('userData',res)
					this.inviterShow = false
					this.inviteCodeShow = false
					uni.switchTab({
						url:'../index/index'
					})
				})
			}
		}
	};
</script>

<style lang="scss">
	.login-wrapper {
		width: 100%;
		min-height: 100vh;
		background-color: #FFFFFF;

		.pageContent {
			width: 100%;
			padding: 0 60rpx;

			.titleText {
				width: 100%;
				font-size: 42rpx;
				font-weight: bold;
				color: #333333;
				margin: 60rpx 0;
			}

			.input-container {
				width: 100%;
				margin-bottom: 20rpx;

				.outSidebox {
					width: 100%;
					height: 85rpx;
					border-bottom: 2rpx solid #F1F1F1;

					.input-placeHolder {
						font-size: 34rpx;
						font-weight: 500;
						color: #CACACA;
					}

					input {
						font-size: 34rpx;
						font-weight: 500;
						color: #222222;
					}

					.hidepass {
						font-size: 32rpx;
						font-weight: 800;
						color: #CACACA;
					}

					.getcodebox {
						font-size: 28rpx;
						white-space: nowrap;
						font-weight: 400;
						color: #FF2851;
						pointer-events: none;
					}

					.colorTxt {
						pointer-events: auto;
					}
				}

				.outSidebox-active {
					border-bottom: 2rpx solid #FF2851;
				}
			}

			.txtTips {
				font-size: 26rpx;
				font-weight: 400;
				color: #999999;
				line-height: 38rpx;
			}

			.login-btn {
				width: 100%;
				height: 86rpx;
				background: #E2E2E2;
				border-radius: 43rpx;
				margin-top: 80rpx;
				pointer-events: none;

				.btn-font {
					font-size: 30rpx;
					font-weight: 500;
					color: #FFFFFF;
				}
			}

			.colorfulbtn {
				background: #FD002F;
				pointer-events: auto;
			}
		}
	}
</style>
