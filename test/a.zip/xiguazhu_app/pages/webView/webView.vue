<template>
	<view>
		<web-view :webview-styles="webviewStyles" :src="webviewUrl" @message='received'></web-view>
	</view>
</template>

<script>
	var wv
	export default {
		data() {
			return {
				webviewUrl: '',
				webviewStyles: {
					progress: {
						color: '#EE1B14'
					}
				},
			}
		},
		onLoad(options) {
			console.log(options);
			this.webviewUrl = encodeURI(options.url)
		},
		methods: {
			received(e) {
				console.log(e.detail.data[0].type)
				if(e.detail.data[0].type=='getToken'){
					const token = uni.getStorageSync('userInfo').token;
					var currentWebview = this.$scope.$getAppWebview()
					var wv = currentWebview.children()[0]
					wv.evalJS('localStorage.setItem("ZZTOKEN",' + JSON.stringify(token) + ')');
				}
			},
		},
		onNavigationBarButtonTap(e) {
			// #ifdef APP-PLUS
			const currentWebview = this.$scope.$getAppWebview(); //此对象相当于html5plus里的plus.webview.currentWebview()。在uni-app里vue页面直接使用plus.webview.currentWebview()无效，非v3编译模式使用this.$mp.page.$getAppWebview()
			var wv = currentWebview.children()[0]
			wv.reload();
			// #endif
			console.log(JSON.stringify(e))
		},
	}
</script>

<style>

</style>
