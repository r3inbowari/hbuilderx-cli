<template>
	<view class="officialNotice wrapperLayer">
		<titleBar :titleText='pageTitle' :pageForm='"officialNotice"'></titleBar>
		<view class="sortbar-container rowCenBet borderBox">
			<block v-for="(items,index) in sortList" :key="index">
				<view class="sortItems-container rowCenCen" :class="sortCurrent==index?'sortItems-container-active':''" @click="selectSort(index)">
					<view class="sortname">
						{{items.sortname}}
					</view>
					<view class="defIcon directionbox" v-if="index==3">
						<image v-if="sortCurrent!=3 " src="https://cmsstatic.ffquan.cn//wap_new/search/images/sort.svg" mode=""></image>
						<block v-else>
							<image v-if="priceUp" src="https://cmsstatic.ffquan.cn//wap_new/search/images/asce.svg" mode=""></image>
							<image v-else src="https://cmsstatic.ffquan.cn//wap_new/search/images/desc.svg" mode=""></image>
						</block>
					</view>
				</view>
			</block>
		</view>
		<view class="bottomGoodslist-container colCen borderBox">
			<view class="colCen borderBox goodsList-container">
				<view class="listbox colCen borderBox">
					<block v-for="(items,index) in goodsList" :key="index">
						<view class="goods-items" @click="goDetail(items)">
							<rowGoods :items="items"></rowGoods>
						</view>
					</block>
					<aLoadMore :status="loadstatus" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import titleBar from '../../components/backTitlebar.vue';
	import rowGoods from '../../components/rowGoods.vue'
	export default {
		components: {
			titleBar,
			rowGoods
		},
		data(){
			return{
				cid:'',
				priceUp: false,
				sortCurrent:0,
				pageTitle:'',
				sortType:0,
				sortList: [{
						sortname: '人气',
						type: 'mood'
					},
					{
						sortname: '最新',
						type: 'newest'
					},
					{
						sortname: '销量',
						type: 'salesvolume'
					},
					{
						sortname: '价格',
						type: 'price'
					}
				],
				goodsList: [],
				
				canloadmore:false,
				loadstatus:'loading',
				currentPage:1
			}
		},
		onLoad(options) {
			if(options){
				this.cid = options.cid
				this.pageTitle = options.title
			}
			this.getGoodsList()
		},
		onReachBottom() {
			if(this.canloadmore){
				this.getGoodsList()
			}
		},
		methods:{
			getGoodsList() {
				this.$http.post('tb/getGoodsList', {
					subcid: this.cid,
					pageId: this.currentPage,
					pageSize: 10,
					sort: this.sortType,
				}, 'application/json').then((res) => {
					console.log(res, '========>获取底部分类');
					uni.stopPullDownRefresh()
					if (res.goodsList.length < 10) {
						this.loadstatus = 'nomarl'
						this.canloadmore = false
					} else {
						this.loadstatus = 'loading'
						this.canloadmore = true
						this.currentPage++
					}
					this.goodsList = this.goodsList.concat(res.goodsList);
				})
			},
			
			selectSort(idx) {
				this.sortCurrent = idx
				this.currentPage = 1
				this.goodsList = []
				if (idx != 3) {
					if (idx != this.sortType) {
						this.sortType = idx;
					}
				} else {
					this.priceUp = !this.priceUp;
					if (this.priceUp) {
						console.log('true');
						this.sortType = 6
					} else {
						this.sortType = 5
					}
				}
				this.$nextTick(() => {
					this.getGoodsList();
				})
			},
			
			// scrollmorePage() {
			// 	this.$http.post('tb/getGoodsList', {
			// 		cids: this.parentId,
			// 		pageId: this.currentPage,
			// 		pageSize: 10,
			// 		sort: this.sortType,
			// 	}, 'application/json').then((res) => {
			// 		console.log(res, '========>获取底部分类');
			// 		if (res.goodsList.length < 10) {
			// 			this.loadstatus = 'nomarl'
			// 			this.canloadmore = false
			// 		} else {
			// 			this.loadstatus = 'loading'
			// 			this.canloadmore = true
			// 			this.currentPage++
			// 		}
			// 		if (this.currentPage > 1) {
			// 			this.goodsList = this.goodsList.concat(res.goodsList)
			// 		} else {
			// 			this.goodsList = res.goodsList;
			// 		}
			// 	})
			// },
			
			goDetail(info){
				console.log(info);
				uni.navigateTo({
					url: '../goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(info))
				})
			}
		},
		onPullDownRefresh() {
			this.currentPage = 1
			this.goodsList = []
			this.getGoodsList()
		}
	}
</script>

<style lang='scss'>
	.officialNotice{
		width: 100%;
		.sortbar-container {
			z-index: 10;
			position: fixed;
			left: 0;
			width: 100%;
			height: 100rpx;
			background-color: #FFFFFF;
			padding: 0 50rpx;
			border-top: 1rpx solid #F0F1F7;
				
			.sortItems-container {
				width: 90rpx;
				
				.sortname {
					font-size: 24rpx;
					font-weight: 400;
					color: #333333;
				}
				
				.directionbox {
					width: 25rpx;
					height: 35rpx;
					margin-left: 5rpx;
				}
			}
				
			.sortItems-container-active {
				.sortname {
					color: #FF4242;
				}
			}
		}
		.bottomGoodslist-container {
			width: 100%;
			background-color: #FFFFFF;
			margin-top: 120rpx;
		
			.goodsList-container {
				width: 100%;
		
				.listbox {
					width: 100%;
					.goods-items{
						width: 100%;
					}
				}
			}
		}
	}
</style>
