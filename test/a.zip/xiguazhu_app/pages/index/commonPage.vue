<template>
	<view class="commonPage-wrapper wrapperLayer">
		<titleBar :titleText='pageT' :pageForm='"setting"'></titleBar>
		<view class="img_box">
			<image :src="bannerImg" mode="aspectFill"></image>
		</view>
		<view class="list_wrap colCen">
			<view class="content_wrap">
				<view v-for="(item, index) in list" :key="index" class="shangpin_box" @click="goDetails(item)">
					<image :src="item.mainPic"></image>
					<!-- 商品标题 -->
					<view id="title_box">
						<text class="biaoqian" v-if="item.searchSource == 3">京东</text>
						<text class="biaoqian" v-if="item.searchSource == 2">拼多多</text>
						<text class="biaoqian" v-if="item.searchSource == 1">淘宝</text>
						<text class="biaoqian" v-if="item.searchSource == 4">唯品会</text>
						<text class="biaoqian" v-if="item.zy != null">自营</text>
						<text class="title">{{item.dtitle}}</text>
					</view>
					<!-- 优惠卷 -->
					<view class="bq">
						<text class="juan" v-if="item.searchSource!=4">券{{ item.couponPrice }}元</text>
						<text class="juan" v-else>{{ item.discount }}折</text>
						<text class="zhuan">赚{{ item.fanli }}元</text>
					</view>
					<!-- 价格 -->
					<view class="price_box">
						<view class="price">
							<text>￥</text>
							{{ item.actualPrice }}
						</view>
						<view class="history_price">
							<text>￥</text>
							{{ item.originalPrice }}
						</view>
						<view class="sold_out" v-if="item.searchSource!=4">已售{{ item.monthSales }}</view>
					</view>
				</view>
			</view>
			<aLoadMore :status="loadstate" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				platform:0,
				bannerImg: '',
				interface:'',
				list: [],
				
				canload:false,
				loadstate:'loading',
				pageNumber:1
			};
		},
		onLoad(options) {
			console.log(options);
			this.pageT = options.pageTitle
			this.interface = options.interface
			this.platform = options.platform
			this.bannerImg = options.pic
			if(this.platform==0){
				this.pageNumber=1
				this.getjdList()
			}else if(this.platform==1){
				this.pageNumber=0
				this.getpddList()
			}else if (this.platform == 2){
				this.pageNumber=1
				this.getvphList()
			}
		},
		onReachBottom() {
			if(this.canload){
				if(this.platform==0){
					this.getjdList()
				}else if(this.platform==1){
					this.getpddList()
				}else if(this.platform==1){
					this.getvphList()
				}
			}
		},
		onPullDownRefresh() {
			this.list = []
			this.canload = false
			this.loadstate = 'loading'
			if(this.platform==0){
				this.pageNumber = 1
				this.getjdList()
			}else if(this.platform==1){
				this.pageNumber = 0
				this.getpddList()
			}else if(this.platform==1){
				this.pageNumber = 0
				this.getvphList()
			}
		},
		methods: {
			getjdList(){
				this.$http.post('wx/jd/commonApi',{
					pageIndex:this.pageNumber,
					pageSize:20,
					parameter:this.interface
				},'application/json').then(res=>{
					console.log(res);
					uni.stopPullDownRefresh()
					if(res.data.goodsList.length<10){
						this.canload = false
						this.loadstate = 'nomore'
					}else{
						this.canload = true
						this.loadstate = 'loading'
						this.pageNumber++
					}
					this.list=this.list.concat(res.data.goodsList)
				})
			},
			
			getvphList(){
				this.$http.post('wx/vip/getVIPBannerData',{
					page:this.pageNumber,
					pageSize:20,
					channelType:this.interface
				},'application/json').then(res=>{
					console.log(res);
					uni.stopPullDownRefresh()
					if(res.data.goodsList.length<10){
						this.canload = false
						this.loadstate = 'nomore'
					}else{
						this.canload = true
						this.loadstate = 'loading'
						this.pageNumber++
					}
					this.list=this.list.concat(res.data.goodsList)
				})
			},
			
			getpddList(){
				this.$http.post('wx/pdd/homeDataList',{
					pageIndex:this.pageNumber,
					pageSize:20,
					parameter:this.interface
				},'application/json').then(res=>{
					console.log(res,'pdd商品');
					uni.stopPullDownRefresh()
					if(res.goodsList.length<10){
						this.canload = false
						this.loadstate = 'nomore'
					}else{
						this.canload = true
						this.loadstate = 'loading'
						this.pageNumber+=20
					}
					this.list=this.list.concat(res.goodsList)
				})
			},
			
			goDetails(data) {
				uni.navigateTo({
					url: '../goods/goodsDetail?info=' + JSON.stringify(data)
				})
			},
		},
	};
</script>

<style lang="less">

	.ti_shi {
		width: 100%;
		height: 80rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 24rpx;
		font-weight: 500;
		color: #666666;
	}

	.commonPage-wrapper {

		// 顶部图片
		.img_box {
			width: 710rpx;
			height: 280rpx;
			// border: 1px solid;
			margin: 0 auto;
			padding-top: 20rpx;

			image {
				width: 100%;
				height: 100%;
				border-radius: 18rpx;
			}
		}

		//商品列表
		.list_wrap {
			width: 100%;
			padding: 0 20rpx;
			box-sizing: border-box;
			margin-top: 20rpx;

			.content_wrap {
				width: 100%;
				display: flex;
				justify-content: space-between;
				flex-wrap: wrap;

				.shangpin_box {
					width: 345rpx;
					padding-bottom: 20rpx;
					border-radius: 12rpx;
					margin-bottom: 20rpx;
					background-color: #fff;
					overflow: hidden;

					image {
						width: 345rpx;
						height: 336rpx;

					}
				}
			}

			#title_box {
				width: 301rpx;
				margin-left: 21rpx;
				margin-top: 25rpx;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #333333;
				position: relative;

				.biaoqian {
					padding-left: 5rpx;
					padding-right: 5rpx;
					background: linear-gradient(-59deg, #fd1e0d, #fd002f);
					border-radius: 4rpx;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #ffffff;
					margin-right: 10rpx;
					position: absolute;
					top: 1rpx;
					left: 0rpx;
				}

				.title {
					text-indent: 3.5em;
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-line-clamp: 2;
					-webkit-box-orient: vertical;
				}
			}

			.bq {
				margin-left: 21rpx;
				margin-top: 19rpx;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;

				text {
					width: 75rpx;
					height: 30rpx;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #ffffff;
					margin-right: 10rpx;
					padding: 4rpx 13rpx 3rpx 12rpx;
					border-radius: 5rpx;
				}

				.juan {
					background: linear-gradient(255deg, #ff437e, #ff7755);
				}

				.zhuan {
					background: linear-gradient(255deg, #d674fb, #6344f9);
				}
			}

			.price_box {
				// border: 1px solid;
				display: flex;
				align-items: center;
				width: 100%;
				margin-top: 19rpx;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #ff002c;
				font-size: 30rpx;
				// margin-bottom: 50rpx;

				.price {
					margin-left: 10rpx;

					text {
						font-size: 24rpx;
					}
				}

				.history_price {
					margin-left: 10rpx;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 500;
					text-decoration: line-through;
					color: #999999;
				}

				.sold_out {
					margin-left: auto;
					margin-right: 20rpx;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #999999;

				}
			}
		}
	}
</style>
