<template>
	<view class="findGoods-wrapper wrapperLayer">
		<view class="pageNavigationBar-container colCen">
			<view class="topbarbox"></view>
			<view class="headerNavigationbar rowCenBet borderBox">
				<view class="leftuserInfo rowCen">
					<view class="backIcon rowCenSta" @click="backUrl()">
						<image src="../../static/images/home/return.png" mode="aspectFill"></image>
					</view>

					<image class="avator-img" :src="pageInfo.headImg" mode="aspectFill"></image>

					<view class="author-name-box">
						{{pageInfo.userName}}
					</view>

					<view class="follow-btn rowCenCen" @tap='followFnc()'>
						<view>{{followState=='0'?'关注':'已关注'}}</view>
					</view>
				</view>
				
				<!-- <view class="rightshare-btn rowCenCen">
					<view class="iconfont">
						&#xe63c;
					</view>
					<view class="txt">
						分享赚佣金
					</view>
				</view> -->
			</view>
		</view>
		<view class="topbarbox"></view>
		<view class="pagebottom-container pd20 borderBox colCen">
			<view class="worksInfo-container">
				<view class="worksinfo-top-content rowCen">
					<view class="tips-box rowCenCen">
						<view>官方精选</view>
					</view>
					<view class="works-name">
						{{pageInfo.albumName}}
					</view>
				</view>
				<view class="updata-time"  v-text="getTimer(pageInfo.updateTime)">
				</view>
			</view>
			
			<view class="goodsList-container colCen">
				<block v-for="(items,index) in pageInfo.goodsList" :key="index">
					<view class="goodsItems-container rowCen" @tap="goDetail(items)">
						<view class="leftpic defIcon">
							<image :src="items.mainPic" mode="aspectFill"></image>
						</view>
						<view class="right-info-container colCen">
							<view class="goodsnameinfo-content rowSta">
								<view class="typeIcon-content defIcon">
									<image v-if="items.shopType=='0'" src="@/static/images/goods/tbtips.png" mode="heightFix"></image>
									<image v-else src="@/static/images/goods/tmtips.png" mode="heightFix"></image>
								</view>
								<view class="tradename">
									{{items.dtitle}}
								</view>
							</view>
							<view class="disc-info-content rowCen">
								<view v-if="items.specialText.length>0">{{items.specialText[0]}}</view>
								<view v-if="items.specialText.length>1">、{{items.specialText[1]}}</view>
							</view>
							
							<view class="discounts-container rowCen borderBox">
								<view class="coupon-box rowCenCen">
									<view>
										{{items.couponPrice}}元券
									</view>
								</view>
							</view>
							
							<view class="bottomInfo-container rowCenBet">
								<view class="left-price-box">
									<view class="top-price rowCen">
										<view class="nowpirce rowEnd">
											<view class="rmb">
												￥
											</view>
											<view class="num">
												{{items.actualPrice}}
											</view>
										</view>
										
										<s class="original-price">
											￥{{items.originalPrice}}
										</s>
									</view>
									<view class="likeNum">
										{{items.monthSales}}人想买
									</view>
								</view>
								<view class="snapUp-btn rowCenCen">
									<view>速度抢</view>
								</view>
							</view>
						</view>
					</view>
				</block>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				goodslist:[],
				followState:0,
				pageInfo:{},
				shake:true,
				userInfo:''
			}
		},
		onLoad(options) {
			this.albumId = options.id
			this.userInfo = uni.getStorageSync('userInfo');
			this.getPageinfo()
		},
		methods: {
			getPageinfo(){
				this.$http.post('album/getDetail',{
					albumId:this.albumId
				},'',true).then(res=>{
					console.log(res);
					uni.stopPullDownRefresh() 
					this.pageInfo = res;
					if(this.userInfo){
						this.getFollowInfo()
					}
				})
			},
			
			getFollowInfo(){
				this.$http.post('followAlbum/judgment',{
					uid:this.pageInfo.uid
				}).then(res=>{
					console.log(res);
					this.followState = res.isFollow
				})
			},
			
			followFnc(){
				if(this.shake){
					this.shake = false
					this.$http.post(this.followState=='0'?'followAlbum/save':'followAlbum/cancel',{
						uid:this.pageInfo.uid
					},'',true).then(res=>{
						this.shake = true
						if(this.followState == '0'){
							this.followState = '1'
						}else{
							this.followState = '0'
						}
					}).catch(res=>{
						this.shake = true
					})
				}
			},
			
			getTimer(stringTime) {
				if(!stringTime){
					return null
				}
			    var minute = 1000 * 60;
			    var hour = minute * 60;
			    var day = hour * 24;
			    var week = day * 7;
			    var month = day * 30;
			    var time1 = new Date().getTime();//当前的时间戳
			    var time2 = Date.parse(new Date((stringTime.replace(/\-/g, '/'))));//指定时间的时间戳
			    var time = time1 - time2;
			
			    var result = null;
			    if (time < 0) {
			    } else if (time / month >= 1) {
			        result ="更新于" + parseInt(time / month) + "月前";
			    } else if (time / week >= 1) {
			        result ="更新于" + parseInt(time / week) + "周前";
			    } else if (time / day >= 1) {
			        result ="更新于" + parseInt(time / day) + "天前";
			    } else if (time / hour >= 1) {
			        result = "更新于" + parseInt(time / hour) + "小时前";
			    } else if (time / minute >= 1) {
			        result ="更新于" + parseInt(time / minute) + "分钟前";
			    } else {
			        result ="更新于刚刚！";
			    }
			    return result;
			},
			
			goDetail(info) {
				info.searchSource = 1
				uni.navigateTo({
					url: '../goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(info))
				})
			},
			
			
			backUrl() {
				uni.navigateBack({
					delta: 1
				})
			},
		},
		
		onPullDownRefresh() {
			this.getPageinfo()
		}
	}
</script>

<style lang="scss">
	.findGoods-wrapper {
		width: 100%;

		.pageNavigationBar-container {
			width: 100%;
			position: fixed;
			top: 0;
			left: 0;
			z-index: 100;
			background-color: #FFFFFF;

			.headerNavigationbar {
				width: 100%;
				height: 100rpx;
				padding: 0 32rpx;

				.leftuserInfo {
					.backIcon {
						width: 32rpx;
						height: 32rpx;

						image {
							width: 17rpx;
							height: 32rpx;
						}
					}

					.avator-img {
						width: 62rpx;
						height: 62rpx;
						border-radius: 50%;
						margin-left: 30rpx;
					}

					.author-name-box {
						font-size: 28rpx;
						font-weight: bold;
						color: #333333;
						margin-left: 25rpx;
					}

					.follow-btn {
						width: 107rpx;
						height: 49rpx;
						background: #FFFFFF;
						border: 1rpx solid #E7E7E7;
						border-radius: 24rpx;
						font-size: 28rpx;
						font-weight: 500;
						color: #999999;
						margin-left: 20rpx;
					}
				}
				
				.rightshare-btn{
					width: 196rpx;
					height: 48rpx;
					background: linear-gradient(0deg, #F5501D, #F6541E);
					border-radius: 24rpx;
					font-size: 28rpx;
					font-weight: 500;
					color: #FFFFFF;
				}
			}
		}
		
		.pagebottom-container{
			width: 100%;
			margin-top: 130rpx;
			.worksInfo-container{
				width: 100%;
				.worksinfo-top-content{
					width: 100%;
					.tips-box{
						width: 104rpx;
						height: 34rpx;
						background: #FE0F4A;
						border-radius: 4rpx;
						font-size: 24rpx;
						font-weight: 500;
						color: #FFFEFE;
					}
					.works-name{
						font-size: 28rpx;
						font-weight: 500;
						color: #333333;
						margin-left: 30rpx;
					}
				}
				.updata-time{
					font-size: 22rpx;
					font-weight: 500;
					color: #999999;
					margin-top: 15rpx;
				}
			}
			
			.goodsList-container{
				width: 100%;
				margin-top: 20rpx;
				.goodsItems-container{
					width: 100%;
					height: 262rpx;
					background: #FFFFFF;
					border-radius: 16rpx;
					padding: 0 10rpx;
					margin-bottom: 20rpx;
					.leftpic{
						width: 222rpx;
						height: 222rpx;
						border-radius: 8rpx;
						overflow: hidden;
					}
					.right-info-container{
						width: 450rpx;
						margin-left: 20rpx;
						.goodsnameinfo-content {
							width: 100%;
							margin-bottom: 15rpx;
						
							.typeIcon-content {
								width: 60rpx;
								height: 24rpx;
								margin-right: 5rpx;
								margin-top: 8rpx;
							}
						
							.tradename {
								width: 400rpx;
								overflow: hidden;
								text-overflow: ellipsis;
								white-space: nowrap;
								font-size: 28rpx;
								font-weight: 400;
								color: #333333;
							}
						}
						
						.disc-info-content{
							width: 100%;
							height: 30rpx;
							margin-bottom: 25rpx;
							font-size: 28rpx;
							font-weight: 500;
							color: #FE3738;
							view{
								overflow: hidden;
								text-overflow: ellipsis;
								white-space: nowrap;
							}
						}
						
						.discounts-container {
							width: 100%;
							margin-bottom: 20rpx;
						
							.coupon-box {
								width: 102rpx;
								height: 30rpx;
								background: url(../../static/images/goods/couponbac.png)no-repeat;
								background-size: 100% 100%;
								font-size: 20rpx;
								font-weight: 500;
								color: #FF4242;
							}
						}
						
						.bottomInfo-container{
							width: 100%;
							.left-price-box {
								.top-price{
									.nowpirce{
										.rmb {
											font-size: 24rpx;
											font-weight: 600;
											color: #FF4242;
											line-height: 30rpx;
										}
										.num{
											font-size: 30rpx;
											line-height: 34rpx;
											font-weight: bold;
											color: #FF4242;
										}
									}
									.original-price {
										font-size: 24rpx;
										font-weight: 400;
										color: #999999;
										margin-left: 15rpx;
										line-height: 30rpx;
									}
								}
								.likeNum{
									font-size: 24rpx;
									font-weight: 500;
									color: #666666;
									margin-top: 20rpx;
								}
							}
							
							.snapUp-btn{
								width: 104rpx;
								height: 44rpx;
								background: linear-gradient(0deg, #E00604, #F85C21);
								border-radius: 8rpx;
								font-size: 28rpx;
								font-weight: 500;
								color: #FFFFFF;
							}
						}
					}
				}
			}
		}
	}
</style>
