<template>
	<view class="searchResult wrapperLayer">
		<view class="backTitlebar-wrapper colCen borderBox">
			<view class="fixedBox">
				<view class="topbarbox"></view>
				<view>
					<view class="headerNavigationbar rowCenBet borderBox">
						<view class="leftContent rowCen">
							<view class="backIcon rowCenSta" @click="backUrl()">
								<image src="@/static/images/home/return.png" mode=""></image>
							</view>
							<view class="search-container rowCenCen borderBox" @click="gosearch()">
								<view>{{searchText}}</view>
							</view>
						</view>
						<view class="typeSetting-btn defIcon" @click="changeSet()">
							<image v-if="rowset" src="../../static/images/goods/row.png" mode=""></image>
							<image v-else src="../../static/images/goods/col.png" mode=""></image>
						</view>
					</view>
				</view>
				<view class="onlineStore-container rowCen">
					<view class="onlineStoreList rowSta" v-if="!showtar || platform!='iOS'">
						<block v-for="(items,index) in onlineStoreList" :key="index">
							<view class="store-items colCen" :class="storeCurrent==index?'store-items-active':''" @click="checkstore(index)">
								<view class="store-name">
									{{items.name}}
								</view>
								<view class="bordercontent"></view>
							</view>
						</block>
					</view>
				</view>
				<view class="sortbar-container rowCenBet borderBox">
					<block v-for="(items,index) in sortList" :key="index">
						<view class="sortItems-container rowCenCen" :class="sortCurrent==index?'sortItems-container-active':''" @click="selectSort(index)">
							<view class="sortname">
								{{items.sortname}}
							</view>
							<view class="defIcon directionbox" v-if="index==2">
								<image v-if="sortCurrent!=2 " src="https://cmsstatic.ffquan.cn//wap_new/search/images/sort.svg" mode=""></image>
								<block v-else>
									<image v-if="saleUp" src="https://cmsstatic.ffquan.cn//wap_new/search/images/asce.svg" mode=""></image>
									<image v-else src="https://cmsstatic.ffquan.cn//wap_new/search/images/desc.svg" mode=""></image>
								</block>
							</view>
						</view>
					</block>
					<view class="couponSort colCen" v-if="storeCurrent>0 && storeCurrent!=3">
						<view class="leftContent rowCen" @click="couponClick()">
							<view v-if="selectCoupon" class="defIcon icon-box">
								<image src="../../static/images/home/select.png" mode="aspectFill"></image>
							</view>
							<view class="nocoupon" v-else></view>
							<view class="textContent">
								优惠券
							</view>
						</view>
					</view>
					<view class="couponSort colCen" v-if="storeCurrent==1">
						<view class="leftContent rowCen" @click="selfsupportClick()">
							<view v-if="selfsupport" class="defIcon icon-box">
								<image src="../../static/images/home/select.png" mode="aspectFill"></image>
							</view>
							<view class="nocoupon" v-else></view>
							<view class="textContent">
								自营
							</view>
						</view>
					</view>
				</view>
			</view>
			<view class="placeBox">
				<view class="topbarbox"></view>
				<view class="placeemptybox"></view>
			</view>
		</view>


		<view class="pageContent-container colCen">
			<view class="advert-container colCenCen borderBox" v-if="advertList.length>0">
				<swiper class="picbox" :autoplay="true" :interval="3000" :duration="1000">
					<swiper-item v-for="(items,index) in advertList" :key="index">
						<view class="picbox defIcon" @tap='goUrl(items)'>
							<image :src="items.pic" mode="aspectFill"></image>
						</view>
					</swiper-item>
				</swiper>
			</view>

			<view class="goodsList-container" :style="'background-color:'+(rowset?'':'#fff')">

				<!-- 竖排版 -->
				<view class="goods-content rowStaBet" v-if="rowset">
					<block v-for="(items,index) in goodsList" :key='index'>
						<view class="goods-items" @click="goDetail(items)">
							<colGoods :items="items"></colGoods>
						</view>
					</block>
				</view>

				<!-- 横排版 -->
				<view class="colSetting-container colCen" v-else>
					<view class="listbox colCen borderBox">
						<block v-for="(items,index) in goodsList" :key="index">
							<view class="goods-items" @click="goDetail(items)">
								<rowGoods :items="items"></rowGoods>
							</view>
						</block>
					</view>
				</view>
			</view>
			<aLoadMore :status="loadstatus" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
		</view>

		<!-- pdd -->
		<u-popup v-model="pddempowerModel" mode="center" border-radius="12">
			<pddEmpower @closemodel='closeMdl'></pddEmpower>
		</u-popup>
	</view>
</template>

<script>
	import utils from '../../utils/utils.js'
	import colGoods from '../../components/colGoods.vue'
	import rowGoods from '../../components/rowGoods.vue'
	import pddEmpower from '../../components/pddempower.vue'
	export default {
		components: {
			colGoods,
			rowGoods,
			pddEmpower
		},
		data() {
			return {
				memberId: '',
				showtar: false,
				pddempowerModel: false,

				searchText: '',
				storeCurrent: '',
				sortCurrent: '',
				rowset: false,
				advertPic: '',
				onlineStoreList: [{
						name: '淘宝',
						type: 'tb'
					},
					{
						name: '京东',
						type: 'jd'
					},
					{
						name: '拼多多',
						type: 'pdd'
					},
					{
						name: '唯品会',
						type: 'wph'
					}
				],

				sortList: [{
						sortname: '人气',
					},
					{
						sortname: '销量',
					},
					{
						sortname: '价格',
					}
				],
				saleUp: false,
				sortType: 'renqi',
				selectCoupon: false,
				selfsupport: false,


				goodsList: [],
				advertList: [],
				loadstatus: 'loading',
				canloadmore: false,

				platform: '',
				currentPage: 1,
			}
		},
		onLoad(options) {
			if (getApp().globalData.userInfo.memberId) {
				this.memberId = getApp().globalData.userInfo.memberId
			}
			// #ifdef APP-PLUS
			this.showtar = getApp().globalData.appinfo.iosExamine ? true : (getApp().globalData.ifwt == 0 ? false : true)			
			this.platform = plus.os.name
			// #endif
			this.searchText = options.searchText
			if (options.storetype) {
				if (options.storetype == 2) {
					this.checkstore(2)
				} else {
					this.storeCurrent = options.storetype
					this.$nextTick(() => {
						if (this.storeCurrent == 0) {
							this.getTbData()
						} else if (this.storeCurrent == 1) {
							this.getJdData()
						} else if (this.storeCurrent == 2) {
							this.getPddData()
						} else if (this.storeCurrent == 3) {
							this.getWphData()
						}
					})
				}
			}
			this.getbanner()
		},

		onReachBottom() {
			if (this.canloadmore) {
				if (this.storeCurrent == 0) {
					this.getTbData()
				} else if (this.storeCurrent == 1) {
					this.getJdData()
				} else if (this.storeCurrent == 2) {
					this.getPddData()
				} else if (this.storeCurrent == 3) {
					this.getWphData()
				}
			}
		},

		methods: {
			getTbData() {
				this.$http.post('tb/taobaoSuperSearch', {
					keyWords: this.searchText,
					memberId: this.memberId,
					pageId: this.currentPage,
					pageSize: 10,
					sort: this.sortType,
				}, 'application/json').then(res => {
					console.log(res.goodsList, '=========>淘宝商品搜索结果');
					uni.stopPullDownRefresh();
					if (res.goodsList.length < 10) {
						this.canloadmore = false
						this.loadstatus = 'nomarl'
					} else {
						this.currentPage++
						this.canloadmore = true
						this.loadstatus = 'loading'
					}
					if (this.currentPage > 1) {
						this.goodsList = this.goodsList.concat(res.goodsList)
					} else {
						this.goodsList = res.goodsList
					}
				})
			},

			getJdData() {
				this.$http.post('jd/superSearch', {
					keyword: this.searchText,
					memberId: this.memberId,
					pageIndex: this.currentPage,
					owner: this.selfsupport ? 'g' : '',
					pageSize: 10,
					sort: this.sortType
				}, 'application/json').then((res) => {
					console.log(res, '=========>京东商品搜索结果');
					uni.stopPullDownRefresh();
					if (res.length < 10) {
						this.canloadmore = false
						this.loadstatus = 'nomarl'
					} else {
						this.currentPage++
						this.canloadmore = true
						this.loadstatus = 'loading'
					}
					if (this.currentPage > 1) {
						this.goodsList = this.goodsList.concat(res)
					} else {
						this.goodsList = res
					}
				})
			},

			getPddData() {
				this.$http.post('pddgoods/superSearch', {
					keyWords: this.searchText,
					memberId: this.memberId,
					pageId: this.currentPage,
					withCoupon: this.selectCoupon,
					pageSize: 10,
					sort: this.sortType
				}, 'application/json').then((res) => {
					console.log(res, '=========>拼多多商品搜索结果');
					uni.stopPullDownRefresh();
					if (res.goodsList.length < 10) {
						this.canloadmore = false
						this.loadstatus = 'nomarl'
					} else {
						this.currentPage++
						this.canloadmore = true
						this.loadstatus = 'loading'
					}
					if (this.currentPage > 1) {
						this.goodsList = this.goodsList.concat(res.goodsList)
					} else {
						this.goodsList = res.goodsList
					}
				})
			},

			getWphData() {
				this.$http.post('vip/query', {
					keyword: this.searchText,
					page: this.currentPage,
					pageSize: 10,
					sort: this.sortType
				}, 'application/json').then((res) => {
					console.log(res, '=========>唯品会');
					uni.stopPullDownRefresh();
					if (res.length < 10) {
						this.canloadmore = false
						this.loadstatus = 'nomarl'
					} else {
						this.currentPage++
						this.canloadmore = true
						this.loadstatus = 'loading'
					}

					if (this.currentPage > 1) {
						this.goodsList = this.goodsList.concat(res)
					} else {
						this.goodsList = res
					}
				})
			},


			gosearch() {
				uni.redirectTo({
					url: './search?type=' + this.storeCurrent + '&searchText=' + this.searchText
				})
			},

			goUrl(info) {
				utils.goUrl(info)
			},

			couponClick() {
				this.currentPage = 1
				this.goodsList = []
				this.selectCoupon = !this.selectCoupon
				if (this.storeCurrent == 0) {
					this.getTbData()
				} else if (this.storeCurrent == 1) {
					this.getJdData()
				} else if (this.storeCurrent == 2) {
					this.getPddData()
				} else if (this.storeCurrent == 3) {
					this.getWphData()
				}
			},

			selfsupportClick() {
				this.currentPage = 1
				this.goodsList = []
				this.selfsupport = !this.selfsupport
				this.getJdData()
			},

			getbanner() {
				this.$http.get('banner/list/0').then((res) => {
					console.log(res, '=========>广告数据');
					this.advertList = res
					this.advertPic = res[0].pic
				})
			},

			selectSort(idx) {
				this.sortCurrent = idx
				this.currentPage = 1
				this.goodsList = []
				if (idx == 0) {
					this.sortType = 'renqi'
				} else if (idx == 1) {
					this.sortType = 'total_sales_des'
				} else if (idx == 2) {
					this.saleUp = !this.saleUp
					if (this.saleUp) {
						this.sortType = 'price_asc'
					} else {
						this.sortType = 'price_des'
					}
				}


				this.$nextTick(() => {
					if (this.storeCurrent == 0) {
						this.getTbData()
					} else if (this.storeCurrent == 1) {
						this.getJdData()
					} else if (this.storeCurrent == 2) {
						this.getPddData()
					} else if (this.storeCurrent == 3) {
						this.getWphData()
					}
				})
			},

			checkstore(idx) {
				if (idx == 2) {
					const value = uni.getStorageSync('userInfo');
					console.log(value)
					if (value) {
						this.updataUser(idx)
					} else {
						uni.navigateTo({
							url: '../login/login'
						})
					}
				} else {
					this.storeCurrent = idx
					this.loadstatus = 'loading'
					this.canloadmore = false
					this.sortType = 'renqi'
					this.currentPage = 1
					this.sortCurrent = 0
					this.selectCoupon = false
					this.selfsupport = false
					this.goodsList = []
					this.$nextTick(() => {
						if (this.storeCurrent == 0) {
							this.getTbData()
						} else if (this.storeCurrent == 1) {
							this.getJdData()
						} else if (this.storeCurrent == 2) {
							this.getPddData()
						} else if (this.storeCurrent == 3) {
							this.getWphData()
						}
					})
				}
			},

			closeMdl() {
				this.pddempowerModel = false
			},

			updataUser(idx) {
				this.userInfo = utils.getCacheSync('userData')
				this.$http.get('member/getInfo').then((res) => {
					console.log(res, '========>获取用户信息');
					this.userInfo = res
					utils.setCache('userData', res)
					if (this.userInfo.pddAuthority == 1) {
						this.storeCurrent = idx
						this.loadstatus = 'loading'
						this.canloadmore = false
						this.sortType = 'renqi'
						this.currentPage = 1
						this.sortCurrent = 0
						this.selectCoupon = false
						this.selfsupport = false
						this.goodsList = []
						this.$nextTick(() => {
							this.getPddData()
						})
					} else {
						this.$http.get('pddgoods/checkPddAuth').then(res => {
							console.log(res);
							if (res.isAuth == 1) {
								this.storeCurrent = idx
								this.sortType = 'renqi'
								this.currentPage = 1
								this.sortCurrent = 0
								this.selectCoupon = false
								this.selfsupport = false
								this.goodsList = []
								this.$nextTick(() => {
									this.getPddData()
								})
							} else {
								this.pddempowerModel = true
								this.storeCurrent = 0
								this.loadstatus = 'loading'
								this.canloadmore = false
								this.sortType = 'renqi'
								this.currentPage = 1
								this.sortCurrent = 0
								this.selectCoupon = false
								this.selfsupport = false
								this.goodsList = []
								this.getTbData()
							}
						})
					}
				})
			},


			changeSet() {
				// 切换排版
				this.rowset = !this.rowset
				this.currentPage = 1
			},

			backUrl() {
				uni.navigateBack({
					delta: 1
				})
			},
			goDetail(info) {
				uni.navigateTo({
					url: '../goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(info))
				})
			}
		},
		onPullDownRefresh() {
			this.currentPage = 1
			this.goodsList = []
			if (this.storeCurrent == 0) {
				this.getTbData()
			} else if (this.storeCurrent == 1) {
				this.getJdData()
			} else if (this.storeCurrent == 2) {
				this.getPddData()
			} else if (this.storeCurrent == 3) {
				this.getWphData()
			}
		}
	}
</script>

<style lang="scss">
	.searchResult {
		.backTitlebar-wrapper {
			.placeBox {
				.placeemptybox {
					height: 230rpx;
				}
			}

			.fixedBox {
				width: 100%;
				position: fixed;
				top: 0;
				left: 0;
				z-index: 100;
				background-color: #FFFFFF;

				.headerNavigationbar {
					width: 100%;
					height: 90rpx;
					padding: 0 32rpx;

					.leftContent {
						.backIcon {
							width: 40rpx;
							height: 32rpx;
							z-index: 1;

							image {
								width: 17rpx;
								height: 32rpx;
							}
						}

						.search-container {
							width: 554rpx;
							height: 60rpx;
							border-radius: 30rpx;
							background: #F7F7F7;

							view {
								width: 554rpx;
								font-size: 28rpx;
								padding: 0 32rpx;
								font-weight: 400;
								text-overflow: ellipsis;
								white-space: nowrap;
								overflow: hidden;
							}
						}
					}

					.typeSetting-btn {
						width: 65rpx;
						height: 35rpx;

						image {
							width: 35rpx;
							height: 35rpx;
						}
					}
				}

				.onlineStore-container {
					width: 100%;
					height: 80rpx;
					background-color: #FFFFFF;
					padding: 0 32rpx;

					.onlineStoreList {
						width: 100%;
						height: 100%;

						.store-items {
							margin-right: 60rpx;

							.store-name {
								font-size: 28rpx;
								font-weight: 500;
								color: #999999;
								margin-top: 20rpx;
							}

							.bordercontent {
								width: 30rpx;
								height: 4rpx;
								margin-top: 10rpx;
								border-radius: 2rpx;
								background-color: transparent;
							}
						}

						.store-items-active {
							.store-name {
								font-size: 32rpx;
								font-weight: 500;
								color: #FF4242;
							}

							.bordercontent {
								width: 30rpx;
								height: 4rpx;
								background-color: #FF4242;
							}
						}
					}
				}

				.sortbar-container {
					z-index: 10;
					position: fixed;
					left: 0;
					width: 100%;
					height: 80rpx;
					background-color: #FFFFFF;
					padding: 0 50rpx;

					.sortItems-container {
						width: 90rpx;

						.sortname {
							font-size: 28rpx;
							font-weight: 400;
							color: #333333;
						}

						.directionbox {
							width: 25rpx;
							height: 35rpx;
							margin-left: 5rpx;
						}
					}

					.sortItems-container-active {
						.sortname {
							color: #FF4242;
						}
					}

					.couponSort {
						.leftContent {
							.nocoupon {
								width: 30rpx;
								height: 30rpx;
								background: #FFFFFF;
								border: 1rpx solid #BFBFBF;
								border-radius: 50%;
								margin-right: 10rpx;
							}

							.icon-box {
								width: 30rpx;
								height: 30rpx;
								margin-right: 10rpx;
							}

							.textContent {
								font-size: 28rpx;
								font-weight: 400;
								color: #333333;
							}
						}
					}
				}
			}
		}

		.pageContent-container {
			width: 100%;

			.advert-container {
				width: 100%;
				height: 200rpx;
				background-color: #FFFFFF;
				box-shadow: 0px -1rpx 0px 0px #EFF1F7;
				padding: 0 32rpx;

				.picbox {
					width: 100%;
					height: 160rpx;
					border-radius: 12rpx;
					overflow: hidden;
				}
			}

			.goodsList-container {
				width: 100%;
				margin-top: 20rpx;
				// background-color: #FFFFFF;

				.goods-content {
					width: 100%;
					padding: 0 20rpx;
					flex-wrap: wrap;

					.goods-items {
						width: 346rpx;
						height: 526rpx;
						margin-bottom: 20rpx;
					}
				}

				.colSetting-container {
					width: 100%;

					.listbox {
						width: 100%;

						.goods-items {
							width: 100%;
						}
					}
				}
			}
		}
	}
</style>
