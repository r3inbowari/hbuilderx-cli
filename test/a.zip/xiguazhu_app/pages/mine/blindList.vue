<template>
	<view class="blindList-wrapper wrapperLayer">
		<view class="fixedBox">
			<view class="topbarbox"></view>
			<view class="headerNavigationbar rowCenBet borderBox">
				<view class="backIcon rowCenSta" @click="backUrl()">
					<image src="../../static/images/home/returnWhite.png" mode="aspectFill"></image>
				</view>
				<view class="pageTitle">
					盲盒商品列表
				</view>
				<view class="emptybox rowCenEnd">
				</view>
			</view>
		</view>
		<view class="placeBox">
			<view class="topbarbox"></view>
			<view class="placeemptybox">
			</view>
		</view>
		<view class="box-list-content rowCenBet borderBox">
			<block v-for="(items,index) in gifts" :key="index">
				<view class="goods-items colCen borderBox">
					<image class="itempic" :src="items.img" mode="aspectFill"></image>
					<view class="itemtit">
						{{items.title}}
					</view>
					<view class="abstips rowCenCen">
						<view>{{items.label}}</view>
					</view>
				</view>
			</block>
		</view>

		<view class="rules-title rowCenCen">
			<view class="heng"></view>
			<view class="tit">规则</view>
			<view class="heng"></view>
		</view>

		<view class="rules-content rowCenCen borderBox">
			<view class="content-txt borderBox" v-html="content">
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				id: '',
				gifts:[],
				content:''
			}
		},
		onLoad(options) {
			console.log(options.id);
			this.id = options.id
			this.getPageData()
			this.getxieyi()
		},
		onPullDownRefresh(){
			this.getPageData()
		},
		methods: {
			getPageData() {
				this.$http.post('blindBox/blindBoxGoodsList', {
					"blindBoxId": this.id,
					"limit": 30,
					"offset": 0
				},'application/json').then(res => {
					console.log(res);
					uni.stopPullDownRefresh()
					this.gifts = res
				})
			},
			
			getxieyi(){
				this.$http.get('agreement/list/6').then(res=>{
					console.log(res);
					this.content = res.content
				})
			},

			backUrl() {
				uni.navigateBack({
					delta: 1
				})
			},
		}
	}
</script>

<style lang="scss">
	.blindList-wrapper {
		width: 100%;
		min-height: 100vh;
		background-color: #C373FF;

		.placeBox {
			.placeemptybox {
				height: 90rpx;
			}
		}

		.fixedBox {
			width: 100%;
			position: fixed;
			top: 0;
			left: 0;
			z-index: 100;
			background-color: #A542EF;

			.headerNavigationbar {
				width: 100%;
				height: 90rpx;
				padding: 0 32rpx;

				.backIcon {
					width: 60rpx;
					height: 32rpx;
					z-index: 1;

					image {
						width: 17rpx;
						height: 32rpx;
					}
				}

				.pageTitle {
					font-size: 34rpx;
					font-weight: 500;
					color: #FFFFFF;
				}

				.emptybox {
					width: 60rpx;
					height: 32rpx;
				}
			}
		}

		.box-list-content {
			width: 100%;
			flex-wrap: wrap;
			padding: 0 26rpx;

			.goods-items {
				width: 344rpx;
				height: 344rpx;
				background: #FFFFFF;
				border-radius: 16rpx;
				margin-top: 20rpx;
				padding: 8rpx;
				position: relative;

				.itempic {
					width: 100%;
					height: 252rpx;
					border-radius: 8rpx;
				}

				.itemtit {
					font-size: 28rpx;
					font-weight: 500;
					color: #333333;
					margin-top: 25rpx;
				}

				.abstips {
					position: absolute;
					top: 8rpx;
					left: 8rpx;
					width: 134rpx;
					height: 44rpx;
					background: #FF3F60;
					border-radius: 8rpx 0px 8rpx 0px;
					font-size: 24rpx;
					font-weight: 500;
					color: #FFFFFF;
				}
			}
		}

		.rules-title {
			width: 100%;
			margin-top: 80rpx;
			margin-bottom: 30rpx;

			.heng {
				width: 70rpx;
				height: 2rpx;
				border-radius: 2rpx;
				background-color: #FFFFFF;
			}

			.tit {
				font-size: 30rpx;
				font-weight: bold;
				color: #FFFFFF;
				margin: 0 20rpx;
			}
		}

		.rules-content {
			width: 100%;
			padding: 0 26rpx;
			margin-bottom: 50rpx;

			.content-txt {
				width: 100%;
				background: #A542EF;
				border-radius: 16rpx;
				font-size: 24rpx;
				font-weight: 500;
				color: #FFFFFF;
				padding: 30rpx 24rpx;
			}
		}
	}
</style>
