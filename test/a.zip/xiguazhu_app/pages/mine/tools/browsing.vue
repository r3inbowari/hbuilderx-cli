<template>
	<view class="browsing-wrapper colCen wrapperLayer">
		<titleBar :titleText='"浏览足迹"' :pageForm='"browsing"' @cleanAll="clean"></titleBar>

		<view class="colCen browsingGoodslist borderBox">
			<view class="goodslist-wrapper borderBox rowCenBet">
				<view class="goods-items borderBox colCen" v-for="(items,index) in goodsList" :key='index' @click="goDetail(items)">
					<colGoods :items='items'></colGoods>
				</view>
				<view class="empty-container colCenCen" style="width: 100%;height: 100%;margin-top: 30vh;" v-if="loadstatus=='nomarl' && goodsList.length==0">
					<view class="defIcon" style="width: 200rpx; height: 200rpx;" >
						<image src="../../../static/images/goods/empty.png" mode="aspectFill"></image>
					</view>
					<view class="texttips" style="margin-top: 40rpx; font-size: 28rpx;font-weight: 400;color: #666666;width: 100%; text-align: center;">
						您还没有浏览过商品哦~
					</view>
				</view>
				<view style="width: 100%;" v-else>
					<aLoadMore :status="loadstatus" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
				</view>
			</view>
		</view>
		
		<u-modal v-model="showModel" :show-title="false" :show-cancel-button="true" :content="'确定要清空浏览记录嘛？'" @confirm="confirm" :async-close="true"></u-modal>
	</view>
</template>

<script>
	import colGoods from '../../../components/colGoods.vue'
	export default {
		components: {
			colGoods
		},
		data() {
			return {
				goodsList: [],
				loadstatus: 'loading',
				currentPage: 0,
				showModel: false,
				canloadMore: false
			}
		},
		onLoad() {
			this.getData();
		},
		onReachBottom() {
			if (this.canloadMore) {
				this.getData()
			}
		},
		methods: {
			getData() {
				this.$http.post('browsingHistory/getList', {
					limit: 10,
					offset: this.currentPage
				}, 'application/json').then((res) => {
					console.log(res, '=========>浏览足迹');
					uni.stopPullDownRefresh()
					if (res.length < 10) {
						this.loadstatus = 'nomarl'
						this.canloadMore = false
					} else {
						this.currentPage+=10
						this.loadstatus = 'loading'
						this.canloadMore = true
					}

					if (this.currentPage > 0) {
						this.goodsList = this.goodsList.concat(res)
					} else {
						this.goodsList = res
					}
				})
			},
			goDetail(info) {
				uni.navigateTo({
					url: '../../goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(info))
				})
			},
			clean(){
				this.showModel = true
			},
			confirm(){
				this.$http.post('browsingHistory/cancelBrowsing').then(res=>{
					this.showModel = false
					this.goodsList = []
				})
			}
		},
		onPullDownRefresh() {
			this.currentPage = 0
			this.goodsList = []
			this.getData()
		}
	}
</script>

<style lang="scss">
	.browsing-wrapper {
		width: 100%;
	}

	.browsingGoodslist {
		width: 100%;
		margin-top: 20rpx;

		.goodslist-wrapper {
			width: 100%;
			padding: 0 20rpx;
			flex-wrap: wrap;

			.goods-items {
				margin-bottom: 20rpx;
			}
		}
	}
</style>
