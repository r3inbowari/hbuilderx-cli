<template>
	<view class="turnChain-wrapper wrapperLayer">
		<titleBar :titleText='"转链工具"' :pageForm='"turnChain"'></titleBar>
		<view class="page-fixed colCen">
			<view class="topbarbox"></view>
			<view class="notice-bar-container rowCen">
				<view class="horn iconfont">
					&#xe64c;
				</view>
				<view class="notice-txt">
					<view class="txt-box">
						通过转链后的链接所产生的订单才能进入您的佣金中哦~
					</view>
				</view>
			</view>

			<view class="platform-bar-container">
				<scroll-view class="plat-scrollview" scroll-x scroll-with-animation>
					<block v-for="(items,index) in platformList">
						<view class="plat-items" :class="platCurrent==items.type?'plat-active':''" @tap="platclk(items.type,items.platxt)">
							<view class="items-content rowCenCen">
								<view>{{items.label}}</view>
							</view>
						</view>
					</block>
				</scroll-view>
			</view>
		</view>

		<view class="pageContent-container colCen">
			<view class="turn-container colCen">
				<view class="content-title rowCenBet">
					<view class="left-txt rowCenCen">
						<image v-if="backstate==1" src="../../../static/images/mine/scu.png" mode=""></image>
						<image v-if="backstate==2" src="../../../static/images/mine/warn.png" mode=""></image>
						<view :style="backstate==0?'':(backstate==1?'color:#1ED772':'color:#FE3738')">{{backstate==0?'待转换链接':(backstate==1?'转链成功':'转链失败')}}</view>
					</view>
					<view class="clean-btn" @tap="clean()">
						清空
					</view>
				</view>
				<view class="textarea-bac colCen">
					<textarea class="txtstyle" :maxlength='-1' v-model="txtarea" :placeholder="platxt" />
					<view class="bottom-bar rowCenEnd">
						<view @tap="paste()">粘贴</view>
					</view>
				</view>
			</view>
			
			<view class="btn-container rowCen">
				<view class="btn-box rowCenCen" v-if="backstate==1" @tap="copy()">
					复制链接
				</view>
				<view class="btn-box rowCenCen" v-else @tap="turnChain()">
					一键转换成我的链接
				</view>
			</view>
			
			<image class="jcpic" src="https://hxshapp.oss-cn-beijing.aliyuncs.com/app/img/20210123/zhuanlian.png" mode="widthFix"></image>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				platCurrent: 1,
				platxt:'1.请粘贴您需要转换的淘宝文案/链接和淘口令/淘宝商品链接;不支持券链接\n2.多个链接粘贴在一起会导致识别失败,失败后,请单个链接转链\n3.若内容存在无法识别的文本,转链失败以后,可尝试分批转换',
				txtarea:'',
				backstate:0,
				platformList: [{
						label: '淘宝',
						type: 1,
						platxt:'1.请粘贴您需要转换的淘宝文案/链接和淘口令/淘宝商品链接;不支持券链接\n2.多个链接粘贴在一起会导致识别失败,失败后,请单个链接转链\n3.若内容存在无法识别的文本,转链失败以后,可尝试分批转换'
					},
					{
						label: '京东',
						type: 2,
						platxt:'1.可以是商品链接+文案、活动链接+文案、店铺链接+文案，例如：https://item.jd.com/100007926326.html 或哈密瓜5斤，9.9元https://u.jd.com/wKEHUQX\n2.特殊符号可会导致识别失败,失败后,请修改文案后再次转链 '
					},
					{
						label: '拼多多',
						type: 3,
						platxt:'1.可以是商品链接、商品id 例如：https://p.pinduoduo.com/vgKyBIXv\n2.每次仅支持单个链接转链'
					},
					{
						label: '唯品会',
						type: 4,
						platxt:'1.可以是商品链接、活动链接、例如：https://detail.vip.com/detail-1710613695-6919024311620373535.html\n2.多个链接粘贴在一起会导致识别失败,失败后,请单个链接转链    '
					}
					// {
					// 	label:'苏宁'
					// },
					// {
					// 	label:'唯品会'
					// }
				],
			}
		},
		watch:{
			txtarea(){
				this.backstate = 0
			}
		},
		methods:{
			platclk(type,txt){
				this.platCurrent = type
				this.platxt = txt
				this.backstate = 0 
				this.txtarea = ''
			},
			turnChain(){
				this.$http.post('tb/zhuanLianTool',{
					content:this.txtarea,
					type:this.platCurrent
				},'application/json',true).then(res=>{
					console.log(res);
					this.txtarea = res
					this.$nextTick(()=>{
						this.backstate = 1
					})
				}).catch(res=>{
					this.$nextTick(()=>{
						this.backstate = 2
					})
				})
			},
			clean(){
				this.txtarea = ''
				this.backstate = 0
			},
			paste(){
				uni.getClipboardData({
					success:res=>{
						console.log(res);
						this.txtarea = res.data
					}
				})
			},
			copy(){
				uni.setClipboardData({
					data: this.txtarea,
					success:()=> {
						uni.showToast({
							icon:'none',
							title:'复制成功！'
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.turnChain-wrapper {
		width: 100%;

		.page-fixed {
			width: 100%;
			position: fixed;
			top: 90rpx;
			z-index: 5;

			.notice-bar-container {
				width: 100%;
				height: 50rpx;
				background: #FEF9F6;

				.horn {
					font-size: 22rpx;
					font-weight: 500;
					color: #FE3738;
					margin-left: 20rpx;
					white-space: nowrap;
				}

				.notice-txt {
					position: relative;
					width: 100%;
					height: 50rpx;
					padding-left: 30rpx;
					overflow: hidden;

					.txt-box {
						position: absolute;
						height: 50rpx;
						line-height: 50rpx;
						white-space: nowrap;
						font-size: 22rpx;
						font-weight: 500;
						color: #FE3738;
						animation: slideLeft calc(var(--left)/30*1s) linear infinite;
					}

					@keyframes slideLeft {
						0% {
							left: 0rpx;
						}

						100% {
							left: calc(0rpx - (var(--left))*1rpx)
						}
					}
				}
			}

			.platform-bar-container {
				width: 100%;
				height: 86rpx;
				background: #FFFFFF;

				.plat-scrollview {
					width: 100%;
					height: 100%;
					white-space: nowrap;

					.plat-items {
						display: inline-block;
						height: 86rpx;
						margin-right: 70rpx;

						.items-content {
							height: 100%;
							font-size: 28rpx;
							font-weight: 500;
							color: #333333;
							border-bottom: 4rpx solid transparent;
						}
					}

					.plat-items:nth-child(1) {
						margin-left: 40rpx;
					}

					.plat-active {
						.items-content {
							font-weight: bold;
							color: #FE3738;
							border-bottom: 4rpx solid #FE3738;
						}
					}
				}
			}
		}

		.pageContent-container {
			width: 100%;
			padding: 0 20rpx;
			margin-top: 155rpx;

			.turn-container {
				width: 100%;
				height: 456rpx;
				background: #FFFFFF;
				border-radius: 16rpx;
				padding: 0 27rpx;

				.content-title {
					width: 100%;
					height: 87rpx;
					font-size: 28rpx;
					font-weight: 500;

					.left-txt {
						color: #333333;
						image{
							width: 26rpx;
							height: 26rpx;
							margin-right: 10rpx;
						}
					}

					.clean-btn {
						color: #666666;
					}
				}
			}
			
			.textarea-bac{
				width: 100%;
				height: 330rpx;
				background: #F8F8F8;
				border-radius: 16rpx;
				padding: 30rpx;
				.txtstyle{
					height: 240rpx;
					font-size: 24rpx;
					font-weight: 500;
					color: #000000;
				}
				.bottom-bar{
					width: 100%;
					text-align: right;
					font-size: 24rpx;
					font-weight: 500;
					color: #999999;
				}
			}
			
			.btn-container{
				width: 100%;
				padding: 0 10rpx;
				margin-top: 45rpx;
				.btn-box{
					width: 100%;
					height: 86rpx;
					background: #FD002F;
					border-radius: 43rpx;
					font-size: 30rpx;
					font-weight: 500;
					color: #FFFFFF;
				}
			}
			
			.jcpic{
				width: 100%;
				margin-top: 45rpx;
			}
		}
	}
</style>
