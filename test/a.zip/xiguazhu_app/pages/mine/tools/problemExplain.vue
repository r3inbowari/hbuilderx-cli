<template>
	<view class="problemExplain-wrapper wrapperLayer">
		<titleBar :titleText='pageTitle' :pageForm='"problemExplain"'></titleBar>
		<view class="vid-area" v-if="type==1">
			<video class="video" :src="videoUrl" controls></video>
		</view>
		<view class="pageContent colCen borderBox" v-else v-html="content">
		</view>
	</view>
</template>

<script>
	import titleBar from '../../../components/backTitlebar.vue';
	export default {
		components: {
			titleBar
		},
		data() {
			return {
				pageTitle: '',
				id: '',
				content: '',
				type:2,
				videoUrl:''
			}
		},
		onLoad(options) {
			this.id = options.id
			this.getData()
		},
		methods: {
			getData() {
				this.$http.post('helpContent/getHelpDetail/' + this.id).then(res => {
					console.log(res);
					this.pageTitle = res.title
					this.content = res.content
					this.type = res.type
					this.videoUrl = res.videoUrl
				})
			}
		}
	}
</script>

<style lang="scss">
	.problemExplain-wrapper {
		width: 100%;
		min-height: 100vh;
		display: flex;
		flex-direction: column;
		background-color: #FFFFFF;

		.pageContent {
			width: 100%;
			padding: 32rpx;
			text-indent: 2em;
			font-size: 32rpx;
			line-height: 48rpx;
		}
		.vid-area{
			flex: 1;
			display: flex;
			flex-direction: column;
			.video{
				width: 100%;
				flex: 1;
			}
		}
	}
</style>
