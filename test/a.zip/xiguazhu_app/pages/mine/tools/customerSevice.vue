<template>
	<view class="customerSevice-wrapper wrapperLayer colCen">
		<titleBar :titleText='"联系客服"' :pageForm='"businessCooperation"'></titleBar>
		<view class="centerbox colCen">
			<image @longpress="saveImg" class="code" :src="wxImg" mode=""></image>
			
			<view class="num-container rowCenBet">
				<view class="number">
					{{wxNum}}
				</view>
				<view class="copybtn rowCenCen" @tap="copy()">
					<view>复制</view>
				</view>
			</view>
		</view>
		
		<u-toast ref="uToast" />
	</view>
</template>

<script>
	export default {
		data() {
			return {
				wxNum: 'fisjf390',
				wxImg: '',
			}
		},
		onLoad() {
			this.getpageData()
		},
		methods: {
			getpageData() {
				this.$http.post('cpssystemConfig/getCustomerServiceInfo').then(res => {
					console.log(res, '========>客服信息');
					this.wxNum = res.wxNumber
					this.wxImg = res.wxImg
				})
			},
			pathBack() {
				uni.navigateBack({
					delta: 1,
				})
			},
			saveImg(e) {
				console.log(e);
				uni.saveImageToPhotosAlbum({
					filePath: this.wxImg,
					success: res=> {
						this.$refs.uToast.show({
							title: '保存成功，可在相册中查看',
							type: 'success',
							position: 'bottom'
						})
					}
				});
			},
			copy(){
				uni.setClipboardData({
					data:this.wxNum,
					success: () => {
						uni.showToast({
							title:'复制成功！',
							icon:'none'
						})
						uni.setStorageSync('clipboard', this.wxNum);
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.centerbox{
		width: 605rpx;
		height: 762rpx;
		background: url(../../../static/images/mine/callbac.png)no-repeat;
		background-size: 100% 100%;
		margin-top: 50rpx;
		.code{
			width: 248rpx;
			height: 248rpx;
			margin-top: 280rpx;
		}
		
		.num-container{
			margin-top: 30rpx;
			width: 356rpx;
			height: 64rpx;
			background: linear-gradient(266deg, #FC6656, #FEB878);
			border-radius: 31rpx;
			.number{
				font-size: 30rpx;
				font-weight: 500;
				color: #FFFFFF;
				margin-left: 22rpx;
			}
			.copybtn{
				width: 132rpx;
				height: 64rpx;
				background: linear-gradient(266deg, #FC6656, #FEB878);
				border-radius: 31rpx;
				font-size: 30rpx;
				font-weight: 500;
				color: #FFFFFF;
			}
		}
	}
</style>
