<template>
	<view class="businessCooperation-wrapper wrapperLayer colCen">
		<titleBar :titleText='"商务合作"' :pageForm='"businessCooperation"'></titleBar>
		<image class="applogo" :src="appInfo.logo" mode=""></image>
		<view class="appname">
			{{appInfo.appName}}
		</view>
		
		<view class="centerbox colCen">
			<image @longpress="saveImg" class="code" :src="code" mode=""></image>
			
			<view class="num-container rowCenBet">
				<view class="number">
					{{num}}
				</view>
				<view class="copybtn rowCenCen" @tap="copy()">
					<view>复制</view>
				</view>
			</view>
		</view>
		
		<u-toast ref="uToast" />
	</view>
</template>

<script>
	import util from '../../../utils/utils.js'
	export default {
		data(){
			return{
				appInfo:'',
				code:'',
				num:''
			}
		},
		onLoad() {
			this.appInfo = util.getCacheSync('appInfo')
			this.getpageData()
		},
		methods: {
			getpageData() {
				this.$http.post('cpssystemConfig/getCustomerServiceInfo').then(res => {
					console.log(res, '========>客服信息');
					this.code = res.shangwuWxImg
					this.num = res.shangwuWxNumber
				})
			},
			
			saveImg(e) {
				console.log(e);
				uni.saveImageToPhotosAlbum({
					filePath: this.code,
					success: res=> {
						this.$refs.uToast.show({
							title: '保存成功，可在相册中查看',
							type: 'success',
							position: 'bottom'
						})
					}
				});
			},
			
			copy(){
				uni.setClipboardData({
					data:this.shangwuWxNumber,
					success: () => {
						uni.showToast({
							title:'复制成功！',
							icon:'none'
						})
						
						uni.setStorageSync('clipboard', this.shangwuWxNumber);
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.applogo{
		width: 134rpx;
		height: 134rpx;
		border-radius: 50%;
		margin-top: 50rpx;
	}
	
	.appname{
		font-size: 30rpx;
		font-weight: 500;
		color: #333333;
		margin-top: 20rpx;
	}
	
	.centerbox{
		width: 605rpx;
		height: 762rpx;
		background: url(../../../static/images/mine/callbac.png)no-repeat;
		background-size: 100% 100%;
		margin-top: 50rpx;
		.code{
			width: 248rpx;
			height: 248rpx;
			margin-top: 280rpx;
		}
		
		.num-container{
			margin-top: 30rpx;
			width: 356rpx;
			height: 64rpx;
			background: linear-gradient(266deg, #FC6656, #FEB878);
			border-radius: 31rpx;
			.number{
				font-size: 30rpx;
				font-weight: 500;
				color: #FFFFFF;
				margin-left: 22rpx;
			}
			.copybtn{
				width: 132rpx;
				height: 64rpx;
				background: linear-gradient(266deg, #FC6656, #FEB878);
				border-radius: 31rpx;
				font-size: 30rpx;
				font-weight: 500;
				color: #FFFFFF;
			}
		}
	}
</style>
