<template>
	<view class="myStore-wrapper wrapperLayer colCen">
		<titleBar :titleText='"我的店铺"' :pageForm='"myStore"'></titleBar>
		<view class="fixedbox colCen">
			<view class="topbarbox"></view>
			<image class="bicpic" src="../../static/images/mine/store.png" mode="aspectFill"></image>
		</view>
		
		<view class="usercontent-contaienr colCen">
			<view class="userinfo rowCen">
				<image class="avatar" :src="userinfo.avatar" mode="aspectFill"></image>
				<view class="right-box">
					<view class="name">
						{{userinfo.nickName}}
					</view>
					<view class="label rowCenCen">
						<view>个人店铺</view>
					</view>
				</view>
			</view>
		</view>
		
		<scroll-view scroll-y="true" class="scrview">
			<block v-for="(items,index) in list" :key="index">
				<view class="items-box colCen">
					<view class="card-title rowCenBet">
						<view class="title">
							{{items.shopName}}
						</view>
						
						<view class="rig-arrow-content rowCen" @tap="goShopUrl(items.shopUrl)">
							<view class="gotxt">
								进入店铺
							</view>
							<view class="iconfont">
								&#xe8d4;
							</view>
						</view>
					</view>
					
					<view class="linkcontent">
						{{items.shopUrl}}
					</view>
					
					
					<view class="copybox rowCenCen" @tap="copy(items.shopUrl)">
						<image class="copy" src="../../static/images/mine/copy.png" mode="aspectFill"></image>
						<view>复制链接</view>
					</view>
				</view>
			</block>
		</scroll-view>
	</view>
</template>

<script>
	export default {
		data(){
			return{
				userinfo:'',
				list:''
			}
		},
		onLoad() {
			this.userinfo = uni.getStorageSync('userData');
			this.getList()
		},
		methods:{
			getList(){
				this.$http.get('tb/myShop').then(res=>{
					console.log(res);
					this.list = res
				})
			},
			copy(url){
				uni.setClipboardData({
					data:url,
					success: () => {
						uni.showToast({
							icon:'none',
							title:'复制成功！'
						})
						uni.setStorageSync('clipboard', url);
					}
				})
			},
			goShopUrl(url){
				uni.navigateTo({
					url: '../webView/webView?url=' + url
				})
			}
		}
	}
</script>

<style lang="scss">
	.myStore-wrapper{
		width: 100%;
		min-height: 100vh;
		background: linear-gradient(-7deg, #ED3534, #D30B0B);
		.fixedbox{
			position: fixed;
			right: 0;
			top: 0;
			.bicpic{
				width: 370rpx;
				height: 320rpx;
				margin-top: 110rpx;
			}
		}
		.usercontent-contaienr{
			width: 100%;
			.userinfo{
				width: 100%;
				height: 200rpx;
				padding: 0 36rpx;
				.avatar{
					width: 122rpx;
					height: 122rpx;
					border-radius: 50%;
				}
				.right-box{
					margin-left: 24rpx;
					.name{
						font-size: 30rpx;
						font-weight: 500;
						color: #FFFFFF;
					}
					.label{
						width: 121rpx;
						height: 36rpx;
						background: linear-gradient(-7deg, #F6A354, #F5C886);
						border-radius: 18rpx;
						font-size: 24rpx;
						font-weight: 500;
						color: #FFFFFF;
						margin-top: 15rpx;
					}
				}
			}
		}
		.scrview{
			width: 100%;
			flex: 1;
			padding: 0 20rpx;
			.items-box{
				width: 100%;
				height: 372rpx;
				background: linear-gradient(-7deg, #FFE9CF, #FCF9E9);
				border-radius: 20rpx;
				padding: 0 34rpx;
				margin-bottom: 20rpx;
				.card-title{
					width: 100%;
					height: 90rpx;
					.title{
						font-size: 30rpx;
						font-weight: bold;
						color: #333333;
					}
					
					.rig-arrow-content{
						font-size: 24rpx;
						font-weight: 500;
						color: #999999;
						.iconfont{
							font-size: 20rpx;
						}
					}
				}
				
				.linkcontent{
					width: 643rpx;
					height: 147rpx;
					background: #FFFFFF;
					border-radius: 10rpx;
					padding: 17rpx;
				}
				.copybox{
					width: 304rpx;
					height: 74rpx;
					margin-top: 32rpx;
					border: 1rpx solid #4A3D3F;
					border-radius: 37rpx;
					.copy{
						width: 25rpx;
						height: 25rpx;
						margin-right: 18rpx;
					}
				}
			}
		}
	}
</style>
