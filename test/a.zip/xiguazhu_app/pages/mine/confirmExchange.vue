<template>
	<view class="confirmExchange-wrapper wrapperLayer">
		<titleBar :titleText="'确认兑换'" :pageForm='"confirmExchange"'></titleBar>

		<view class="pagebottom-container colCen">
			<view class="address-content rowCenBet mg20" @tap="checkAddress()">
				<view class="addressInfo-content" v-if="addressInfo">
					<view class="topuserinfo rowCen">
						<view class="name">
							{{addressInfo.realName}}
						</view>
						<view class="phone">
							{{addressInfo.phone}}
						</view>
					</view>
					<view class="address">
					 	{{addressInfo.province}} {{addressInfo.city}} {{addressInfo.district}} {{addressInfo.detail}}
					</view>
				</view>
				<view class="no-address iconfont" v-else>
					&#xe683; 请先选择地址
				</view>

				<view class="arrow iconfont">
					&#xe8d4;
				</view>
			</view>


			<view class="goods-info rowSta borderBox pd20">
				<image class="goods-pic" :src="pageInfo.mainPic" mode="aspectFill"></image>
				<view class="info-box colStaBet">
					<view class="godsname">
						{{pageInfo.title}}
					</view>
					<view class="zuanshi rowCenEnd">
						<view class="corbox rowCenCen">
							<view>{{pageInfo.needDiamonds}}钻石</view>
						</view>
					</view>
				</view>
			</view>

			<view class="confirm-btn rowCenCen" @tap="show()">
				<view>确认兑换</view>
			</view>
		</view>
		
		<u-modal v-model="showModel" show-cancel-button :content="content" @confirm="confirm" :async-close="true"></u-modal>
	</view>
</template>

<script>
	import util from '../../utils/utils.js'
	export default {
		data() {
			return {
				pageInfo:'',
				addressInfo: '',
				showModel:false,
				content:'确定要兑换该商品嘛？'
			}
		},
		onLoad(options) {
			this.pageInfo = JSON.parse(options.info)
			console.log(this.pageInfo);
		},
		onShow() {
			this.addressInfo = util.getCacheSync('addressInfo')
			console.log(this.addressInfo);
		},
		methods:{
			checkAddress(){
				uni.navigateTo({
					url:'./setting/myAddress?type=1'
				})
			},
			show(){
				if(this.addressInfo){
					this.showModel = true
				}else{
					uni.showToast({
						title:'请先添加收货地址！',
						icon:'none'
					})
				}
			},
			confirm(){
				this.$http.post('diamond/exchangeGoods',{
					goodsId:this.pageInfo.id,
					address:this.addressInfo.province + this.addressInfo.city + this.addressInfo.district + this.addressInfo.detail,
					realName:this.addressInfo.realName,
					userPhone:this.addressInfo.phone
				},'application/json',true).then(res=>{
					console.log(res);
					this.showModel = false
					uni.showToast({
						title:'兑换成功，可在兑换中心，已兑换商品处查看！',
						icon:'none'
					})
					uni.navigateBack({
						delta:1
					})
				}).catch(res=>{
					this.showModel = false
				})
			}
		}
	}
</script>

<style lang="scss">
	.confirmExchange-wrapper {
		width: 100%;

		.pagebottom-container {
			width: 100%;
			padding: 0 20rpx;
			margin-top: 20rpx;

			.address-content {
				width: 100%;
				background: #FFFFFF;
				border-radius: 16rpx;
				padding: 35rpx 30rpx;

				.addressInfo-content {
					.topuserinfo {
						.name {
							font-size: 30rpx;
							font-weight: 500;
							color: #333333;
						}

						.phone {
							font-size: 24rpx;
							color: #666666;
							margin-left: 20rpx;
						}
					}

					.address {
						font-size: 24rpx;
						font-weight: 500;
						color: #333333;
						margin-top: 20rpx;
					}
				}

				.no-address {
					font-size: 30rpx;
					font-weight: 500;
					color: #333333;
				}

				.arrow {
					font-size: 30rpx;
					font-weight: 500;
					color: #999999;
				}
			}

			.goods-info {
				width: 100%;
				height: 220rpx;
				background: #FFFFFF;
				border-radius: 8rpx;

				.goods-pic {
					width: 120rpx;
					height: 120rpx;
					border-radius: 6rpx;
					margin-top: 30rpx;
				}

				.info-box {
					margin-left: 20rpx;
					margin-top: 30rpx;
					width: 520rpx;
					height: 160rpx;

					.godsname {
						font-size: 28rpx;
						font-weight: 500;
						color: #333333;
						overflow: hidden;
						text-overflow: ellipsis;
						display: -webkit-box;
						-webkit-line-clamp: 2;
						-webkit-box-orient: vertical;
					}

					.zuanshi {
						width: 100%;

						.corbox {
							width: 121rpx;
							height: 34rpx;
							background: linear-gradient(-90deg, #FEA32A, #FFC437);
							border-radius: 5rpx;
							font-size: 22rpx;
							font-weight: 500;
							color: #FFFFFF;
						}
					}
				}
			}

			.confirm-btn {
				width: 100%;
				height: 86rpx;
				margin-top: 45rpx;
				background: linear-gradient(-90deg, #FEA32A, #FFC437);
				border-radius: 43rpx;
				font-size: 30rpx;
				font-weight: 500;
				color: #FFFFFF;
			}
		}
	}
</style>
