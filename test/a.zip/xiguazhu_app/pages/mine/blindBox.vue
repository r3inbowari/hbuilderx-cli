<template>
	<view class="blindBox-wrapper wrapperLayer">
		<titleBar :titleText='"幸运盲盒"' :pageForm='"blindBox"'></titleBar>
		<view class="banner-container borderBox">
			<swiper class="swiperbox" :indicator-dots="false" :autoplay="true" :interval="3000" :duration="1000" :circular="true">
				<swiper-item v-for="(items,index) in bannerList" :key="index" @tap="goUrl(items)">
					<image class="bannerpic" :src="items.pic" mode="aspectFill"></image>
				</swiper-item>
			</swiper>
		</view>
		
		<view class="options-container rowCenBet borderBox">
			<block v-for="(items,index) in optionsList" :key="index">
				<view class="options-item colCenCen" @tap="gopage(items.url)">
					<image class="optionspic" :src="items.pic" mode="aspectFill"></image>
					<view class="opt-txt">
						{{items.label}}
					</view>
				</view>
			</block>
		</view>
		
		<view class="box-list-container colCen borderBox">
			<view class="boxtitle rowCen">
				<view>火爆单品</view>
			</view>
			<view class="box-content rowCenBet">
				<block v-for="(items,index) in boxList" :key="index">
					<view class="box-items colCen" @tap="godraw(items)">
						<image class="boxpic" :src="items.img"></image>
						<view class="label">
							{{items.title}}
						</view>
					</view>
				</block>
			</view>
		</view>
	</view>
</template>

<script>
	import utils from '../../utils/utils.js'
	export default {
		data() {
			return {
				bannerList:[],
				optionsList:[
					{
						pic:'../../static/images/mine/manghejiaocheng.png',
						label:'新手入门',
						url:'./blindbox/rules'
					},
					{
						pic:'../../static/images/mine/shangjiazanzhu.png',
						label:'商家赞助',
						url:'./tools/businessCooperation'
					},
					{
						pic:'../../static/images/mine/box.png',
						label:'我的盲盒',
						url:'./blindbox/boxOrder'
					}
				],
				
				boxList:[],
				loadstate:'loading',
				canload:false,
				pageNumer:0
			}
		},
		onLoad() {
			this.getpageData()
			this.getbanner()
		},
		onPullDownRefresh() {
			this.getpageData()
		},
		methods:{
			getbanner(){
				// banner数据
				this.$http.get('banner/list/10').then((res) => {
					console.log(res);
					this.bannerList = res;
				})
			},
			getpageData(){
				this.$http.post('blindBox/blindBoxList',{
					limit:30,
					offset:this.pageNumer
				},'application/json').then(res=>{
					console.log(res);
					uni.stopPullDownRefresh()
					this.boxList = res
				})
			},
			
			goUrl(info){
				console.log(info);
				utils.goUrl(info)
			},
			gopage(url){
				uni.navigateTo({
					url:url
				})
			},
			
			godraw(info){
				uni.navigateTo({
					url:'./blindbox/openBlind?info='+JSON.stringify(info)
				})
			}
		}
	}
</script>

<style lang="scss">
	.blindBox-wrapper {
		width: 100%;

		.banner-container {
			width: 100%;
			padding: 0 26rpx;
			margin-top: 20rpx;

			.swiperbox {
				width: 100%;
				height: 280rpx;

				.bannerpic {
					width: 100%;
					height: 280rpx;
					border-radius: 12rpx;
				}
			}
		}
		
		.options-container{
			width: 100%;
			height: 166rpx;
			padding: 0 100rpx;
			margin-top: 20rpx;
			background-color: #FFFFFF;
			.options-item{
				height: 100%;
				.optionspic{
					width: 80rpx;
					height: 80rpx;
					margin-bottom: 15rpx;
				}
				.opt-txt{
					font-size: 28rpx;
					font-weight: 500;
					color: #333333;
				}
			}
		}
		
		.box-list-container{
			width: 100%;
			background-color: #FFFFFF;
			margin-top: 20rpx;
			padding: 0 26rpx;
			.boxtitle{
				width: 100%;
				height: 90rpx;
				font-size: 30rpx;
				font-weight: 500;
				color: #333333;
			}
			.box-content{
				width: 100%;
				flex-wrap: wrap;
				.box-items{
					width: 340rpx;
					margin-bottom: 30rpx;
					.boxpic{
						width: 100%;
						height: 340rpx;
						margin-bottom: 20rpx;
						border-radius: 12rpx;
					}
					.label{
						width: 100%;
						overflow: hidden;
						text-overflow: ellipsis;
						white-space: nowrap;
						text-align: center;
						font-size: 30rpx;
						font-weight: 500;
						color: #333333;
					}
				}
			}
		}
	}
</style>
