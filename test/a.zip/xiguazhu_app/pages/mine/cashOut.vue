<template>
	<view class="cashOut-wrapper wrapperLayer">
		<titleBar :titleText="'提现'" :pageForm='"cashOut"'></titleBar>
		<view class="zfbInfo-container rowCen" @tap="setZFB()">
			<view class="nozfbInfo" v-if="userInfo.truename && userInfo.zfbAccount">
				<view class="leftcontent rowCen">
					<image class="zfb" src="../../static/images/mine/zfb.png" mode=""></image>
					<view class="txt-tips" style="margin-left: 30rpx;">
						<view class="top-txt">
							{{userInfo.truename}}
						</view>
						<view class="down-txt">
							{{userInfo.zfbAccount.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2')}}
						</view>
					</view>
				</view>
			</view>
			<view class="nozfbInfo rowCenBet" v-else>
				<view class="leftcontent rowCen">
					<image class="zfb" src="../../static/images/mine/zfb.png" mode=""></image>
					<view class="txt-tips">
						<view class="top-txt">
							您还未绑定支付宝账号
						</view>
						<view class="down-txt">
							{{appInfo.appName}}保证不会泄露您的支付宝信息
						</view>
					</view>
				</view>
				<view class="right-btn rowCenCen">
					<view>立即绑定</view>
				</view>
			</view>
		</view>
		
		<view class="cashNum-container colCen">
			<view class="box-title">
				提现金额
			</view>
			<view class="cash-input-container rowCenBet">
				<view class="left-input rowCen">
					<view class="rmb">
						￥
					</view>
					<input class="cashinput" type="number" v-model="cashPrice" :placeholder="`(最低提现1元 可提现￥`+userInfo.nowMoney+')'" placeholder-class="placStyle"/>
				</view>
				
				<view class="right-btn" @tap="cashAll()">
					全部
				</view>
			</view>
		</view>
		
		<view class="confirm-bar rowCen" @tap='casntap()'>
			<view class="confirm-btn rowCenCen">
				<view>确认提现</view>
			</view>
		</view>
		
		<view class="bottom-list-container colCen">
			<view class="title-nav-bar rowCenBet">
				<block v-for="(items,index) in orderNav" :key="index">
					<view class="nav-items rowCenCen" :style="navCurrent==index?'border-bottom: 4rpx solid #FD002F;':'border-bottom: 4rpx solid transparent;'" @tap="clkNav(index)">
						<view>{{items.label}}</view>
					</view>
				</block>
			</view>
			<view class="recordList-container colCen">
				<block v-for="(items,index) in recordList" :key="index">
					<view class="items-container rowCenBet">
						<view class="record-details" >
							<view class="record-title">
								{{items.title}}{{navCurrent==1?items.status==1?'-成功':items.status==2?'-失败':'-审核中':''}}
							</view>
							<view class="record-time">
								{{items.createTime}}
							</view>
						</view>
						
						<view class="right-num-content colCen">
							<view class="numbox" :style="'color:' + (items.changeMoney>0?'#FE3738;':'#999999;')">
								{{navCurrent==2?items.status==2?'-':'+':''}}{{items.changeMoney}}
							</view>
						</view>
					</view>
				</block>
			</view>
		</view>
		<aLoadMore :status="loadstate" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
		
		<u-modal v-model="showModel" show-cancel-button :content="content" @confirm="confirm" :async-close="true"></u-modal>
	</view>
</template>

<script>
	export default{
		data(){
			return{
				userInfo:'',
				cashPrice:'',
				navCurrent:0,
				orderNav:[
					{
						label:'结算日志'
					},
					{
						label:'提现记录'
					},
					{
						label:'余额明细'
					}
				],
				recordList:[],
				
				showModel:false,
				content: '确认提现？',
				
				loadstate: 'loading',
				pageCurrent: 0,
				canload: false,
				appInfo:''
			}
		},
		onLoad() {
			this.getrecord()
		},
		onShow() {
			this.appInfo = uni.getStorageSync('appInfo')
			this.getuserInfo()
		},
		onReachBottom() {
			if(this.canload){
				this.getrecord()
			}
		},
		methods:{
			cashAll(){
				this.cashPrice = this.userInfo.nowMoney
			},
			
			casntap(){
				if(this.userInfo.zfbAccount && this.userInfo.truename){
					if(Number(this.cashPrice)<1){
						uni.showToast({
							title: '提现金额不能小于1元！',
							icon:'none'
						});
					}else{
						if(Number(this.cashPrice)>Number(this.userInfo.nowMoney)){
							uni.showToast({
								title: '余额不足了！',
								icon:'none'
							});
						}else{
							this.showModel = true
						}
					}
				}else{
					uni.showToast({
						icon:'none',
						title:'您还没有绑定支付宝账号！'
					})
				}
			},
			
			confirm(){
				this.$http.post('balanceDetails/withdrawal',{
					truename:this.userInfo.truename,
					withdrawalAmount:this.cashPrice,
					zfbAccount:this.userInfo.zfbAccount
				},'application/json',true).then(res=>{
					console.log(res);
					this.cashPrice = ''
					this.getuserInfo()
					this.clkNav(1)
					this.showModel = false
				}).catch(res=>{
					this.cashPrice = ''
					this.recordList = []
					this.getuserInfo()
					this.getrecord()
					this.showModel = false
				})
			},
			
			getuserInfo() {
				this.$http.get('member/getInfo', {}, true).then((res) => {
					console.log(res, '========>获取用户信息');
					this.userInfo = res
				})
			},
			
			getrecord(){
				this.$http.post('balanceDetails/getList', {
					limit:10,
					offset:this.pageCurrent,
					type:this.navCurrent
				},'application/json', true).then((res) => {
					console.log(res, '========>获取记录');
					uni.stopPullDownRefresh()
					if(res.length<10){
						this.loadstate = 'nomore'
						this.canload = false
					}else{
						this.loadstate = 'loading'
						this.canload = true
						this.pageCurrent+=10
					}
					this.recordList = this.recordList.concat(res)
				})
			},
			
			clkNav(idx){
				this.navCurrent = idx
				this.recordList = []
				this.canload = false
				this.pageCurrent = 0
				this.loadstate = 'loading'
				this.getrecord()
			},
			
			setZFB(){
				uni.navigateTo({
					url:'./setting/bindingZFB'
				})
			}
		},
		onPullDownRefresh() {
			this.recordList = []
			this.canload = false
			this.pageCurrent = 0
			this.loadstate = 'loading'
			this.getrecord()
		}
	}
</script>

<style lang="scss">
	.cashOut-wrapper{
		width: 100%;
		.zfbInfo-container{
			width: 100%;
			height: 138rpx;
			margin-top: 20rpx;
			background: #FFFFFF;
			padding: 0 12rpx;
			.nozfbInfo{
				width: 100%;
				.leftcontent{
					.zfb{
						width: 86rpx;
						height: 86rpx;
					}
					.txt-tips{
						margin-left: 12rpx;
						.top-txt{
							font-size: 28rpx;
							font-weight: 500;
							color: #333333;
						}
						.down-txt{
							font-size: 24rpx;
							font-weight: 500;
							color: #666666;
						}
					}
				}
				.right-btn{
					width: 156rpx;
					height: 62rpx;
					background: #0D0D0D;
					border-radius: 31rpx;
					font-size: 28rpx;
					font-weight: 500;
					color: #FFFFFF;
					margin-right: 30rpx;
				}
			}
		}
		
		.cashNum-container{
			width: 750rpx;
			height: 280rpx;
			background: #FFFFFF;
			margin-top: 20rpx;
			.box-title{
				width: 100%;
				font-size: 28rpx;
				font-weight: 500;
				color: #333333;
				padding: 0 28rpx;
				margin-top: 40rpx;
			}
			.cash-input-container{
				width: 100%;
				padding: 0 30rpx;
				margin-top: 60rpx;
				.left-input{
					.rmb{
						font-size: 30rpx;
						font-weight: bold;
						color: #333333;
					}
					.cashinput{
						width: 500rpx;
						margin-left: 20rpx;
						font-size: 50rpx;
						font-weight: bold;
						color: #333333;
					}
					.placStyle{
						font-size: 30rpx;
						font-weight: 500;
						color: #999999;
					}
				}
				
				.right-btn{
					font-size: 28rpx;
					font-weight: 500;
					color: #FE3738;
				}
			}
		}
		
		.confirm-bar{
			width: 100%;
			padding: 0 30rpx;
			.confirm-btn{
				width: 100%;
				height: 86rpx;
				background: #FD002F;
				border-radius: 43rpx;
				font-size: 30rpx;
				font-weight: 500;
				color: #FFFFFF;
				margin: 50rpx 0;
			}
		}
		
		.bottom-list-container{
			width: 100%;
			background-color: #FFFFFF;
			.title-nav-bar{
				width: 100%;
				height: 86rpx;
				padding: 0 104rpx;
				.nav-items{
					width: 112rpx;
					height: 100%;
					font-size: 28rpx;
					font-weight: 500;
					color: #333333;
				}
			}
			.recordList-container{
				width: 100%;
				.items-container{
					width: 100%;
					height: 134rpx;
					padding: 0 30rpx;
					// border-bottom: 1rpx solid #F1F1F1;
					.record-details{
						.record-title{
							font-size: 26rpx;
							font-weight: 500;
							color: #333333;
						}
						.record-time{
							font-size: 22rpx;
							font-weight: 500;
							color: #666666;
							margin-top: 25rpx;
						}
					}
					.right-num-content{
						.numbox{
							font-size: 36rpx;
							font-weight: bold;
							color: #333333;
						}
						.state{
							font-size: 24rpx;
							font-weight: 500;
						}
					}
				}
			}
		}
	}
</style>
