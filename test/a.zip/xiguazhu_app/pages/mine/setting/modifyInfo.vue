<template>
	<view class="modifyInfo-wrapper wrapperLayer">
		<titleBar :titleText="'修改信息'" :pageForm='"modifyInfo"'></titleBar>
		<view class="pagebottom-container colCen">
			<view class="userAvator-bar pd30 rowCenBet" @tap="avatarChoose()">
				<view class="leftkey">
					头像
				</view>
				<view class="rightval rowCen">
					<image :src="userInfo.avatar" mode="aspectFill"></image>
					<view class="arrow iconfont">
						&#xe8d4;
					</view>
				</view>
			</view>
			<view class="username-bar userAvator-bar rowCenBet pd30" @tap="nickname()">
				<view class="leftkey">
					昵称
				</view>
				<view class="rightval rowCen">
					<view class="nameinfo">
						{{userInfo.nickName}}
					</view>
					<view class="arrow iconfont">
						&#xe8d4;
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import util from '../../../utils/utils.js'
	export default {
		data() {
			return {
				userInfo:''
			}
		},
		onShow() {
			util.getCache('userData').then(res=>{
				this.userInfo = res
			})
		},
		methods:{
			nickname(){
				uni.navigateTo({
					url:'./setNickname?nickName='+this.userInfo.nickName
				})
			},
			avatarChoose(){
				uni.chooseImage({
				    count: 1, //默认9
				    success: res=> {
						console.log(res);
						this.$http.upload('common/sysFile/upload',res.tempFilePaths[0]).then(res=>{
							console.log(res);
							this.$http.post('member/updateMember',{
								avatar:res.fileName
							},'application/json').then(res=>{
								console.log(res);
								this.userInfo.avatar = res.avatar
								util.setCache('userData',res)
							})
						}).catch(res=>{
							uni.showToast({
								title:'上传失败！',
								icon:'none'
							})
						})
				    }
				});
			}
		}
	}
</script>

<style lang="scss">
	.modifyInfo-wrapper {
		width: 100%;

		.pagebottom-container {
			width: 100%;
			margin-top: 20rpx;

			.userAvator-bar {
				width: 100%;
				height: 130rpx;
				background: #FFFFFF;
				box-shadow: 0px -1rpx 0px 0px #F1F1F1;

				.leftkey {
					font-size: 28rpx;
					font-weight: 500;
					color: #333333;
				}

				.rightval {
					image {
						width: 100rpx;
						height: 100rpx;
						border-radius: 50%;
					}

					.arrow {
						color: #666666;
						font-size: 20rpx;
						margin-left: 30rpx;
						margin-top: 5rpx;
					}
				}
			}

			.username-bar {
				height: 90rpx;
			}
		}
	}
</style>
