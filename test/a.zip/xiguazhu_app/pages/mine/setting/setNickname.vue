<template>
	<view class="setNickname-wrapper wrapperLayer">
		<titleBar :titleText="'昵称'" :pageForm='"setNickname"'></titleBar>
		<view class="input-container pd30 rowCenBet">
			<input class="ipt" type="text" v-model="nickname" placeholder="请输入昵称" placeholder-class="plc"/>
			<view class="iconfont rowCenSta clear" @tap="clearInp()" v-if="nickname">
				&#xe641;
			</view>
		</view>
		<view class="btn-content pd30 rowCenCen" @tap="submit()">
			<view class="cfm-btn rowCenCen"><view>确认修改</view></view>
		</view>
	</view>
</template>

<script>
	import util from '../../../utils/utils.js'
	export default {
		data(){
			return{
				nickname:''
			}
		},
		onLoad(options) {
			this.nickname = options.nickName
		},
		methods:{
			submit(){
				if(this.nickname){
					this.$http.post('member/updateMember',{
						nickName:this.nickname
					},'application/json').then(res=>{
						console.log(res);
						util.setCache('userData',res).then(res=>{
							uni.navigateBack({
								delta:1
							})
						})
					})
				}else{
					uni.showToast({
						icon:'none',
						title: '用户昵称不能为空！'
					})
				}
			},
			clearInp(){
				this.nickname = ''
			}
		}
	}
</script>

<style lang="scss">
	.setNickname-wrapper{
		width: 100%;
		.input-container{
			width: 100%;
			height: 86rpx;
			margin-top: 20rpx;
			background: #FFFFFF;
			.ipt{
				width: 100%;
				height: 100%;
				font-size: 28rpx;
				font-weight: 500;
				color: #333333;
			}
			.clear{
				width: 50rpx;
				height: 100%;
				white-space: nowrap;
			}
		}
		
		.btn-content{
			width: 100%;
			height: 86rpx;
			margin-top: 46rpx;
			.cfm-btn{
				width: 100%;
				height: 86rpx;
				background: #FD002F;
				border-radius: 43rpx;
				font-size: 30rpx;
				font-weight: 500;
				color: #FFFFFF;
			}
		}
	}
</style>
