<template>
	<view class="accountAuthorization-wrapper wrapperLayer colCen">
		<titleBar :titleText="'账号授权'" :pageForm='"accountAuthorization"'></titleBar>
		
		<image class="icon" v-if="status" src="../../../static/images/mine/suc.png" mode="aspectFill"></image>
		<image class="icon" v-else src="../../../static/images/mine/fail.png" mode="aspectFill"></image>
		
		<view class="result">
			{{status?'授权成功！':'授权失败!'}}
		</view>
		
		<view class="res" v-if="!status">
			{{res}}
		</view>
		
		<view @tap='back()' class="close-btn rowCenCen" :style="status?'background: #17D56B;box-shadow: 0px 5rpx 9rpx 0px rgba(23, 213, 107, 0.33)':''">
			<view>关闭</view>
		</view>
	</view>
</template>

<script>
	export default {
		data(){
			return{
				status:false
			}
		},
		onLoad(options) {
			this.status = options.status
			if(this.status==1){
				this.status = true
			}else{
				this.status = false
			}
			console.log(this.status);
			this.res = options.res
		},
		methods:{
			back(){
				uni.navigateBack({
					delta:1
				})
			}
		}
	}
</script>

<style lang="scss">
	.accountAuthorization-wrapper{
		width: 100%;
		height: 100vh;
		background-color: #FFFFFF;
		.icon{
			width: 107rpx;
			height: 107rpx;
			margin-top: 180rpx;
		}
		.result{
			font-size: 36rpx;
			font-weight: bold;
			color: #333333;
			margin-top: 35rpx;
			margin-bottom: 50rpx;
		}
		
		.res{
			margin-bottom: 60rpx;
			font-size: 24rpx;
			font-weight: 500;
			color: #333333;
		}
		
		.close-btn{
			width: 418rpx;
			height: 76rpx;
			background: #FD002F;
			box-shadow: 0px 5rpx 9rpx 0px rgba(253, 0, 47, 0.33);
			opacity: 0.97;
			border-radius: 38rpx;
			font-size: 30rpx;
			font-weight: 500;
			color: #FFFFFF;
		}
	}
</style>
