<template>
	<view class="newAddress-wrapper wrapperLayer">
		<titleBar :titleText="(!ischange?'新增':'修改') + '收货地址'" :pageForm='!ischange?"newAds":"newAddress"' @addaddress='delads()'></titleBar>

		<view class="info-container colCen">
			<view class="info-bar rowCen">
				<view class="labeltxt">
					收件人
				</view>
				<view class="inputcontent rowCen">
					<input class="uinput" type="text" v-model="name" placeholder="请输入收货人姓名" placeholder-class="placlass" />
				</view>
			</view>
			<view class="info-bar rowCen">
				<view class="labeltxt">
					手机号码
				</view>
				<view class="inputcontent rowCen">
					<input class="uinput" type="number" v-model="phone" placeholder="请输入收货人手机号码" placeholder-class="placlass" />
				</view>
			</view>

			<view class="info-bar rowCen">
				<view class="labeltxt">
					所在地区
				</view>
				<view class="inputcontent rowCenBet" @tap="selectAddress()">
					<view class="address-txt" v-if="address">
						{{address}}
					</view>
					<view class="noaddress" v-else>
						请选择地区
					</view>
					<view class="arrow iconfont">
						&#xe8d4;
					</view>
				</view>
			</view>

			<view class="info-bar rowCen">
				<view class="labeltxt">
					详细地址
				</view>
				<view class="inputcontent rowCen">
					<input class="uinput" type="text" v-model="addressdeatil" placeholder="如道路、门牌号、小区、楼栋号等" placeholder-class="placlass" />
				</view>
			</view>
		</view>

		<view class="isdefault-bar rowCenBet">
			<view class="labeltxt">
				设为默认地址
			</view>
			<u-switch v-model="isdefault" size="40" active-color="#FE5301" inactive-color="#B1B1B1"></u-switch>
		</view>

		<view class="save-bar pd30 borderBox">
			<view class="save-btn rowCenCen" @tap="submit()">
				<view>保存</view>
			</view>
		</view>

		<view>
			<u-picker v-model="show" mode="region" :area-code='defaddress' @confirm="changeArea"></u-picker>
		</view>
		<u-modal v-model="showModel" show-cancel-button :content="content" @confirm="saveaddress" :async-close="true"></u-modal>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				ischange: false,
				id: '',

				isadd: true,
				name: '',
				phone: '',
				province: '',
				city: '',
				area: '',
				address: '',
				addressdeatil: '',
				isdefault: false,

				show: false,
				showModel: false,
				isdel: false,
				content: '确认信息无误并保存？',
				defaddress: []
			}
		},
		onLoad(options) {
			if (options.id) {
				this.id = options.id
				this.ischange = true
				this.getaddressinfo()
			}
		},
		methods: {
			getaddressinfo() {
				this.$http.post('userAddress/getInfo', {
					id: this.id
				}).then(res => {
					console.log(res);
					this.address = res.province + ' ' + res.city + ' ' + res.district
					this.province = res.province
					this.city = res.city
					this.area = res.district
					this.addressdeatil = res.detail
					this.phone = res.phone
					this.name = res.realName
					this.isdefault = res.isDefault == 0 ? false : true
				})
			},

			submit() {
				if (this.name && this.phone && this.province && this.city && this.area && this.addressdeatil) {
					this.content = '确认信息无误并保存？'
					this.showModel = true
					this.isdel = false
				} else {
					uni.showToast({
						title: '请完整的填写地址信息！',
						icon: 'none'
					})
				}
			},

			saveaddress() {
				if (this.isdel) {
					this.$http.post('userAddress/delete/' + this.id).then(res => {
						this.showModel = false
						uni.navigateBack({
							delta: 1
						})
					}).catch(res => {
						this.showModel = false
					})
				} else {
					this.$http.post(this.ischange ? 'userAddress/update' : 'userAddress/save', {
						realName: this.name,
						phone: this.phone,
						province: this.province,
						city: this.city,
						district: this.area,
						detail: this.addressdeatil,
						isDefault: this.isdefault ? 1 : 0,
						id: this.id
					}, 'application/json', true).then(res => {
						console.log(res);
						this.showModel = false
						uni.navigateBack({
							delta: 1
						})
					}).catch(res => {
						this.showModel = false
					})
				}
			},

			delads() {
				this.content = '确定要删除地址嘛？'
				this.isdel = true
				this.showModel = true
			},

			selectAddress() {
				this.show = true
			},

			changeArea(e) {
				console.log(e);
				this.address = e.province.label + ' ' + e.city.label + ' ' + e.area.label
				this.province = e.province.label
				this.city = e.city.label
				this.area = e.area.label
				this.defaddress.push(e.province.value)
				this.defaddress.push(e.city.value)
				this.defaddress.push(e.area.value)
				console.log(this.defaddress);
			}
		}
	}
</script>

<style lang="scss">
	.newAddress-wrapper {
		width: 100%;

		.info-container {
			width: 100%;
			background-color: #FFFFFF;
			margin-top: 20rpx;
			margin-bottom: 40rpx;

			.info-bar {
				width: 100%;
				height: 86rpx;
				box-shadow: 0px -1rpx 0px 0px #F1F1F1;
				padding: 0 30rpx;

				.labeltxt {
					width: 150rpx;
					font-size: 28rpx;
					font-weight: 500;
					color: #333333;
					white-space: nowrap;
				}

				.inputcontent {
					width: 530rpx;

					.uinput {
						width: 100%;
						font-size: 28rpx;
						font-weight: 500;
						color: #333333;
					}

					.placlass {
						color: #999999;
					}

					.noaddress {
						font-size: 28rpx;
						font-weight: 500;
						color: #999999;
					}

					.address-txt {
						font-size: 28rpx;
						font-weight: 500;
						color: #333333;
					}

					.arrow {
						font-size: 24rpx;
						color: #999999;
					}
				}
			}
		}

		.isdefault-bar {
			width: 100%;
			height: 86rpx;
			padding: 0 30rpx;
			background-color: #FFFFFF;
			margin-bottom: 45rpx;

			.labeltxt {
				font-size: 28rpx;
				font-weight: 500;
				color: #333333;
			}
		}

		.save-bar {
			width: 100%;

			.save-btn {
				width: 100%;
				height: 86rpx;
				background: linear-gradient(-90deg, #FE5301, #FE8100);
				border-radius: 43rpx;
				font-size: 30rpx;
				font-weight: 500;
				color: #FFFFFF;
			}
		}
	}
</style>
