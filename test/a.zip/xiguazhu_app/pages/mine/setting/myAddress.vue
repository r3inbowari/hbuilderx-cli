<template>
	<view class="myAddress-wrapper wrapperLayer">
		<titleBar :titleText="'我的收货地址'" :pageForm='"myAddress"' @addaddress='goadd()'></titleBar>
		<view class="address-list-container pd20 borderBox">
			<block v-for="(items,index) in addressList" :key="index">
				<view class="address-items mg20 rowCen" @tap='saveAds(items)'>
					<view class="leftcontent colSta">
						<view class="default-icon mg20 rowCenCen" v-if="items.isDefault">
							<view>默认</view>
						</view>
						<view class="userinfo mg20 rowCen">
							<view class="name">
								{{items.realName}}
							</view>
							<view class="phone">
								{{items.phone}}
							</view>
						</view>

						<view class="addressinfo rowSta">
							<view class="tips">
								地址：
							</view>
							<view class="addresscontent">
								{{items.detail}}
							</view>
						</view>
					</view>
					<view class="rgt-btn borderBox rowCenCen" @tap.stop="exchange(items.id)">
						<view>编辑</view>
					</view>
				</view>
			</block>
		</view>

		<u-modal v-model="showModel" show-cancel-button :content="content" @confirm="confirm" :async-close="true">
		</u-modal>
	</view>
</template>

<script>
	import util from '../../../utils/utils.js'
	export default {
		data() {
			return {
				addressList: [],
				ischeck: false,
				giftinfo: '',
				eggInfo:'',
				content: '确定要使用该地址吗？',
				showModel: false,
				userAddressInfo:''
			}
		},
		onLoad(options) {
			if (options.type) {
				this.ischeck = true
			}

			if (options.guess) {
				this.giftinfo = JSON.parse(options.guess)
			} else if(options.egg){
				this.eggInfo = JSON.parse(options.egg)
			}else{
				this.giftinfo = ''
			}
		},
		onShow() {
			this.getaddress()
		},
		onPullDownRefresh() {
			this.getaddress()
		},
		methods: {
			getaddress() {
				this.$http.post('userAddress/getList').then(res => {
					console.log(res);
					uni.stopPullDownRefresh()
					this.addressList = res
				})
			},
			goadd() {
				uni.navigateTo({
					url: './newAddress'
				})
			},
			saveAds(info) {
				if (this.ischeck) {
					util.setCache('addressInfo', info)
					uni.navigateBack({
						delta: 1
					})
				}
				if (this.giftinfo || this.eggInfo) {
					console.log(info);
					this.showModel = true
					this.userAddressInfo = info
				}
			},
			exchange(id) {
				uni.navigateTo({
					url: './newAddress?id=' + id
				})
			},
			confirm() {
					this.$http.post(this.giftinfo?'blindBox/updateBox':'eggMachine/updateBox', {
						id: this.giftinfo?this.giftinfo.id:this.eggInfo.id,
						realName:this.userAddressInfo.realName,
						userPhone:this.userAddressInfo.phone,
						address:this.userAddressInfo.province + this.userAddressInfo.city + this.userAddressInfo.district + this.userAddressInfo.detail,
					},'application/json').then(res=>{
						console.log(res);
						this.showModel = false
						uni.navigateBack({
							delta:1
						})
					})
			}
		}
	}
</script>

<style lang="scss">
	.myAddress-wrapper {
		width: 100%;

		.address-list-container {
			width: 100%;
			margin-top: 20rpx;

			.address-items {
				width: 100%;
				background: #FFFFFF;
				border-radius: 16rpx;
				padding: 30rpx 0;

				.leftcontent {
					margin-left: 30rpx;
					width: 580rpx;

					.default-icon {
						width: 68rpx;
						height: 34rpx;
						background: #FF2851;
						border-radius: 6rpx;
						font-size: 24rpx;
						font-weight: 500;
						color: #FFFFFF;
					}

					.userinfo {
						line-height: 38rpx;

						.name {
							font-size: 30rpx;
							font-weight: 500;
							color: #333333;
						}

						.phone {
							font-size: 24rpx;
							color: #666666;
							margin-left: 20rpx;
						}
					}

					.addressinfo {
						width: 100%;
						font-size: 28rpx;
						font-weight: 500;
						color: #333333;

						.tips {
							white-space: nowrap;
						}

						.addresscontent {
							margin-right: 20rpx;
						}
					}
				}

				.rgt-btn {
					width: 110rpx;
					border-left: 2rpx solid #F1F1F1;
					font-size: 28rpx;
					font-weight: 500;
					color: #FF2851;
				}
			}
		}
	}
</style>
