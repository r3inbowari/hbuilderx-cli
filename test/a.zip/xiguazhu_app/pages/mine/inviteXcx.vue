<template>
	<view class="inviteFriends-wrapper wrapperLayer" style="height: 100vh;">
		<titleBar :titleText='"邀请好友"' :pageForm='"inviteFriends"'></titleBar>
		<view class="topfixed">
			<view class="rowCenAro" style="height: 88rpx;line-height: 88rpx;color: #999;font-weight: bold;">
				<view :class="curIndex==type?'itemActive':''" @click="tabChange(type)">邀友领红包</view>
				<view :class="curIndex==5?'itemActive':''" @click="tabChange(5)">招募合伙人</view>
			</view>
		</view>
		<!-- <view class="swiper-container">
			<view class="tower-swiper" @touchmove="TowerMove" @touchstart="TowerStart" @touchend="TowerEnd">
				<view class="tower-item" :class="item.zIndex==1?'none':''" v-for="(item,index) in swiperList" :key="index" :style="[{'--index': item.zIndex,'--left':item.mLeft}]"
				 :data-direction="direction">
					<view class="swiper-item">
						<image :src="item.imgUrl" mode="aspectFill"></image>
						<view class="code rowCenCen">
							<image :src="codeSrc" mode="aspectFill"></image>
						</view>
					</view>
				</view>
			</view>
		</view> -->
		<view class="swiper-container">
			<view class="tower-swiper" @touchmove="TowerMove" @touchstart="TowerStart" @touchend="TowerEnd">
				<view class="tower-item" :class="item.zIndex==1?'none':''" v-for="(item,index) in swiperList"
					:key="index" :style="[{'--index': item.zIndex,'--left':item.mLeft}]" :data-direction="direction">
					<view class="swiper-item">
						<image :src="item.imgUrl" mode="aspectFill"></image>
						<view class="code rowCenCen">
							<image :src="codeSrc" mode="aspectFill"></image>
						</view>
					</view>
				</view>
			</view>
		</view>

		<view class="pagebottom-container pd30 colCen">
			<view class="rowCenBet" style="width: 650rpx;">
				<view
					style="width: 300rpx;height: 80rpx;line-height: 80rpx;border-radius: 40rpx;text-align: center;border: 2rpx solid #000;"
					@tap='saveQr()'>仅保存二维码</view>
				<view
					style="width: 300rpx;height: 80rpx;line-height: 80rpx;border-radius: 40rpx;text-align: center;border: 2rpx solid #000;background-color: #f79273;"
					@tap='showModel()'>保存海报</view>
			</view>
		</view>


		<u-popup v-model="shareShow" mode="bottom" border-radius="14" height="auto">
			<view class="share-container colCen">
				<view class="share-title rowCenCen">
					<view class="title-text">
						分享到
					</view>
				</view>
				<view class="shareList rowCen">
					<view class="items-container colCen" @tap='sharewx()'>
						<view class="icon-box defIcon">
							<image src="../../static/images/mine/wxshare.png" mode=""></image>
						</view>
						<view class="modeName">
							微信好友
						</view>
					</view>
					<view class="items-container colCen" @tap='sharepyq()'>
						<view class="icon-box defIcon">
							<image src="../../static/images/mine/sharefriend.png" mode=""></image>
						</view>
						<view class="modeName">
							朋友圈
						</view>
					</view>
					<view class="items-container colCen" @tap='shareqq()'>
						<view class="icon-box defIcon">
							<image src="../../static/images/mine/shareqq.png" mode=""></image>
						</view>
						<view class="modeName">
							QQ
						</view>
					</view>
					<view class="items-container colCen" @tap='savepic()'>
						<view class="icon-box defIcon">
							<image src="../../static/images/app/saveimg.png" mode=""></image>
						</view>
						<view class="modeName">
							保存相册
						</view>
					</view>
				</view>

				<view class="cancelbox rowCenCen" @click="closeModel()">
					<view class="canceltext">
						取消
					</view>
				</view>
			</view>
		</u-popup>
		<canvas canvas-id="qrcode" class="canvass" style="width: 260rpx;height: 260rpx;opacity: 0;" />
		<canvas canvas-id="sharePoster" class="canvass"
			:style="{ width: canvasInfo.canvasW + 'px', height: canvasInfo.canvasH + 'px'}" />
	</view>
</template>

<script>
	import util from '../../utils/utils.js'
	import uQRCode from '../../utils/qrcode.js'
	let qrcode
	export default {
		data() {
			return {
				curIndex: 6,
				type: 6,
				code: '',
				codeSrc: '',
				direction: '',
				userInfo: '',
				swiperList: [],

				shareShow: false,
				bannerUrl: '',

				CVS: null,
				canvasInfo: {
					canvasW: 750,
					canvasH: 1334,
				},
				shareUrl: '',

				qrCode: null,
			}
		},
		onLoad(e) {
			if (e.type) {
				this.type = e.type;
				this.curIndex = e.type;
			}
			if (e.qrCode) {
				this.qrCode = e.qrCode;
			}
			this.$nextTick(() => {
				this.getpageInfo(this.curIndex)
				this.userInfo = util.getCacheSync('userData')
				if (this.curIndex == 5) {
					this.makeCode();
				} else {
					this.codeSrc = e.qrCode;
				}
			})
		},
		methods: {
			tabChange(index) {
				this.curIndex = parseInt(index);
				this.getpageInfo(this.curIndex)
				if (this.curIndex == 5) {
					this.makeCode();
				} else {
					this.codeSrc = this.qrCode;
				}
			},
			showModel() {
				this.$nextTick(() => {
					this.getbanner()
				})
			},
			closeModel() {
				this.shareShow = false
			},

			async getbanner() {
				uni.showLoading()
				let goodsPic = await this.getImageInfo(this.bannerUrl) //广告图
				this.CVS = uni.createCanvasContext('sharePoster', this);
				this.canvasInfo.canvasW = 750
				this.canvasInfo.canvasH = 1334
				this.CVS.setFillStyle('white'); //canvas背景颜色
				this.CVS.fillRect(0, 0, 750, 1334); //canvas画布大小 

				this.CVS.drawImage(goodsPic.path, 0, 0, 750, 1334);
				this.CVS.drawImage(this.codeSrc, 240, 580, 270, 270);
				
				this.CVS.setTextAlign('center');
				console.log("this.curIndex================="+this.curIndex) 
				if(this.curIndex == 5){
					this.CVS.setFontSize(28); //设置标题字体大小
					this.CVS.fillText('邀请码：' + this.userInfo.inviteCode, 374, 1273); 
				}
				

				this.CVS.draw(false, res => {
					uni.canvasToTempFilePath({
						canvasId: 'sharePoster',
						success: ress => {
							uni.hideLoading()
							this.shareShow = true
							this.shareUrl = ress.tempFilePath
						}
					});
				});
			},

			async getImageInfo(imgSrc) {
				return new Promise((resolve, errs) => {
					uni.getImageInfo({
						src: imgSrc,
						success: image => {
							resolve(image);
						},
						fail: err => {
							errs(err);
							uni.hideLoading()
						}
					});
				});
			},

			async makeCode() {
				var txt = getApp().globalData.appinfo.appAndroidDownUrl
				// #ifdef APP-PLUS
				txt = plus.os.name == 'Android' ? getApp().globalData.appinfo.appAndroidDownUrl : getApp().globalData
					.appinfo.appIosDownUrl, // 生成内容
					// #endif
					qrcode = new uQRCode({
						context: this, // 上下文环境
						canvasId: 'qrcode', // canvas-id
						usingComponents: false, // 是否是自定义组件
						loadingText: '', // loading文字
						text: txt, // 生成内容
						size: uni.upx2px(260), // 二维码大小
						cbResult: res => { // 生成二维码的回调
							this.codeSrc = res
						},
					});
			},
			copyLink() {
				// #ifdef APP-PLUS
				var txtdata
				if (plus.os.name == 'Android') {
					txtdata = getApp().globalData.appinfo.appName + '的下载链接为：' + getApp().globalData.appinfo
						.appAndroidDownUrl +
						'\n邀请码：' + this.userInfo.inviteCode
				} else {
					txtdata = getApp().globalData.appinfo.appName + '的下载链接为：' + getApp().globalData.appinfo.appIosDownUrl +
						'\n邀请码：' +
						this.userInfo.inviteCode
				}
				uni.setClipboardData({
					data: txtdata,
					success: res => {
						uni.showToast({
							title: '邀请链接已复制~快去分享给好友吧！',
							icon: 'none'
						})
						uni.setStorageSync('clipboard', txtdata);
					}
				});
				// #endif
			},

			clipcode() {
				uni.setClipboardData({
					data: this.userInfo.inviteCode,
					success: res => {
						uni.showToast({
							title: '邀请码已复制~快去分享给好友吧！',
							icon: 'none'
						})
						uni.setStorageSync('clipboard', this.userInfo.inviteCode);
					}
				});
			},

			getpageInfo(curIndex) {
				this.$http.get('cpssystemConfig/getImgList', {
					type: curIndex
				}).then(res => {
					this.swiperList = res
					this.TowerSwiper('swiperList');
				})
			},


			sharewx() {
				uni.share({
					provider: "weixin",
					scene: "WXSceneSession",
					type: 2,
					imageUrl: this.shareUrl,
					success: function(res) {
						console.log("success:" + JSON.stringify(res));
					},
					fail: function(err) {
						console.log("fail:" + JSON.stringify(err));
					}
				});
			},

			sharepyq() {
				uni.share({
					provider: "weixin",
					scene: "WXSenceTimeline",
					type: 2,
					imageUrl: this.shareUrl,
					success: function(res) {
						console.log("success:" + JSON.stringify(res));
					},
					fail: function(err) {
						console.log("fail:" + JSON.stringify(err));
					}
				});
			},

			shareqq() {
				uni.share({
					provider: "qq",
					type: 2,
					imageUrl: this.shareUrl,
					success: function(res) {
						console.log("success:" + JSON.stringify(res));
					},
					fail: function(err) {
						console.log("fail:" + JSON.stringify(err));
					}
				});
			},

			savepic() {
				uni.saveImageToPhotosAlbum({
					filePath: this.shareUrl,
					success: res => {
						uni.showToast({
							title: '保存相册成功~',
							icon: 'none'
						})
						this.closeModel()
					},
					fail(err) {
						console.log(err);
					},
				});
			},
			saveQr() {
				uni.saveImageToPhotosAlbum({
					filePath: this.codeSrc,
					success: res => {
						uni.showToast({
							title: '保存相册成功~',
							icon: 'none'
						})
						this.closeModel()
					},
					fail(err) {
						console.log(err);
					},
				});
			},


			DotStyle(e) {
				this.dotStyle = e.detail.value
			},
			// cardSwiper
			cardSwiper(e) {
				this.cardCur = e.detail.current
			},
			// towerSwiper
			// 初始化towerSwiper
			TowerSwiper(name) {
				let list = this[name];
				for (let i = 0; i < list.length; i++) {
					list[i].zIndex = parseInt(list.length / 2) + 1 - Math.abs(i - parseInt(list.length / 2))
					list[i].mLeft = i - parseInt(list.length / 2)
				}
				this.swiperList = list
				this.swiperList.forEach((items, index) => {
					if (items.mLeft == 0) {
						this.bannerUrl = items.imgUrl
					}
				})
			},

			// towerSwiper触摸开始
			TowerStart(e) {
				this.towerStart = e.touches[0].pageX
			},

			// towerSwiper计算方向
			TowerMove(e) {
				this.direction = e.touches[0].pageX - this.towerStart > 0 ? 'right' : 'left'
			},

			// towerSwiper计算滚动
			TowerEnd(e) {
				let direction = this.direction;
				let list = this.swiperList;
				if (direction == 'right') {
					let mLeft = list[0].mLeft;
					let zIndex = list[0].zIndex;
					for (let i = 1; i < this.swiperList.length; i++) {
						this.swiperList[i - 1].mLeft = this.swiperList[i].mLeft
						this.swiperList[i - 1].zIndex = this.swiperList[i].zIndex
					}
					this.swiperList[list.length - 1].mLeft = mLeft;
					this.swiperList[list.length - 1].zIndex = zIndex;
				} else {
					let mLeft = list[list.length - 1].mLeft;
					let zIndex = list[list.length - 1].zIndex;
					for (let i = this.swiperList.length - 1; i > 0; i--) {
						this.swiperList[i].mLeft = this.swiperList[i - 1].mLeft
						this.swiperList[i].zIndex = this.swiperList[i - 1].zIndex
					}
					this.swiperList[0].mLeft = mLeft;
					this.swiperList[0].zIndex = zIndex;
				}
				this.direction = ""
				this.swiperList.forEach((items, index) => {
					if (items.mLeft == 0) {
						this.bannerUrl = items.imgUrl
					}
				})
			},
		}
	}
</script>

<style>
	page {
		background-color: #FFFFFF;
	}
</style>
<style lang="scss">
	.topfixed {
		position: fixed;
		top: calc(var(--status-bar-height) + 44px);
		left: 0;
		width: 100vw;
		z-index: 10;
		background-color: #FFFFFF;
	}

	.itemActive {
		color: #ff0000;
		position: relative;
	}

	.itemActive::after {
		content: "";
		position: absolute;
		width: 50%;
		height: 4rpx;
		background-color: #ff0000;
		left: 0;
		right: 0;
		bottom: 4rpx;
		margin: auto;
	}

	.inviteFriends-wrapper {
		width: 100%;

		.swiper-container {
			margin: 80rpx 0 30rpx;
			width: 100%;
			height: 1100rpx;

			.tower-swiper {
				height: 100%;

				.tower-item {
					width: 600rpx;
					height: 100%;
					left: 35%;

					.swiper-item {
						position: relative;

						.code {
							position: absolute;
							width: 99%;
							bottom: 395rpx;

							image {
								width: 240rpx;
								height: 240rpx;
								z-index: 10;
							}
						}
					}
				}
			}
		}

		.pagebottom-container {
			width: 100%;
			margin-bottom: 260rpx;

			.inviteCode-container {
				width: 100%;
				height: 86rpx;
				background: #FFFFFF;
				border-radius: 16rpx;

				.left-code {
					font-size: 28rpx;
					font-weight: 500;
					color: #333333;
				}

				.clipbtn {
					width: 122rpx;
					height: 52rpx;
					background: linear-gradient(0deg, #7A11F2, #D31BF7);
					border-radius: 26rpx;
					font-size: 28rpx;
					font-weight: 500;
					color: #FFFFFF;
				}
			}

			.invite-step {
				width: 100%;
				margin-top: 30rpx;
				background-color: #FFFFFF;
				border-radius: 16rpx;
				padding: 30rpx;

				.step-title {
					width: 100%;
				}

				.step-list {
					font-size: 24rpx;
					font-weight: 500;
					color: #666666;
					line-height: 38rpx;
					margin-top: 25rpx;
				}
			}

			.bottom-options-container {
				width: 100%;
				background: #FFFFFF;
				border-radius: 16rpx;
				padding: 20rpx 0;
				position: fixed;
				bottom: 0;

				.option-items-container {
					.icon-box {
						width: 96rpx;
						height: 96rpx;
					}

					.option-name {
						font-size: 24rpx;
						font-weight: 500;
						color: #333333;
					}

					.option-explain {
						font-size: 22rpx;
						font-weight: 500;
						color: #666666;
					}
				}
			}
		}
	}

	.tower-swiper .tower-item {
		transform: scale(calc(0.65 + var(--index) / 10));
		margin-left: calc(var(--left) * 570upx - 184upx);
		z-index: var(--index);
	}

	.share-container {
		width: 100%;

		.share-title {
			width: 100%;
			height: 90rpx;
			flex-wrap: wrap;
			border-bottom: 1rpx solid #EFF1F7;

			.title-text {
				font-size: 28rpx;
				font-weight: 500;
				color: #333333;
			}
		}

		.shareList {
			width: 100%;
			flex-wrap: wrap;
			border-bottom: 1rpx solid #EFF1F7;
			margin-top: 45rpx;

			.items-container {
				width: 25%;
				margin-bottom: 30rpx;

				.icon-box {
					width: 95rpx;
					height: 95rpx;
				}

				.modeName {
					font-size: 24rpx;
					font-weight: 500;
					color: #333333;
					margin-top: 15rpx;
				}
			}
		}

		.cancelbox {
			width: 100%;
			height: 90rpx;

			.canceltext {
				font-size: 28rpx;
				font-weight: 500;
				color: #333333;
			}
		}
	}

	.canvass {
		opacity: 0;
		position: fixed;
		pointer-events: none;
		bottom: 0;
		left: 0;
	}
</style>
