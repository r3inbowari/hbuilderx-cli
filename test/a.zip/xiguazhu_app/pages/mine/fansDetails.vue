<template>
	<view class="fansDetails-wrapper wrapperLayer">
		<titleBar :titleText="ncName+'的粉丝'" :pageForm='"fans"'></titleBar>
		<view class="fansList-container colCen borderBox" v-if="fansList">
			<block v-for="(items,index) in fansList" :key="index">
				<view class="fans-items rowCenBet" @tap="goFansDetails()">
					<view class="itm-left rowCen">
						<view class="avator-box defIcon">
							<image :src="items.avatar" mode="aspectFill"></image>
						</view>
						<view class="name-level-time">
							<view class="name-level rowCen">
								<view class="namebox">
									{{items.nickName}}
								</view>
								<view class="levelbox rowCenCen">
									<view>{{items.levelName}}</view>
								</view>
							</view>
							<view class="timebox">
								{{items.createTime}}
							</view>
						</view>
					</view>
		
					<view class="itm-right colEnd">
						<!-- <view class="inviteInfo rowCen">
							<view class="invite">
								邀请{{items.inCount}}人
							</view>
						</view> -->
						<view class="phone-effect rowCen">
							<view class="phone" v-text="items.account"></view>
							<view class="effect">
								{{items.tradeParentId!='0'?'有':'无'}}效
							</view>
						</view>
					</view>
				</view>
			</block>
			<aLoadMore :status="loadstate" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
		</view>
	</view>
</template>

<script>
	export default{
		data(){
			return{
				fansList: [],
				ncName:'',
				memberId:'',
				
				loadstate: 'nomore',
				pageCurrent: 0,
				canload: false
			}
		},
		onLoad(options) {
			console.log(JSON.parse(options.info));
			this.memberId = JSON.parse(options.info).memberId
			this.ncName = JSON.parse(options.info).nickName
			this.getList()
		},
		
		onReachBottom() {
			if(this.canload){
				this.getList()
			}
		},
		
		methods:{
			getList(){
				this.$http.post('member/getFansZ', {
					limit:10,
					offset:this.pageCurrent,
					type:0,
					memberId:this.memberId
				},'application/json').then((res) => {
					console.log(res);
					uni.stopPullDownRefresh()
					if(res.length<10){
						this.loadstate = 'nomore'
						this.canload = false
					}else{
						this.loadstate = 'loading'
						this.canload = true
						this.pageCurrent+=10
					}
					this.fansList = this.fansList.concat(res)
				})
			},
		},
		onPullDownRefresh() {
			this.fansList = []
			this.canload = false
			this.pageCurrent = 0
			this.loadstate = 'loading'
			this.getList()
		}
	}
</script>

<style lang="scss">
	.fansDetails-wrapper{
		width: 100%;
		.fansList-container {
			width: 100%;
			padding: 0 30rpx;
			margin-top: 20rpx;
		
			.fans-items {
				width: 100%;
				height: 125rpx;
				background: #FFFFFF;
				border-radius: 16rpx;
				margin-bottom: 20rpx;
				padding: 0 30rpx;
		
				.itm-left {
					height: 100%;
		
					.avator-box {
						width: 80rpx;
						height: 80rpx;
						border-radius: 50%;
						overflow: hidden;
					}
		
					.name-level-time {
						margin-left: 20rpx;
		
						.name-level {
							.namebox {
								font-size: 26rpx;
								font-weight: bold;
								margin-right: 30rpx;
								color: #333333;
							}
		
							.levelbox {
								width: 90rpx;
								height: 34rpx;
								background: linear-gradient(0deg, #F7C394, #EFE0D6);
								border-radius: 17rpx;
								font-size: 22rpx;
								font-weight: 500;
								color: #613309;
							}
						}
		
						.timebox {
							font-size: 20rpx;
							font-weight: 500;
							color: #999999;
							margin-top: 15rpx;
						}
					}
				}
		
				.itm-right {
					.inviteInfo {
						.invite {
							font-size: 24rpx;
							font-weight: 500;
							color: #333333;
							margin-right: 15rpx;
						}
		
						.arrow {
							font-size: 20rpx;
							font-weight: 500;
							color: #333333;
							margin-top: 3rpx;
						}
					}
		
					.phone-effect {
						margin-top: 10rpx;
		
						.phone {
							font-size: 24rpx;
							font-weight: 500;
							color: #333333;
							margin-right: 20rpx;
						}
		
						.effect {
							font-size: 24rpx;
							font-weight: 500;
							color: #FF2851;
						}
					}
				}
			}
		}
	}
</style>
