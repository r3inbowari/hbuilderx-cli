<template>
	<view class="myProfit-wrapper wrapperLayer">
		<titleBar :titleText='"我的收益"' :pageForm='"myProfit"'></titleBar>
		<view class="top-bac-container colCen">
			<view class="total-profit">
				{{pageData.sumMoney}}
			</view>
			<view class="totaltips">
				累计收益(元)
			</view>

			<view class="screenbar-container rowCen borderBox">
				<view class="screen-bar-bac rowCenBet">
					<block v-for="(items,index) in screenList" :key="index">
						<view class="screen-items colCenBet" @tap="scrProfit(index)">
							<view class="bdr"></view>
							<view>{{items.txt}}</view>
							<view class="bdr" :style="'background-color:'+(screenCurrent==index?'#FF2851':'')"></view>
						</view>
					</block>
				</view>
			</view>
		</view>
		
		<view class="pagebottom-container colCen borderBox" v-if="pageData">
			<view class="extension-container colCen">
				<view class="title-bar">
					我的推广
				</view>
				<view class="extension-infobar rowCenBet">
					<view class="itm-box1 colCen">
						<view class="txt">
							订单笔数
						</view>
						<view class="num">
							{{pageData.my.orderCount}}
						</view>
					</view>
					<view class="itm-box1 colCen">
						<view class="txt">
							预估收益
						</view>
						<view class="num">
							{{pageData.my.estimatedRevenue}}
						</view>
					</view>
					<view class="itm-box1 colCen">
						<view class="txt">
							销售额
						</view>
						<view class="num">
							{{pageData.my.effectiveSales}}
						</view>
					</view>
				</view>
				<view class="title-bar">
					团队推广
				</view>
				<view class="extension-infobar rowCenBet">
					<view class="itm-box1 colCen">
						<view class="txt">
							订单笔数
						</view>
						<view class="num">
							{{pageData.team.orderCount}}
						</view>
					</view>
					<view class="itm-box1 colCen">
						<view class="txt">
							预估收益
						</view>
						<view class="num">
							{{pageData.team.estimatedRevenue}}
						</view>
					</view>
					<view class="itm-box1 colCen">
						<view class="txt">
							销售额
						</view>
						<view class="num">
							{{pageData.team.effectiveSales}}
						</view>
					</view>
				</view>
			</view>
			
			<view class="order-extension-container">
				<view class="title">
					自推订单收益
				</view>
				<view class="header-title rowCenBet">
					<view class="box2 rowCenCen">
						<view>平台</view>
					</view>
					<view class="box2 rowCenCen">
						<view>付款笔数</view>
					</view>
					<view class="box2 rowCenCen">
						<view>预估收益</view>
					</view>
					<view class="box2 rowCenCen">
						<view>销售额</view>
					</view>
				</view>
				<view class="platform-bar rowCen" v-for="(items,index) in pageData.myData" @tap="goOrder()">
					<view class="box3 rowCenCen">
						<view>{{items.name}}</view>
					</view>
					<view class="box3 rowCenCen">
						<view>{{items.orderCount}}</view>
					</view>
					<view class="box3 rowCenCen">
						<view>{{items.estimatedRevenue}}</view>
					</view>
					<view class="box3 rowCenEnd">
						<view>{{items.effectiveSales}}</view>
						<view class="arrow iconfont">
							&#xe8d4;
						</view>
					</view>
				</view>
			</view>
			
			<view class="order-extension-container">
				<view class="title">
					团队订单收益
				</view>
				<view class="header-title rowCenBet">
					<view class="box2 rowCenCen">
						<view>平台</view>
					</view>
					<view class="box2 rowCenCen">
						<view>付款笔数</view>
					</view>
					<view class="box2 rowCenCen">
						<view>预估收益</view>
					</view>
					<view class="box2 rowCenCen">
						<view>销售额</view>
					</view>
				</view>
				<view class="platform-bar rowCen" v-for="(items,index) in pageData.teamData" @tap="goOrder()">
					<view class="box3 rowCenCen">
						<view>{{items.name}}</view>
					</view>
					<view class="box3 rowCenCen">
						<view>{{items.orderCount}}</view>
					</view>
					<view class="box3 rowCenCen">
						<view>{{items.estimatedRevenue}}</view>
					</view>
					<view class="box3 rowCenEnd">
						<view>{{items.effectiveSales}}</view>
						<view class="arrow iconfont">
							&#xe8d4;
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				screenCurrent: 0,
				screenList: [{
						txt: "今日",
						type: 0
					},
					{
						txt: "昨日",
						type: 1
					},
					{
						txt: "本月",
						type: 2
					},
					{
						txt: "上月",
						type: 3
					},
				],
				
				pageData:''
			}
		},
		onLoad() {
			this.getPageInfo()
		},
		methods: {
			getPageInfo(){
				this.$http.get('member/getMyIncome',{type:this.screenCurrent}).then(res=>{
					uni.stopPullDownRefresh()
					console.log(res);
					this.pageData = res
				})
			},
			scrProfit(idx) {
				this.screenCurrent = idx
				this.getPageInfo()
			},
			goOrder(){
				uni.navigateTo({
					url:"./myOrder"
				})
			}
		},
		onPullDownRefresh() {
			this.getPageInfo()
		}
	}
</script>

<style lang="scss">
	.myProfit-wrapper {
		width: 100%;
		min-height: 100vh;

		.top-bac-container {
			width: 100%;
			height: 250rpx;
			background: linear-gradient(180deg, #FBDD37, #FBAC3A);
			position: relative;

			.total-profit {
				font-size: 48rpx;
				font-weight: bold;
				color: #FFFFFF;
				margin-top: 50rpx;
			}

			.totaltips {
				font-size: 28rpx;
				color: #FFFFFF;
			}

			.screenbar-container {
				width: 100%;
				padding: 0 30rpx;
				position: absolute;
				bottom: -43rpx;
				z-index: 1;

				.screen-bar-bac {
					width: 100%;
					height: 86rpx;
					background: #FFFFFF;
					border-radius: 16rpx;
					padding: 0 80rpx;
					box-shadow: 0px 0px 10rpx 0px rgba(202, 202, 202, 0.52);

					.screen-items {
						height: 100%;

						.bdr {
							width: 42rpx;
							height: 4rpx;
							border-radius: 2rpx;
							border-radius: 2rpx;
						}
					}
				}
			}
		}
		
		.pagebottom-container{
			width: 100%;
			padding: 0 30rpx;
			margin-top: 60rpx;
			.extension-container{
				width: 100%;
				height: 420rpx;
				background: #FFFFFF;
				border-radius: 16rpx;
				padding: 0 28rpx;
				margin-bottom: 20rpx;
				.title-bar{
					width: 100%;
					font-size: 30rpx;
					font-weight: bold;
					color: #333333;
					margin: 30rpx 0;
				}
				.extension-infobar{
					width: 100%;
					margin-bottom: 10rpx;
					.itm-box1{
						width: 150rpx;
						.txt{
							font-size: 26rpx;
							font-weight: 500;
							color: #333333;
						}
						.num{
							font-size: 26rpx;
							font-weight: bold;
							color: #333333;
							white-space: nowrap;
							margin-top: 10rpx;
						}
					}
				}
			}
			
			.order-extension-container{
				width: 100%;
				background: #FFFFFF;
				border-radius: 16rpx;
				margin-bottom: 20rpx;
				.title{
					font-size: 30rpx;
					font-weight: bold;
					color: #333333;
					padding: 30rpx 30rpx;
				}
				.header-title{
					width: 100%;
					height: 86rpx;
					.box2{
						width: 25%;
						font-size: 22rpx;
						font-weight: 500;
						color: #666666;
					}
				}
				
				.platform-bar{
					width: 100%;
					height: 86rpx;
					border-bottom: 1rpx solid #F7F7F7;
					.box3{
						width: 25%;
						font-size: 28rpx;
						font-weight: 500;
						color: #333333;
						.arrow {
							font-size: 20rpx;
							font-weight: 500;
							color: #333333;
							margin-top: 3rpx;
							margin-left: 15rpx;
							margin-right: 30rpx;
						}
					}
				}
			}
		}
	}
</style>
