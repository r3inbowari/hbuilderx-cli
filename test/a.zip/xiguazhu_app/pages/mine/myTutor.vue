<template>
	<view class="myTutor-wrapper wrapperLayer">
		<titleBar :titleText='"我的导师"' :pageForm='"myStore"'></titleBar>
		<image class="pageTop-bac" src="https://hxshapp.oss-cn-beijing.aliyuncs.com/app/img/20210407/tutor.png"
			mode="aspectFill"></image>
		<view class="page-list colCen borderBox">
			<view class="abs-container colCen borderBox">
				<view class="card-items colCen borderBox">
					<view class="card-title rowCen">
						我的导师
					</view>
					<view class="info-content rowStaBet">
						<view class="left-content rowCen">
							<image class="ava-pic" :src="pageInfo.tutorHead" mode="aspectFill"></image>
							<view class="userInfo-content">
								<view class="user-name">
									{{pageInfo.tutorName}}
								</view>
								<view class="wechatnum">
									微信号:{{pageInfo.tutorWeChat}}
								</view>
							</view>
						</view>
						<view class="addBtn rowCenCen" @tap="copywx()">
							<view>添加导师微信</view>
						</view>
					</view>
				</view>

				<view class="card-items colCen borderBox">
					<view class="card-title rowCen">
						<view class="title">
							我的微信
						</view>
						<view class="ft-tips">
							填写微信号，方便导师找到你
						</view>
					</view>
					<view class="info-content rowStaBet">
						<view class="left-content rowCen">
							<image class="ava-pic" :src="pageInfo.myHead" mode="aspectFill"></image>
							<view class="userInfo-content">
								<view class="user-name">
									{{pageInfo.myName}}
								</view>
								<view class="wechatnum" v-if="pageInfo.myWeChat">
									微信号:{{pageInfo.myWeChat}}
								</view>
							</view>
						</view>
						<view class="addBtn rowCenCen" @tap="()=>{modelShow=true}">
							<view>填写微信号</view>
						</view>
					</view>
				</view>
			</view>
		</view>

		<u-popup v-model="modelShow" mode="center" border-radius="32" :mask-close-able='true'>
			<view class="alert-contaienr colCen borderBox">
				<view class="title rowCenCen">
					<view>填写微信号</view>
				</view>
				<view class="input-content rowCen">
					<input class="ipt" type="text" v-model="wxchat" placeholder="请填写正确的微信号" placeholder-class="plainput"/>
				</view>
				<view class="confirm-btn rowCenCen" @tap="setWx()">
					<view>完 成</view>
				</view>
				<view class="back-btn" @tap="()=>{modelShow=false}">
					下次再说
				</view>
			</view>
		</u-popup>
	</view>
</template>

<script>
	import util from '../../utils/utils.js'
	export default {
		data() {
			return {
				pageInfo: '',
				modelShow: false,
				wxchat:''
			}
		},
		onLoad() {
			this.getTutor()
		},
		methods: {
			getTutor() {
				this.$http.get('member/myTutor').then(res => {
					console.log(res);
					this.pageInfo = res
				})
			},
			setWx() {
				this.$http.post('member/updateMember',{
					tutorWechat:this.wxchat
				},'application/json').then(res=>{
					console.log(res);
					util.setCache('userData', res)
					uni.showToast({
						title:'填写成功！',
						icon:'none'
					})
					this.modelShow = false
				})
			},
			copywx(){
				uni.setClipboardData({
					data:this.pageInfo.tutorWeChat,
					success:()=> {
						uni.showToast({
							title:'复制成功，快去添加导师微信吧~',
							icon:'none' 
						})
					}
				})
			}
		}
	}
</script>

<style lang="scss">
	.myTutor-wrapper {
		width: 100%;
		min-height: 100vh;

		.pageTop-bac {
			width: 100%;
			height: 320rpx;
		}

		.page-list {
			width: 100%;
			position: relative;

			.abs-container {
				width: 100%;
				position: absolute;
				top: -40rpx;
				z-index: 10;
				padding: 0 26rpx;

				.card-items {
					width: 100%;
					height: 244rpx;
					background: #FFFFFF;
					border-radius: 16rpx;
					padding: 0 30rpx;
					margin-bottom: 20rpx;

					.card-title {
						width: 100%;
						height: 100rpx;
						font-size: 28rpx;
						font-weight: bold;
						color: #333333;

						.title {
							font-size: 28rpx;
							font-weight: 500;
							color: #333333;
						}

						.ft-tips {
							font-size: 24rpx;
							font-weight: 500;
							color: #666666;
							margin-left: 20rpx;
						}
					}

					.info-content {
						width: 100%;

						.left-content {
							.ava-pic {
								width: 100rpx;
								height: 100rpx;
								border-radius: 50%;
							}

							.userInfo-content {
								margin-left: 30rpx;

								.user-name {
									font-size: 32rpx;
									font-weight: 500;
									color: #333333;
								}

								.wechatnum {
									font-size: 26rpx;
									font-weight: 500;
									color: #FE3738;
									margin-top: 15rpx;
								}
							}
						}

						.addBtn {
							width: 208rpx;
							height: 50rpx;
							background: #FF053A;
							border-radius: 25rpx;
							font-size: 26rpx;
							font-weight: 500;
							color: #FFFEFE;
						}
					}
				}
			}
		}
		
		.alert-contaienr{
			width: 565rpx;
			padding: 0 42rpx;
			.title{
				width: 100%;
				height: 100rpx;
				font-size: 26rpx;
				font-weight: 500;
				color: #333333;
			}
			.input-content{
				width: 100%;
				background-color: #F6F8F7;
				height: 80rpx;
				border-radius: 40rpx;
				padding: 0 30rpx;
				margin-bottom: 40rpx;
				.ipt{
					font-size: 24rpx;
					font-weight: 500;
					color: #333333;
					flex: 1;
				}
			}
			
			.confirm-btn{
				width: 100%;
				height: 80rpx;
				background-color: #FF0060;
				border-radius: 40rpx;
				font-size: 28rpx;
				font-weight: 500;
				color: #FFFFFF;
				margin-bottom: 40rpx;
			}
			
			.back-btn{
				font-size: 22rpx;
				font-weight: 500;
				color: #BEBEBE;
				margin-bottom: 40rpx;
			}
		}
	}
</style>
