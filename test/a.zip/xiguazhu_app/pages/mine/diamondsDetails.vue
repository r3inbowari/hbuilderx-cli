<template>
	<view class="diamondsDetails-wrapper wrapperLayer">
		<titleBar :titleText="'钻石明细'" :pageForm='"diamondsDetails"'></titleBar>

		<view class="pageList pd20 colCen">
			<block v-for="(items,index) in goodsList" :key="index">
				<view class="itm-card mg20 rowCenBet">
					<view class="left-content">
						<view class="itm-name">
							{{items.title}}
						</view>
						<view class="time">
							{{items.createTime}}
						</view>
					</view>

					<view class="right-num colCen" :style="items.changeType==1?'color: #FF2851;':'color: #333333;'">
						<view>{{items.changeType==1?'+'+items.number:'-'+ items.number}}</view>
						<view class="diamonStates" v-if="items.changeType==1" style="font-size: 24rpx;">{{items.statust==1?'待到账':(items.statust==2?'已到账':'已失效')}}</view>
					</view>
				</view>
			</block>
			<aLoadMore :status="loadstate" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				goodsList: [],
				
				loadstate: 'loading',
				pageCurrent: 0,
				canload: false
			}
		},
		onLoad() {
			this.getList()
		},
		onReachBottom() {
			if (this.canload) {
				this.getList()
			}
		},
		methods:{
			getList() {
				this.$http.post('diamond/getDiamondDetails',{
					limit:10,
					offset:this.pageCurrent
				},'application/json').then(res => {
					uni.stopPullDownRefresh()
					if(res.length<10){
						this.canload = false
						this.loadstate = 'nomore'
					}else{
						this.canload = true
						this.loadstate = 'loading'
						this.pageCurrent +=10
					}
					this.goodsList = this.goodsList.concat(res)
				})
			},
		},
		onPullDownRefresh() {
			this.canload = false
			this.pageCurrent = 0
			this.loadstate = 'loading'
			this.goodsList = []
			this.getList()
		}
	}
</script>

<style lang="scss">
	.diamondsDetails-wrapper {
		width: 100%;

		.pageList {
			width: 100%;
			margin-top: 20rpx;

			.itm-card {
				width: 100%;
				height: 133rpx;
				background: #FFFFFF;
				border-radius: 16rpx;
				padding: 0 30rpx;

				.left-content {
					.itm-name {
						width: 474rpx;
						font-size: 28rpx;
						font-weight: 500;
						color: #333333;
						overflow: hidden;
						text-overflow: ellipsis;
						white-space: nowrap;
					}

					.time {
						font-size: 20rpx;
						font-weight: 500;
						color: #666666;
						margin-top: 20rpx;
					}
				}
			}
		}
	}
</style>
