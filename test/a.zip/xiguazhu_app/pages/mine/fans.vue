<template>
	<view class="fans-wrapper wrapperLayer">
		<titleBar :titleText='"粉丝"' :pageForm='"fans"'></titleBar>
		<view class="top-info-card colCen borderBox">
			<view class="top-color-container colCen borderBox">
				<view class="fans-content colCen">
					<view class="fans-num">
						{{pageData.allCount}}
					</view>
					<view class="fans-txt">
						我的粉丝
					</view>
				</view>

				<view class="data-content rowCenBet">
					<view class="itm-box colCen">
						<view class="num">
							{{pageData.toDayMember}}
						</view>
						<view class="txt">
							今日新增
						</view>
					</view>
					<view class="bdr"></view>
					<view class="itm-box colCen">
						<view class="num">
							{{pageData.yesterdayMember}}
						</view>
						<view class="txt">
							昨日新增
						</view>
					</view>
					<view class="bdr"></view>
					<view class="itm-box colCen">
						<view class="num">
							{{pageData.youxiao}}
						</view>
						<view class="txt">
							有效用户
						</view>
					</view>
					<view class="bdr"></view>
					<view class="itm-box colCen">
						<view class="num">
							{{pageData.shouquan}}
						</view>
						<view class="txt">
							已授权
						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="screenbar-container rowCen borderBox">
			<view class="screen-bar-bac rowCenBet">
				<block v-for="(items,index) in screenList" :key="index">
					<view class="screen-items colCenBet" @tap="scrFans(index)">
						<view class="bdr"></view>
						<view>{{items.txt}}</view>
						<view class="bdr" :style="'background-color:'+(screenCurrent==index?'#FF2851':'')"></view>
					</view>
				</block>
			</view>
		</view>

		<view class="fansList-container colCen borderBox" v-if="fansList.length>0">
			<block v-for="(items,index) in fansList" :key="index">
				<view class="fans-items rowCenBet" @tap="goFansDetails(items)">
					<view class="itm-left rowCen">
						<view class="avator-box defIcon">
							<image :src="items.avatar" mode="aspectFill"></image>
						</view>
						<view class="name-level-time">
							<view class="name-level rowCen">
								<view class="namebox">
									{{items.nickName}}
								</view>
								<view class="levelbox rowCenCen" v-if="items.levelName">
									<view>{{items.levelName}}</view>
								</view>
							</view>
							<view class="timebox">
								{{items.createTime}}
							</view>
						</view>
					</view>

					<view class="itm-right colEnd">
						<view class="inviteInfo rowCen">
							<view class="invite">
								邀请{{items.inCount}}人
							</view>
							<view class="arrow iconfont">
								&#xe8d4;
							</view>
						</view>
						<view class="phone-effect rowCen">
							<view class="phone" v-text="items.account"></view>
							<view class="effect">
								{{items.isNew==0?'无':'有'}}效
							</view>
						</view>
					</view>
				</view>
			</block>
			<aLoadMore :status="loadstate" mode="loading3" :showTitle='true' :invite='true' color="#999999"></aLoadMore>
		</view>

		<view class="noFans-invites" v-else>
			<view class="color-content colCen">
				<view class="tips">
					这里是空空的~好友下单你得奖励，快去邀请好友吧~
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				pageData:'',
				screenCurrent: 0,
				screenList: [{
						txt: "全部",
						type: 0
					},
					{
						txt: "直属",
						type: 1
					},
					{
						txt: "间接",
						type: 2
					}
				],
				fansList: [],
				loadstate: 'nomore',
				pageCurrent: 0,
				canload: false
			}
		},
		onLoad() {
			this.getUserFans()
			this.getList()
		},
		
		onReachBottom() {
			if(this.canload){
				this.getList()
			}
		},
		
		methods: {
			getList(){
				this.$http.post('member/getFansList', {
					limit:10,
					offset:this.pageCurrent,
					type:this.screenCurrent,
				},'application/json').then((res) => {
					console.log(res);
					uni.stopPullDownRefresh()
					if(res.length<10){
						this.loadstate = 'nomore'
						this.canload = false
					}else{
						this.loadstate = 'loading'
						this.canload = true
						this.pageCurrent+=10
					}
					this.fansList = this.fansList.concat(res)
				})
			},
			getUserFans(){
				this.$http.get('member/getFansCount',{},'application/json').then(res=>{
					console.log(res);
					this.pageData = res
				})
			},
			scrFans(idx) {
				this.screenCurrent = idx
				this.fansList = []
				this.canload = false
				this.pageCurrent = 0
				this.loadstate = 'loading'
				this.getList()
			},
			goFansDetails(info) {
				uni.navigateTo({
					url: './fansDetails?info='+encodeURIComponent(JSON.stringify(info))
				})
			}
		},
		onPullDownRefresh() {
			this.fansList = []
			this.canload = false
			this.pageCurrent = 0
			this.loadstate = 'loading'
			this.getList()
		}
	}
</script>

<style lang="scss">
	.fans-wrapper {
		width: 100%;

		.top-info-card {
			width: 100%;
			padding: 0 30rpx;

			.top-color-container {
				width: 100%;
				height: 250rpx;
				background: linear-gradient(0deg, #FBBC54, #FF9C1A);
				border-radius: 16rpx;
				margin: 20rpx 0;
				padding: 0 32rpx;

				.fans-content {
					color: #FFFFFF;
					margin-top: 10rpx;

					.fans-num {
						font-size: 48rpx;
						font-weight: bold;
						color: #FFFFFF;
					}

					.fans-txt {
						font-size: 28rpx;
						color: #FFFFFF;
					}
				}

				.data-content {
					width: 100%;
					margin-top: 20rpx;

					.itm-box {
						color: #FFFFFF;

						.num {
							font-size: 32rpx;
							font-weight: bold;
						}

						.txt {
							font-size: 24rpx;
							margin-top: 5rpx;
						}
					}

					.bdr {
						width: 2rpx;
						height: 28rpx;
						background: #FFFFFF;
					}
				}
			}
		}

		.screenbar-container {
			width: 100%;
			margin-bottom: 20rpx;
			padding: 0 30rpx;

			.screen-bar-bac {
				width: 100%;
				height: 86rpx;
				background: #FFFFFF;
				border-radius: 16rpx;
				padding: 0 100rpx;

				.screen-items {
					height: 100%;

					.bdr {
						width: 42rpx;
						height: 4rpx;
						border-radius: 2rpx;
						border-radius: 2rpx;
					}
				}
			}
		}

		.fansList-container {
			width: 100%;
			padding: 0 30rpx;

			.fans-items {
				width: 100%;
				height: 125rpx;
				background: #FFFFFF;
				border-radius: 16rpx;
				margin-bottom: 20rpx;
				padding: 0 30rpx;

				.itm-left {
					height: 100%;

					.avator-box {
						width: 80rpx;
						height: 80rpx;
						border-radius: 50%;
						overflow: hidden;
					}

					.name-level-time {
						margin-left: 20rpx;

						.name-level {
							.namebox {
								font-size: 26rpx;
								font-weight: bold;
								margin-right: 30rpx;
								color: #333333;
							}

							.levelbox {
								height: 34rpx;
								background: linear-gradient(0deg, #F7C394, #EFE0D6);
								border-radius: 17rpx;
								font-size: 22rpx;
								font-weight: 500;
								color: #613309;
								padding: 0 15rpx;
							}
						}

						.timebox {
							font-size: 20rpx;
							font-weight: 500;
							color: #999999;
							margin-top: 15rpx;
						}
					}
				}

				.itm-right {
					.inviteInfo {
						.invite {
							font-size: 24rpx;
							font-weight: 500;
							color: #333333;
							margin-right: 15rpx;
						}

						.arrow {
							font-size: 20rpx;
							font-weight: 500;
							color: #333333;
							margin-top: 3rpx;
						}
					}

					.phone-effect {
						margin-top: 10rpx;

						.phone {
							font-size: 24rpx;
							font-weight: 500;
							color: #333333;
							margin-right: 20rpx;
						}

						.effect {
							font-size: 24rpx;
							font-weight: 500;
							color: #FF2851;
						}
					}
				}
			}
		}

		.noFans-invites {
			width: 100%;
			padding: 0 30rpx;

			.color-content {
				width: 100%;
				background: #FFFFFF;
				border-radius: 16rpx;
				padding: 0 148rpx;
				.tips{
					width: 100%;
					text-align: center;
					margin-top: 115rpx;
					margin-bottom: 60rpx;
					font-size: 24rpx;
					font-weight: 500;
					color: #333333;
				}
				.invite-btn{
					width: 286rpx;
					height: 74rpx;
					background: #FFA520;
					border-radius: 37rpx;
					font-size: 30rpx;
					font-weight: 500;
					color: #FFFFFF;
					margin-bottom: 115rpx;
				}
			}
		}
	}
</style>
