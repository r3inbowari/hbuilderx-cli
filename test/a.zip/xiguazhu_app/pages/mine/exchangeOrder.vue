<template>
	<view class="exchangeOrder-wrapper wrapperLayer">
		<titleBar :titleText="'我的订单'" :pageForm='"exchangeOrder"'></titleBar>
		<view class="fixed-navbar-container rowCenBet borderBox">
			<block v-for="(items,index) in navList" :key="index">
				<view class="nav-items" :class="navCurrent==index?'nav-active':''" @tap="excNav(index)">
					{{items.name}}
				</view>
			</block>
		</view>

		<view class="exchangeList-container borderBox">
			<block v-for="(items,index) in goodsList" :key="index">
				<view class="order-items colCen">
					<view class="expressinfo-content rowCenBet">
						<view class="leftexpressNum-box rowCen">
							<view class="num">
								快递号：{{items.expressNo}}
							</view>
							<view class="clipbtn rowCenCen" @tap="clipCode(items.expressNo)">
								<view>复制</view>
							</view>
						</view>
						<view class="exchange-num rowCenCen">
							<view>{{items.needDiamonds}}钻石</view>
						</view>
					</view>

					<view class="goodsInfo-container rowSta">
						<image class="goods-pic" :src="items.mainPic" mode="aspectFill"></image>
						<view class="right-info colStaBet">
							<view class="goods-name">
								{{items.title}}
							</view>
							<view class="btm-info">
								<view class="time">
									兑换时间：{{items.createTime}}
								</view>
								<view class="ordernum">
									订单号：{{items.orderSn}}
								</view>
							</view>
						</view>
					</view>

					<view class="state-box rowCenEnd borderBox">
						<view class="txt">
							{{items.status==1?'审核中':items.status==2?'已发货':items.status==3?'已完成':'已拒绝'}}
						</view>
					</view>
				</view>
			</block>
			<aLoadMore :status="loadstate" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				navCurrent: 0,
				navList: [{
						name: '全部'
					},
					{
						name: '审核中'
					},
					{
						name: '待收货'
					},
					{
						name: '已完成'
					},
					{
						name: '已拒绝'
					}
				],

				goodsList: [],
				loadstate: 'loading',
				pageCurrent: 0,
				canload: false
			}
		},
		onLoad() {
			this.getList()
		},
		onReachBottom() {
			if (this.canload) {
				this.getList()
			}
		},
		methods: {
			excNav(idx) {
				this.navCurrent = idx
				this.canload = false
				this.pageCurrent = 0
				this.loadstate = 'loading'
				this.goodsList = []
				this.getList()
			},
			clipCode(data) {
				uni.setClipboardData({
					data: data,
					success: () => {
						uni.showToast({
							title: '复制成功',
							duration: 2000,
							icon: "none"
						})
						
						uni.setStorageSync('clipboard', data);
					}
				})
			},
			getList() {
				this.$http.post('diamond/getOrderList', {
					limit: 10,
					status: this.navCurrent,
					offset: this.pageCurrent
				}, 'application/json').then(res => {
					uni.stopPullDownRefresh()
					if (res.length < 10) {
						this.canload = false
						this.loadstate = 'nomore'
					} else {
						this.canload = true
						this.loadstate = 'loading'
						this.pageCurrent += 10
					}
					this.goodsList = this.goodsList.concat(res)
				})
			},
		},
		onPullDownRefresh() {
			this.canload = false
			this.pageCurrent = 0
			this.loadstate = 'loading'
			this.goodsList = []
			this.getList()
		}
	}
</script>

<style lang="scss">
	.exchangeOrder-wrapper {
		width: 100%;

		.fixed-navbar-container {
			width: 100%;
			height: 86rpx;
			background-color: #FFFFFF;
			position: fixed;
			padding: 0 90rpx;
			z-index: 10;

			.nav-items {
				font-size: 28rpx;
				font-weight: 300;
				color: #333333;
			}

			.nav-active {
				font-size: 28rpx;
				font-weight: bold;
			}
		}

		.exchangeList-container {
			width: 100%;
			padding: 0 30rpx;
			margin-top: 106rpx;

			.order-items {
				width: 100%;
				height: 306rpx;
				background: #FFFFFF;
				border-radius: 8rpx;
				margin-bottom: 20rpx;

				.expressinfo-content {
					width: 100%;
					height: 80rpx;
					padding: 0 20rpx;

					.leftexpressNum-box {
						.num {
							font-size: 24rpx;
							font-weight: 500;
							color: #333333;
						}

						.clipbtn {
							width: 69rpx;
							height: 34rpx;
							background: #F3F3F3;
							border-radius: 17rpx;
							font-size: 24rpx;
							font-weight: 500;
							color: #666666;
							margin-left: 25rpx;
						}
					}

					.exchange-num {
						width: 121rpx;
						height: 34rpx;
						background: linear-gradient(-90deg, #FEA32A, #FFC437);
						border-radius: 5rpx;
						font-size: 22rpx;
						font-weight: 500;
						color: #FFFFFF;
					}
				}

				.goodsInfo-container {
					width: 100%;
					padding: 0 20rpx;

					.goods-pic {
						width: 120rpx;
						height: 120rpx;
						border-radius: 6rpx;
					}

					.right-info {
						height: 160rpx;
						margin-left: 20rpx;

						.goods-name {
							width: 415rpx;
							font-size: 28rpx;
							line-height: 38rpx;
							font-weight: 500;
							color: #333333;
							text-overflow: -o-ellipsis-lastline;
							overflow: hidden;
							text-overflow: ellipsis;
							display: -webkit-box;
							-webkit-line-clamp: 2;
							line-clamp: 2;
							-webkit-box-orient: vertical;
						}

						.btm-info {
							margin-bottom: 20rpx;
							font-size: 20rpx;
							font-weight: 500;
							color: #666666;
							line-height: 30rpx;
							opacity: 0.66;
						}
					}
				}

				.state-box {
					width: 100%;
					height: 66rpx;
					border-top: 1rpx solid #f4f4f4;
					padding: 0 20rpx;

					.txt {
						font-size: 26rpx;
						font-weight: 500;
						color: #333333;
					}
				}
			}
		}
	}
</style>
