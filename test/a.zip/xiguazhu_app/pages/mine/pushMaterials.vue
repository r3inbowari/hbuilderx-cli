<template>
	<view class="container" >
		<titleBar :titleText='"地推物料"' :pageForm='"setting"'></titleBar>
		<view class="pushHeader colCen">
			<image class="pushImg" src="/static/images/push/pushNg.png"></image>
			<view class="rowCenCen hdCon">
				<image :src="appInfo.logo" class="huaImg"></image>
			</view>
			<image src="/static/images/push/heji.png" class="hdTitle"></image>
			<view class="hdDesc">超全地推物料 助力拉新涨粉</view>
			<view class="hdBtnWrap rowCenCen" @tap="gostrategy()">
				<text>查看地推必备攻略</text>
				<image src="/static/images/push/rightRed.png"></image>
			</view>
		</view>
		<view class="pushSection colCen">
			<view class="scTitleWrap colCen">
				<view class="rowCenCen">
					<image src="/static/images/push/star.png" class="star"></image>
					<view class="scTitle">地推物料介绍</view>
					<image src="/static/images/push/star.png" class="star"></image>
				</view>
				<view class="tips">提示：二维码区域为示意，您可以按需求自行修改或删减</view>
			</view>
			<view class="item">
				<image src="/static/images/push/itemBg.png" class="itemBg"></image>
				<view class="itemTitleWrap colCen">
					<view class="itemTitle1">X展架</view>
					<view class="itemTitle2">60cm*160cm</view>
				</view>
				<view class="itemCon rowCen">
					<view class="itemLeft">
						<image src="/static/images/push/itemImg.png" class="itemImg"></image>
					</view>
					<view class="itemRight">地推装备必备之X展架，便携式展架之一，携带轻便，安装容易，使用的时候，1分钟就搞定。适合在固定场地使用，如商店门口，公园等地都可使用!</view>
				</view>
			</view>
			<view class="item">
				<image src="/static/images/push/itemBg.png" class="itemBg"></image>
				<view class="itemTitleWrap colCen">
					<view class="itemTitle1">传单</view>
					<view class="itemTitle2">148mm*208mm</view>
				</view>
				<view class="itemCon rowCen">
					<view class="itemLeft">
						<image src="/static/images/push/itemImg.png" class="itemImg"></image>
					</view>
					<view class="itemRight">地推广告传单的成本最低，经多人传阅，产生连动效果，作为引导更直观。主要用于流动性的场所，而且它便于携带，可以长期保存。</view>
				</view>
			</view>
			<view class="item">
				<image src="/static/images/push/itemBg.png" class="itemBg"></image>
				<view class="itemTitleWrap colCen">
					<view class="itemTitle1">桌牌</view>
					<view class="itemTitle2">210mm*297mm</view>
				</view>
				<view class="itemCon rowCen">
					<view class="itemLeft">
						<image src="/static/images/push/itemImg.png" class="itemImg"></image>
					</view>
					<view class="itemRight">地推桌牌属于高性价比地推物料之一，可反复使用的特点，在固定和流动场所都比较方便使用，而且用户能一目了然了解重要信息的传达! </view>
				</view>
			</view>
			<view class="more">更多物料持续添加中，敬请期待</view>
		</view>
		<view class="pushFooter rowCenCen" @tap='copyhref()'>复制百度网盘链接</view>
	</view>
</template>

<script>
	import util from '../../utils/utils.js'
	export default {
		data() {
			return {
				appInfo:''
			}
		},
		onLoad() {
			this.appInfo = util.getCacheSync('appInfo')
		},
		methods: {
			copyhref(){
				this.$http.post('cpssystemConfig/getCategoryList',{
					type:45
				},'application/json').then(res=>{
					console.log(res);
					uni.setClipboardData({
						data:res.cvalue,
					    success:res => {
					        uni.showToast({
					        	icon:'none',
								title:'复制成功~'
					        })
							
							uni.setStorageSync('clipboard', res.cvalue);
					    }
					});
				})
			},
			gostrategy(){
				uni.navigateTo({
					url:'./pushStrategy'
				})
			}
		}
	}
</script>

<style lang="scss">
	.container{
		.pushHeader{position: relative;background-color: #F44807;height: 540rpx;
			.pushImg{width: 100vw;height: 178rpx;}
			.hdCon{position: absolute;top: 60rpx;width: 100vw;
				.huaImg{width: 84rpx;height: 84rpx;}
				.huaText{width: 159rpx;height: 57rpx;margin-left: 12rpx;}
			}
			.hdTitle{width: 673rpx;height: 141rpx;}
			.hdDesc{font-size: 32rpx;font-weight: 500;font-style: italic;color: #FFFFFF;margin: 33rpx 0 40rpx;}
			.hdBtnWrap{width: 354rpx;height: 70rpx;background: linear-gradient(90deg, #FEED1A, #FEED1A);box-shadow: 0rpx 4rpx 0rpx 0rpx rgba(232, 60, 35, 0.63);border-radius: 10rpx;
				text{font-size: 26rpx;font-weight: 500;color: #FE0700;}
				image{width: 11rpx;height: 22rpx;margin-left: 18rpx;}
			}
		}
		.pushSection{background: linear-gradient(0deg, #F98414, #F85B1F);padding: 33rpx;
			.scTitleWrap{
				.star{width: 47rpx;height: 45rpx;}
				.scTitle{margin: 0 26rpx;font-size: 40rpx;font-weight: bold;color: #FFFFFF;line-height: 46rpx;}
				.tips{font-size: 20rpx;font-weight: 500;color: #FFFFFF;line-height: 35rpx;margin-top: 26rpx;}
			}
			.item{margin-top: 30rpx;position: relative;
				.itemBg{width: 683rpx;height: 558rpx;}
				.itemTitleWrap{color: #FFFFFF;position: absolute;top: 8rpx;width: 100%;
					.itemTitle1{font-size: 36rpx;font-weight: bold;}
					.itemTitle2{font-size: 28rpx;}
				}
				.itemCon{position: absolute;top: 146rpx;left: 47rpx;right: 65rpx;
					.itemLeft{width: 314rpx;height: 348rpx;
						.itemImg{width: 314rpx;height: 348rpx;}
					}
					.itemRight{font-size: 24rpx;font-weight: 500;color: #333333;line-height: 34rpx;margin-left: 18rpx;}
				}
			}
			.more{font-size: 24rpx;font-weight: 500;color: #FFFFFF;line-height: 55rpx;margin-top: 21rpx;}
		}
		.pushFooter{width: 750rpx;height: 92rpx;background: #FE0700;font-size: 30rpx;font-weight: 500;color: #FFFFFF;line-height: 34rpx;}
	}
</style>
