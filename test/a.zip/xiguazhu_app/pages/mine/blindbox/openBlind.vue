<template>
	<view class="openBlind-wrapper wrapperLayer">
		<view class="pagetopbar colCen" :style="'background:'+ (blacktop?'#ffffff;':'')">
			<view class="topbarbox"></view>
			<view class="bar-content rowCen">
				<view class="backbox" @tap="back()">
					<image class="backpic" v-if="!blacktop" src="../../../static/images/home/returnWhite.png" mode=""></image>
					<image class="backpic" v-else src="../../../static/images/home/return.png" mode=""></image>
				</view>
			</view>
		</view>
		<view class="topbarbox"></view>
		<view class="slider-container rowCen">
			<view class="sliderjjjj rowCen" :style="{'--lt':Number(slideWidth) + 10}">
				<block v-for="(items,index) in bulletList" :key="index">
					<view class="slider-items rowCen">
						<image class="header-box" :src="items.icon" mode="aspectFill"></image>
						<view class="txt">
							{{items.hint}}
						</view>
					</view>
				</block>
			</view>
		</view>
		<view class="shopwindow-container colCen borderBox">
			<view class="shopw-content colCen">
				<view class="blind-class rowCenCen">
					<view>{{info.title}}</view>
				</view>
				<view class="people-num">
					已有{{info.number}}人参与活动
				</view>
				<image class="openbac" src="../../../static/images/mine/shopwindow.png" mode="scaleToFill"></image>

				<view class="gift-list rowCen">
					<block v-for="(items,index) in 9" :key="index">
						<view class="gift-content" @tap="openBox(index)">
							<image class="giftpic" :class="index==tada?'tada':''"
								src="../../../static/images/mine/gift.png" mode="aspectFill"></image>
						</view>
					</block>
				</view>
			</view>
		</view>


		<view class="times-tips">
			您还有<span>{{userInfo.score}}</span>积分
		</view>

		<view class="bottom-bar rowCenBet borderBox ">
			<view class="mybox rowCenCen" @tap="giftWatch()">
				<view>奖品预览</view>
			</view>
			<view class="openBtn colCenCen" @tap="openBox()">
				<view class="open-txt">
					随机开盒
				</view>
				<view class="small-txt">
					{{info.goldCoin}}积分/次
				</view>
			</view>
			<view class="invite-friend rowCenCen" @tap="mygift()">
				<view>我的奖品</view>
			</view>
		</view>

		<u-popup v-model="giftShow" mode="center" border-radius="32" :mask-close-able='true'>
			<view class="model-container colCen">
				<image class="bacpic" src="../../../static/images/mine/getGift.png" mode="aspectFill"></image>
				<image class="goodspic" :src="giftGoods.img" mode="aspectFill"></image>
				<view class="bt-bar rowCenCen">
					<view class="get-btn rowCenCen" @tap="receive()">
						<view>领取</view>
					</view>
				</view>
			</view>
		</u-popup>

		<u-modal v-model="showModel" show-cancel-button :content="content" @confirm="confirm" :async-close="true">
		</u-modal>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				slideWidth: '',
				tada: null,
				info: '',
				userInfo: '',
				proshake: true,
				giftShow: false,
				giftGoods: '',
				showModel: false,
				content: "确定要消耗积分抽奖吗？",
				bulletList: [],
				interval:null,
				blacktop:false
			}
		},
		onLoad(options) {
			this.info = JSON.parse(options.info)
			console.log(this.info);
			this.getbulletChat()
			this.getrandom()
		},
		onShow() {
			this.getUserInfo()
		},
		onPageScroll(e) {
			if(e.scrollTop>15){
				this.blacktop = true
			}else{
				this.blacktop = false
			}
		},
		mounted() {
			this.getSlideWidth()
		},
		methods: {
			back(){
				uni.navigateBack({
					delta:1
				})
			},
			receive(){
				this.giftShow = false
				uni.navigateTo({
					url:'./boxOrder'
				})
			},
			getSlideWidth() {
				uni.createSelectorQuery().in(this).select('.slider-container').boundingClientRect(data => {
					console.log(data);
					this.slideWidth = data.width
				}).exec();

				setTimeout(() => {
					uni.createSelectorQuery().in(this).select('.sliderjjjj').boundingClientRect(data => {
						console.log(data);
						this.slideWidth = this.slideWidth - data.width
						console.log(this.slideWidth);
					}).exec();
				}, 1000)
			},
			getbulletChat() {
				this.$http.post('blindBox/publicScreen').then(res => {
					console.log(res);
					this.bulletList = res
				})
			},
			getrandom() {
				this.interval = setInterval(() => {
					var num = Math.floor(Math.random() * 10)
					if (this.tada == num) {
						this.tada = num++
					} else {
						this.tada = num
					}
				}, 1000)
			},

			giftWatch() {
				uni.navigateTo({
					url: '../blindList?id=' + this.info.id
				})
			},

			getUserInfo() {
				this.$http.get('member/getInfo', {}, true).then((res) => {
					console.log(res, '========>获取用户信息');
					this.userInfo = res
					uni.setStorageSync('userData', res)
				})
			},

			openBox(index) {
				console.log(index);
				if(index || index==0){
					clearInterval(this.interval)
					this.tada = index
					setTimeout(()=>{
						this.showModel = true
						this.getrandom()
					},1000)
				}else{
					this.showModel = true
				}
			},
			
			mygift(){
				uni.navigateTo({
					url:'./boxOrder'
				})
			},

			confirm() {
				uni.showLoading()
				setTimeout(() => {
					if (this.proshake) {
						this.proshake = false
						this.$http.post('blindBox/openBlindBox', {
							blindBoxId: this.info.id
						}).then(res => {
							this.proshake = true
							console.log(res);
							if (res.id) {
								this.giftGoods = res
								this.showModel = false
								this.giftShow = true
							}
						}).catch(res => {
							uni.hideLoading()
							this.showModel = false
							this.proshake = true
						})
					}
				}, 1000)
			}
		}
	}
</script>

<style lang="scss">
	.openBlind-wrapper {
		width: 100%;
		min-height: 100vh;
		background: url(../../../static/images/mine/openbac.png)no-repeat;
		background-size: 100% 100%;
		
		.pagetopbar{
			width: 100%;
			position: fixed;
			top: 0;
			left: 0;
			z-index: 100;
			.bar-content{
				width: 100%;
				height: 90rpx;
				padding: 0 32rpx;
				box-sizing: border-box;
				.backbox{
					width: 32rpx;
					height: 32rpx;
					.backpic{
						width: 17rpx;
						height: 32rpx;
					}
				}
			}
		}

		.slider-container {
			width: 100%;
			height: 120rpx;
			margin-top: 90rpx;
			position: relative;

			.sliderjjjj {
				position: absolute;
				animation: slideLeft calc((0 - var(--lt)) / 30 * 1s) linear infinite;

				@keyframes slideLeft {
					0% {
						left: 0rpx;
					}

					100% {
						left: calc((var(--lt))*1rpx);
					}
				}

				.slider-items {
					height: 60rpx;
					background: rgba(0, 7, 85, 0.4);
					border-radius: 30rpx;
					padding: 0rpx 50rpx 0rpx 10rpx;
					height: 100%;
					margin-right: 60rpx;

					.header-box {
						width: 45rpx;
						height: 45rpx;
						border-radius: 50%;
					}

					.txt {
						font-size: 26rpx;
						font-weight: 500;
						color: #FFFFFF;
						white-space: nowrap;
						margin-left: 10rpx;
					}
				}
			}
		}

		.shopwindow-container {
			width: 100%;
			margin-top: 55px;
			padding: 0 10px;

			.shopw-content {
				width: 350px;
				height: 429px;
				position: relative;

				.openbac {
					width: 100%;
					height: 100%;
				}

				.blind-class {
					width: 288px;
					height: 38px;
					background: linear-gradient(86deg, #926FEF, #CB5BEF);
					box-shadow: 0px 1px 5px 1px rgba(247, 247, 247, 0.24);
					border-radius: 8px;
					position: absolute;
					top: -30px;
					font-size: 16px;
					font-weight: 500;
					color: #FFFFFF;
					z-index: 10;
				}

				.people-num {
					position: absolute;
					top: 30px;
					z-index: 10;
					font-size: 14px;
					font-weight: 500;
					color: #FFFFFF;
				}

				.gift-list {
					width: 330px;
					flex-wrap: wrap;
					position: absolute;
					top: 83px;
					left: 10px;

					.gift-content {
						width: 110px;
						height: 86px;
						margin-bottom: 20px;

						.giftpic {
							width: 110px;
							height: 86px;
						}

						@keyframes tada {
							from {
								transform: scale3d(1, 1, 1);
							}

							10%,
							20% {
								transform: scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg);
							}

							30%,
							50%,
							70%,
							90% {
								transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg);
							}

							40%,
							60%,
							80% {
								transform: scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg);
							}

							to {
								transform: scale3d(1, 1, 1);
							}
						}

						.tada {
							animation: tada 1s 1 linear;
						}
					}
				}
			}
		}

		.times-tips {
			width: 100%;
			text-align: center;
			font-size: 26rpx;
			font-weight: 500;
			color: #FFFFFF;
			margin: 30rpx 0;

			span {
				font-weight: bold;
				color: #FECC04;
				font-size: 30rpx;
			}
		}

		.bottom-bar {
			width: 100%;
			padding: 0 26rpx;

			.mybox {
				width: 192rpx;
				height: 68rpx;
				background: linear-gradient(180deg, #FC25C8, #FC25C8, #FF54D9, #FC25C8);
				box-shadow: 1rpx 2rpx 5rpx 0px #FE4DD3;
				border-radius: 34rpx;
				font-size: 26rpx;
				font-weight: 500;
				color: #FFFFFF;
			}

			.openBtn {
				width: 234rpx;
				height: 106rpx;
				background: #FC25C8;
				box-shadow: 0px 5rpx 17rpx 1rpx rgba(255, 255, 255, 0.69);
				border-radius: 16rpx;
				font-weight: 500;
				color: #FFFFFF;

				.open-txt {
					font-size: 34rpx;
				}

				.small-txt {
					font-size: 24rpx;
					margin-top: 5rpx;
				}
			}

			.invite-friend {
				width: 192rpx;
				height: 68rpx;
				background: linear-gradient(180deg, #FC25C8, #FC25C8, #FF54D9, #FC25C8);
				box-shadow: 1rpx 2rpx 5rpx 0px #FE4DD3;
				border-radius: 34rpx;
				font-size: 26rpx;
				font-weight: 500;
				color: #FFFFFF;
			}
		}

		.model-container {
			width: 660rpx;
			height: 840rpx;
			position: relative;

			.bacpic {
				width: 100%;
				height: 800rpx;
			}

			.goodspic {
				width: 245rpx;
				height: 245rpx;
				border-radius: 12rpx;
				position: absolute;
				z-index: 10;
				top: 320rpx;
			}

			.bt-bar {
				width: 100%;
				position: absolute;
				bottom: 0;

				.get-btn {
					width: 334rpx;
					height: 87rpx;
					background: linear-gradient(43deg, #FF7604 0%, #FF4B04 100%);
					border-radius: 44rpx;
					font-size: 36rpx;
					font-weight: bold;
					color: #FFFFFF;
				}
			}
		}

		.u-mode-center-box {
			background: transparent !important;
		}
	}
</style>
