<template>
	<view class="boxOrder-wrapper wrapperLayer">
		<titleBar :titleText='"我的奖品"' :pageForm='"mygift"'></titleBar>
		<view class="page-fixed colCen">
			<view class="topbarbox"></view>
			<view class="orderStates-container pd20 rowCen">
				<view class="state-view rowCenBet">
					<block v-for="(items,index) in stateList">
						<view class="plat-items colCen" :class="stateCurrent==index?'plat-active':''" @tap="stateclk(index)">
							<view class="items-content rowCenCen">
								<view>{{items.label}}</view>
							</view>
							<view class="border" v-if="stateCurrent==index"></view>
						</view>
					</block>
				</view>
			</view>
		</view>
		
		<view class="pageContent-container colCen borderBox">
			<block v-for="(items,index) in giftList" :key="index">
				<view class="gift-items colCen borderBox">
					<view class="rowCenBet">
						<image class="goodspic" :src="items.img" mode="aspectFill"></image>
						<view class="rigth-info">
							<view class="goods-name">
								{{items.title}}
							</view>
							<view class="time">
								开箱时间：{{items.createTime}}
							</view>
							<view class="orderid">
								订单ID：{{items.id}}
							</view>
							<view class="price">
								￥{{items.originalPrice}}
							</view>
						</view>
						<view class="right-state rowSta">
							<view v-if="items.status==0">待领取</view>
							<view v-if="items.status==1">待发货</view>
							<view v-if="items.status==2">已发货</view>
							<view v-if="items.status==3">已回收</view>
						</view>
					</view>
					
					<view class="bottom-btnbar rowEnd borderBox" v-if="items.status==0">
						<view class="opt-btn rowCenCen" @tap="recovery(items)">
							<view>回收</view>
						</view>
						<view class="opt-btn rowCenCen" @tap="chooseAdr(items)">
							<view>{{items.virtualGoods==0?'领取':'添加收货地址'}}</view>
						</view>
					</view>
				</view>
			</block>
			<aLoadMore :status="loadstate" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
		</view>
		
		<u-modal v-model="showModel" show-cancel-button :content="content" @confirm="confirm" :async-close="true">
		</u-modal>
		
		<u-modal v-model="lingqu" show-cancel-button :content="content" @confirm="confirmLingqu" :async-close="true">
		</u-modal>
	</view>
</template>

<script>
	export default {
		data(){
			return{
				stateCurrent:0,
				stateList:[
					{
						label:'全部'
					},
					{
						label:'待领取'
					},
					{
						label:'待发货'
					},
					{
						label:'已发货'
					},
					{
						label:'已回收'
					}
				],
				
				showModel:false,
				content:'该商品可以回收',
				recoveryInfo:null,
				
				giftList:[],
				
				pageNumber:0,
				canload:false,
				loadstate:'loading',
				lingqu:false,
				content:'虚拟商品请添加客服微信领取~'
				
			}
		},
		onShow() {
			this.canload = false
			this.loadstate = 'loading'
			this.pageNumber=0
			this.giftList = []
			this.getList()
		},
		onReachBottom() {
			if(this.canload){
				this.getList()
			}
		},
		onPullDownRefresh() {
			this.canload = false
			this.loadstate = 'loading'
			this.pageNumber=0
			this.giftList = []
			this.getList()
		},
		methods:{
			stateclk(idx){
				this.stateCurrent = idx
				this.canload = false
				this.pageNumber = 0
				this.loadstate = 'loading'
				this.giftList = []
				this.getList()
			},
			
			getList(){
				this.$http.post('blindBox/myBoxGoodsList',{
					limit:10,
					offset:this.pageNumber,
					status:this.stateCurrent-1
				},'application/json').then(res=>{
					console.log(res);
					uni.stopPullDownRefresh()
					if(res.length<10){
						this.canload = false
						this.loadstate = 'nomore'
					}else{
						console.log(res);
						this.canload = true
						this.loadstate = 'loading'
						this.pageNumber+=10
					}
					this.giftList = this.giftList.concat(res)
				})
			},
			
			recovery(info){
				this.showModel = true
				this.recoveryInfo = info
				this.content = '回收可得'+this.recoveryInfo.recoveryPrice + '元，一经回收，无法找回!'
			},
			
			confirm(){
				this.$http.post('blindBox/recycling',{
					blindBoxRecordId:this.recoveryInfo.id
				}).then(res=>{
					console.log(res);
					uni.showToast({
						title:'回收成功！',
						icon:'none'
					})
					this.pageNumber = 0
					this.loadstate = 'loading'
					this.giftList = []
					this.canload = false
					this.showModel = false
					this.getList()
				})
			},
			cancel(){
				this.recoveryInfo = null
			},
			chooseAdr(info){
				if(info.virtualGoods==0){
					this.lingqu = true
				}else{
					uni.navigateTo({
						url:'../setting/myAddress?guess='+JSON.stringify(info)
					})
				}
			},
			
			confirmLingqu(){
				this.lingqu = false
				uni.navigateTo({
					url:'../tools/customerSevice'
				})
			}
		}
	}
</script>

<style lang="scss">
	.boxOrder-wrapper{
		width: 100%;
		.page-fixed {
			width: 100%;
			position: fixed;
			top: 90rpx;
			z-index: 5;
		
			.orderStates-container{
				width: 100%;
				height: 96rpx;
				background-color: #FFFFFF;
				.state-view{
					width: 100%;
					height: 86rpx;
					border-radius: 8rpx;
					border-top: 2rpx solid #F4F4F4;
					padding:0 38rpx;
					.plat-items{
						height:86rpx;
						.items-content{
							height: 100%;
							font-size: 28rpx;
							font-weight: 400;
							color: #333333;
						}
					}
					.plat-active{
						position: relative;
						
						.items-content{
							font-size: 30rpx;
							font-weight: bold;
							color: #333333;
						}
						.border{
							position: absolute;
							bottom: 16rpx;
							width: 34rpx;
							height: 4rpx;
							background: #FF3F60;
							border-radius: 2rpx;
						}
					}
				}
			}
		}
		
		.pageContent-container{
			width: 100%;
			margin-top: 110rpx;
			padding: 0 26rpx;
			.gift-items{
				width: 100%;
				background: #FFFFFF;
				border-radius: 16rpx;
				margin-bottom: 20rpx;
				padding: 20rpx;
				.goodspic{
					width: 164rpx;
					height: 164rpx;
					border-radius: 10rpx;
				}
				.rigth-info{
					flex: 1;
					width: 400rpx;
					height: 164rpx;
					margin-left: 20rpx;
					.goods-name{
						font-size: 28rpx;
						width: 100%;
						overflow: hidden;
						text-overflow: ellipsis;
						white-space: nowrap;
						font-weight: 500;
						color: #333333;
						margin-bottom: 15rpx;
					}
					.time{
						width: 100%;
						font-size: 22rpx;
						font-weight: 500;
						color: #666666;
					}
					.orderid{
						width: 100%;
						font-size: 22rpx;
						font-weight: 500;
						color: #666666;
						margin-bottom: 15rpx;
					}
					.price{
						width: 100%;
						font-size: 24rpx;
						font-weight: 500;
						color: #FF3F60;
					}
				}
				
				.right-state{
					height: 164rpx;
					font-size: 24rpx;
					font-weight: 500;
					color: #FF3F60;
				
				}
				
				.bottom-btnbar{
					width:100%;
					height: 80rpx;
					padding: 0 20rpx;
					justify-content: flex-end;
					.opt-btn{
						padding: 0 30rpx;
						height: 60rpx;
						background: #FFFFFF;
						border: 1rpx solid #DBD9D9;
						border-radius: 30rpx;
						font-size: 28rpx;
						font-weight: 500;
						color: #333333;
						margin-left: 30rpx;
					}
				}
			}
		}
	}
</style>
