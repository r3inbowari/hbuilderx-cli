<template>
	<view class="container">
		<titleBar :titleText='"地推攻略"' :pageForm='"setting"'></titleBar>
		
		<view class="pushWrap">
			<image class="pushImg" src="/static/images/push/pushStrategy.png"></image>
			<view class="colCen item">
				<view class="itemTitleWrap rowCenBet">
					<view class="itemDian"></view>
					<view class="itemTitle">地推优势</view>
					<view class="itemDian"></view>
				</view>
				<view class="itemcon">优先开展线下地推。直接触目标人群，快速精准的获取更多目标用户， 提前抢占市场，让收益更上一层楼！</view>
			</view>
			<view class="colCen item">
				<view class="itemTitleWrap rowCenBet">
					<view class="itemDian"></view>
					<view class="itemTitle">前期准备</view>
					<view class="itemDian"></view>
				</view>
				<view class="itemcon">
					<view class="itemconCate">1、确定目标人群</view>
					<view>宝妈，学生、上班族、想做兼职或创业的人群； </view>
					<view class="itemconCate">2、物料准备</view>
					<view>单人需准备: X展架、宣传单、工作证、小礼品、不干胶贴。团队(2人以上)需准备: X展架、宣传单、工作证、小礼品。折叠凳、不干胶贴。</view>
					<view class="itemconCate">3、地点和时间的选择</view>
					<view>
						周边小区、公园：18点、19点该时间蹲点最好;<br/>
						商业：街选择节假日，建议15点以后;<br/>
						地铁口：18点下班之后可踩点;<br/>
						校门口：选择大学的考虑16点-17点期间；<br/>
						幼儿园门口：尽量在15点以后皆可;<br/>
						快递站点：与快递代收点商户合作协商，相关时间也可跟商家协商来定。<br/>
					</view>
					<view class="itemconCate">4、礼品的选择</view>
					<view>小玩具，气球、学生用品、小风扇、纸巾、口罩、盆栽，多肉、小零食、发光的小气球等根据不同的场地及不同的用户群体去选择不同的礼品!</view>
					<view class="itemconCate">5、地推话术</view>
					<view>
						(1) “你可以先体验一下哦， 去应用商店搜一下[XXX]，它是对接淘宝以及拼多多等大平台的一款APP，可以领取大额优惠券，通过我们的app下单更优惠，你自己也返佣90%”<br/>
						(2) “可以直接通过我们的app，你自己买可以省钱，邀请好友下载APP，还可以赚钱哦~ 你也可以联系我们官方客服为你提供最新优惠信息的~”<br/>
						(3) “你可以体验一下XXX，而且我们还有很多特色活动是他们没有的，而且特别优惠，有啥需要的您告诉我，我们会第一时间回复您的，很方便的~”<br/>
					</view>
				</view>
			</view>
			<view class="colCen item">
				<view class="itemTitleWrap rowCenBet">
					<view class="itemDian"></view>
					<view class="itemTitle">细节安排</view>
					<view class="itemDian"></view>
				</view>
				<view class="itemcon">
					1、根据地点的人流情况，安排工作人员数量;<br/>
					2、首次地推建议2人以上，可以壮胆，互相帮助学习;<br/>
					3、团队地推细节安排:<br/>
					地推工作人员，必须装备正式，带上工牌，体现足够的专业意识;<br/>
					驻场人员做好相关引导和解说;<br/>
					安排小伙伴在地点周围发宣传单;<br/>
					遇到长时间无人关注的时候，可以安排另外的朋友作为托儿，围观关注，利用大家的从众心理，可促进气氛打造;<br/>
					完成当天的地推工作，做好清洁安排;<br/>
					4、时间选择周末，节假日，工作时间后;<br/>
					5、现场布置整洁有序;<br/>
					6、提前了解好场地是否允许开展，如果不允许，需要做适当调整；避免当日在选场地上浪费过多的时间;<br/>
				</view>
			</view>
			<view class="colCen item">
				<view class="itemTitleWrap rowCenBet">
					<view class="itemDian"></view>
					<view class="itemTitle">地推方案</view>
					<view class="itemDian"></view>
				</view>
				<view class="itemcon">
					方案1：现场扫码下载注册XXX，体验免单流程送小礼品;<br/>
					方案2：现场微信扫码加好友+下载XXX，免费送小礼品;<br/>
				</view>
			</view>
			<view class="colCen item">
				<view class="itemTitleWrap rowCenBet">
					<view class="itemDian"></view>
					<view class="itemTitle">地推后维护</view>
					<view class="itemDian"></view>
				</view>
				<view class="itemcon">
					(1) 每天对获取的新用户进行统计;<br/> 
					(2) 将当天拉到的所有用户，建立一个新的福利群。做相关活动;<br/> 
					(3) 第2天可针对用户做领取免单的活动;<br/>
					(4) 后期刺激他们去邀粉拉新。<br/>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
			}
		},
		onLoad() {
		},
		methods: {
			
		}
	}
</script>

<style lang="scss">
	.container{
		.pushWrap{background: linear-gradient(0deg, #F98514, #F34105);padding-bottom: 113rpx;
			.pushImg{width: 100vw;height: 178rpx;}
			.item{margin-top: 50rpx;
				.itemTitleWrap{width: 457rpx;height: 70rpx;background: #FFF15F;box-shadow: 0rpx 3rpx 2rpx 0rpx rgba(248, 156, 67, 0.69);border-radius: 10rpx;padding: 0 20rpx;position: relative;z-index: 9;
					.itemDian{width: 6rpx;height: 6rpx;background: #994D04;border-radius: 50%;}
					.itemTitle{font-size: 30rpx;font-weight: bold;color: #994D04;}
				}
				.itemcon{font-size: 24rpx;font-weight: 500;color: #F34606;line-height: 40rpx;width: 690rpx;background: #FFFFFF;border-radius: 10rpx;margin-top: -32rpx;padding: 76rpx 38rpx 46rpx;
					.itemconCate{font-size: 28rpx;font-weight: bold;}
				}
			}
		}
	}
</style>
