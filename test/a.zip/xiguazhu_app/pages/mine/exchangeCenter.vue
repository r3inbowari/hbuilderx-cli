<template>
	<view class="exchangeCenter-wrapper wrapperLayer">
		<titleBar :titleText="'兑换中心'" :pageForm='"exchangeCenter"'></titleBar>
		<view class="infoCard-container borderBox">
			<view class="color-card-container">
				<view class="header-info-content rowStaBet">
					<view class="header-box rowSta">
						<image class="headimg" :src="userinfo.avatar" mode="aspectFill"></image>
						<view class="username">
							{{userinfo.nickName}}
						</view>
					</view>
					<view class="order-tips rowCenCen">
						<view>下单赢钻石</view>
					</view>
				</view>

				<view class="account-balance rowStaBet">
					<view class="rowCen">
						<view class="itm-container colCen">
							<view class="itm-num">
								{{diamondBalance}}
							</view>
							<view class="txt">
								余额(钻石)
							</view>
						</view>
						<view class="itm-container colCen" style="margin-left: 155rpx;" @tap="goOrder()">
							<view class="itm-num">
								{{orderCount}}
							</view>
							<view class="txt">
								已兑换商品
							</view>
						</view>
					</view>

					<view class="records rowCen" @tap="godiamondsDts()">
						<view class="txttips iconfont">
							钻石记录 &#xe8d4;
						</view>
					</view>
				</view>
			</view>
		</view>

		<view class="goodslist-container borderBox">
			<view class="box-title rowCenCen">
				<view>商品列表</view>
			</view>

			<view class="goods-list-content rowCenBet">
				<block v-for="(items,index) in goodsList" :key="index">
					<view class="goods-items colCen borderBox" @tap="goDetails(items)">
						<image class="goods-pic" :src="items.mainPic" mode="aspectFill"></image>
						<view class="goods-info colCenBet">
							<view class="goods-name">
								{{items.title}}
							</view>
							<view class="bottom-info">
								<view class="success-yet rowCenBet">
									<view>已有{{items.exchangeQuantity}}人兑换成功</view>
									<view style="color: #999999;font-weight: 400;">库存{{items.stock}}</view>
								</view>
								<view class="exchange-info rowCenBet">
									<view class="exchange-num rowCenCen">
										<view>{{items.needDiamonds}}钻石</view>
									</view>
									<view class="exchange-btn rowCenCen">
										<view>兑换</view>
									</view>
								</view>
							</view>
						</view>
					</view>
				</block>

				<aLoadMore :status="loadstate" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
			</view>
		</view>
	</view>
</template>

<script>
	import util from '../../utils/utils.js'
	export default {
		data() {
			return {
				userinfo: '',
				diamondBalance: '',
				orderCount: '',
				goodsList: [],
				loadstate: 'loading',
				pageCurrent: 0,
				canload: false
			}
		},
		onLoad() {
			util.getCache('userData').then(res => {
				this.userinfo = res
			})
			this.getInfo()
			this.getList()
		},
		onReachBottom() {
			if (this.canload) {
				this.getList()
			}
		},
		methods: {
			getInfo() {
				this.$http.post('diamond/getDiamondBalance').then(res => {
					console.log(res);
					this.orderCount = res.orderCount
					this.diamondBalance = res.diamondBalance
				})
			},
			getList() {
				this.$http.post('diamond/getList',{
					limit:10,
					offset:this.pageCurrent
				},'application/json').then(res => {
					uni.stopPullDownRefresh()
					if(res.length<10){
						this.canload = false
						this.loadstate = 'nomore'
					}else{
						this.canload = true
						this.loadstate = 'loading'
						this.pageCurrent +=10
					}
					this.goodsList = this.goodsList.concat(res)
				})
			},
			godiamondsDts(){
				uni.navigateTo({
					url:"./diamondsDetails"
				})
			},
			goOrder(){
				uni.navigateTo({
					url:"./exchangeOrder"
				})
			},
			goDetails(info) {
				uni.navigateTo({
					url: './confirmExchange?info=' + encodeURIComponent(JSON.stringify(info))
				})
			}
		},
		onPullDownRefresh() {
			this.canload = false
			this.pageCurrent = 0
			this.loadstate = 'loading'
			this.goodsList = []
			this.getInfo()
			this.getList()
		}
	}
</script>

<style lang="scss">
	.exchangeCenter-wrapper {
		width: 100%;

		.infoCard-container {
			width: 100%;
			padding: 0 34rpx;
			margin-top: 20rpx;

			.color-card-container {
				width: 100%;
				height: 340rpx;
				background: url(../../static/images/mine/excbac.png) no-repeat;
				background-size: 100% 100%;

				.header-info-content {
					width: 100%;

					.header-box {
						margin-left: 47rpx;
						margin-top: 40rpx;

						.headimg {
							width: 116rpx;
							height: 116rpx;
							border-radius: 50%;
						}

						.username {
							font-size: 34rpx;
							font-weight: 500;
							margin-left: 25rpx;
							color: #FFFFFF;
						}
					}

					.order-tips {
						margin-top: 64rpx;
						width: 189rpx;
						height: 63rpx;
						background: linear-gradient(90deg, #FFF26E, #FFD025);
						border-radius: 32rpx 4rpx 4rpx 32rpx;
						font-size: 26rpx;
						font-weight: 500;
						color: #CA9300;
					}
				}

				.account-balance {
					margin-top: 40rpx;
					margin-left: 50rpx;

					.itm-container {
						font-size: 40rpx;
						font-weight: 500;
						color: #FFFFFF;

						.txt {
							font-size: 24rpx;
						}
					}

					.records {
						margin-top: 70rpx;
						margin-right: 30rpx;
						font-size: 24rpx;
						font-weight: 500;
						color: #FFFFFF;
					}
				}
			}
		}

		.goodslist-container {
			margin-top: 50rpx;
			padding: 0 20rpx;

			.box-title {
				font-size: 32rpx;
				font-weight: 500;
				color: #333333;
				margin-bottom: 30rpx;
			}

			.goods-list-content {
				width: 100%;
				flex-wrap: wrap;

				.goods-items {
					width: 345rpx;
					height: 535rpx;
					padding: 10rpx;
					background-color: #FFFFFF;
					margin-bottom: 20rpx;

					.goods-pic {
						width: 100%;
						height: 325rpx;
						border-radius: 6rpx;
					}

					.goods-info {
						width: 100%;
						height: 190rpx;
						padding: 0 10rpx;

						.goods-name {
							font-size: 28rpx;
							font-weight: 500;
							color: #333333;
							line-height: 34rpx;
							margin-top: 20rpx;
							overflow: hidden;
							text-overflow: ellipsis;
							display: -webkit-box;
							-webkit-line-clamp: 2;
							-webkit-box-orient: vertical;
						}

						.bottom-info {
							width: 100%;

							.success-yet {
								width: 100%;
								font-size: 22rpx;
								font-weight: 500;
								color: #FF4242;
								margin-bottom: 20rpx;
							}

							.exchange-info {
								.exchange-num {
									width: 121rpx;
									height: 34rpx;
									background: linear-gradient(-90deg, #FEA32A, #FFC437);
									border-radius: 5rpx;
									font-size: 22rpx;
									font-weight: 500;
									color: #FFFFFF;
								}

								.exchange-btn {
									width: 100rpx;
									height: 44rpx;
									background: linear-gradient(9deg, #FD002F, #FE3F62);
									border-radius: 22rpx;
									font-size: 24rpx;
									font-weight: 500;
									color: #FFFFFF;
								}
							}
						}
					}
				}
			}
		}
	}
</style>
