<template>
	<view class="shopsPage-wrapper wrapperLayer colCen">
		<view class="backTitlebar-wrapper colCen borderBox">
			<view class="fixedBox">
				<view class="topbarbox"></view>
				<view class="headerNavigationbar rowCenBet borderBox">
					<view class="backIcon rowCenSta" @click="backUrl()">
						<image src="../../static/images/home/returnWhite.png" mode=""></image>
					</view>
					<view class="pageTitle">
						商家店铺
					</view>
					<view class="emptybox rowCenEnd">
					</view>
				</view>
			</view>
			<view class="placeBox">
				<view class="topbarbox"></view>
				<view class="placeemptybox">
				</view>
			</view>
		</view>
		
		<view class="pageContent-container colCen">
			<view class="shops-info borderBox rowCen">
				<image class="shopLogo" :src="shopLogo" mode="aspectFill"></image>
				<view class="shopinfo-content">
					<view class="shopname">
						{{shopName}}
					</view>
					<image class="tianmaoLogo" v-if="true" src="../../static/images/goods/tmshop.png"></image>
				</view>
			</view>
			<view class="shops-score borderBox rowCenBet">
				<view class="score-item">
					宝贝描述:{{descScore}}
				</view>
				<view class="score-item">
					卖家服务:{{serviceScore}}
				</view>
				<view class="score-item">
					服务物流:{{shipScore}}
				</view>
			</view>
			
			<view class="goods-content rowStaBet">
				<block v-for="(items,index) in goodsList" :key='index'>
					<view class="goods-items" @click="goDetail(items)">
						<colGoods :items="items"></colGoods>
					</view>
				</block>
			</view>
			
			<aLoadMore :status="loadstatus" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
		</view>
	</view>
</template>

<script>
	import colGoods from '../../components/colGoods.vue'
	export default {
		components:{
			colGoods
		},
		data() {
			return {
				sellerId:'',
				shopLogo:'',
				shopName:'',
				shopType:'',
				goodsList:[],
				
				descScore:'',
				serviceScore:'',
				shipScore:'',
				
				loadmore:false,
				pageCurrent:1,
				loadstatus:'loading'
			}
		},
		onLoad(options) {
			console.log(options);
			this.sellerId = options.id;
			this.getPageList()
		},
		onReachBottom() {
			if(this.loadmore){
				this.getPageList()
			}
		},
		methods:{
			getPageList(){
				this.$http.post('tb/tbShopGoods',{
					page:this.pageCurrent,
					pageSize:10,
					sellerId:this.sellerId,
				},'application/json').then(res=>{
					if(this.pageCurrent==1){
						console.log(res)
						this.shopName = res[0].shopName
						this.shopLogo = res[0].shopLogo
						this.shopType = res[0].shopType
						this.descScore = res[0].descScore
						this.serviceScore = res[0].serviceScore
						this.shipScore = res[0].shipScore
					}
					
					uni.stopPullDownRefresh()
					
					if(res.length<10){
						this.loadmore = false
						this.loadstatus = 'nomore'
					}else{
						this.loadmore = true
						this.loadstatus = 'loading'
						this.pageCurrent++
					}
					
					this.goodsList= this.goodsList.concat(res)
				})
			},
			
			goDetail(info) {
				uni.navigateTo({
					url: '../goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(info))
				})
			},
			backUrl(){
				uni.navigateBack({
					delta:1
				})
			}
		},
		onPullDownRefresh() {
			this.loadmore = false
			this.pageCurrent = 1
			this.loadstatus = 'loading'
			this.goodsList = []
			this.getPageList()
		}
	}
</script>

<style lang="scss">
	.shopsPage-wrapper{
		.backTitlebar-wrapper {
			.placeBox {
				.placeemptybox {
					height: 90rpx;
				}
			}
		
			.fixedBox {
				width: 100%;
				position: fixed;
				top: 0;
				left: 0;
				z-index: 100;
				background: linear-gradient(-7deg, #DB2222, #ED3534);
		
				.headerNavigationbar {
					width: 100%;
					height: 90rpx;
					padding: 0 32rpx;
		
					.backIcon {
						width: 60rpx;
						height: 32rpx;
						z-index: 1;
		
						image {
							width: 17rpx;
							height: 32rpx;
						}
					}
		
					.pageTitle {
						font-size: 34rpx;
						font-weight: 500;
						color: #FFFFFF;
					}
		
					.emptybox {
						width: 60rpx;
						height: 32rpx;
					}
				}
			}
		}
		
		.pageContent-container{
			width: 100%;
			.shops-info{
				width: 100%;
				height: 180rpx;
				background: #FFFFFF;
				padding: 0 24rpx;
				.shopLogo{
					width: 120rpx;
					height: 120rpx;
					margin-right: 20rpx;
				}
				.shopinfo-content{
					.shopname{
						font-size: 28rpx;
						font-weight: 500;
						color: #333333;
					}
					.tianmaoLogo {
						width: 150rpx;
						height: 20rpx;
					}
				}
			}
			.shops-score{
				width: 100%;
				height: 92rpx;
				font-size: 24rpx;
				font-weight: 500;
				color: #666666;
				background-color: #FFFFFF;
				padding: 0 28rpx;
			}
		}
		.goods-content {
			width: 100%;
			padding: 0 20rpx;
			margin-top: 20rpx;
			flex-wrap: wrap;
		
			.goods-items {
				width: 346rpx;
				height: 526rpx;
				margin-bottom: 20rpx;
			}
		}
	}
</style>
