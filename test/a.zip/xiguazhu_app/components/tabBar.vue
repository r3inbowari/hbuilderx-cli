<template>
	<view class="page-tabbar-area">
		<view class="height-box"></view>
		<view class="tabbar-wrapper rowSta">
			<view class="tablist-conatiner rowCenAro">
				<block v-for="(items,index) in tabbarList" :key="index">
					<view class="tabItems-container colCen" @tap="gourl(items.url)">
						<view class="tabIcon-box defIcon">
							<image :src="current==items.url?items.afterIcon:items.beforeIcon" mode="aspectFill"></image>
						</view>
						<view class="tabbar-text" :style="'color:' + (current==items.url?defColor:'')">
							{{items.menuName}}
						</view>
					</view>
				</block>
			</view>
		</view>
	</view>
</template>

<script>
	export default{
		props:{
			current:{
				default:'../index/index'
			}
		},
		data(){
			return{
				defColor:'rgb(254, 58, 51)',
				tabbarList:[]
			}
		},
		created() {
			this.tabbarList = uni.getStorageSync('tabbar')
		},
		methods:{
			gourl(url){
				if(url!=this.current){
					if(url=='../mine/mine'){
						const value = uni.getStorageSync('userInfo');
						if(value){
							uni.reLaunch({
								url:url
							})
						}else{
							uni.navigateTo({
								url:'../login/login'
							})
						}
					}else{
						uni.reLaunch({
							url:url
						})
					}
				}
			}
		}
	}
</script>

<style lang="scss">
	/* #ifndef APP-NVUE */
	.tabbar-wrapper{
		position: fixed;
		bottom: 0;
		left: 0;
		width: 100%;
		height: 100rpx;
		height: calc(100rpx + constant(safe-area-inset-bottom));
		height: calc(100rpx + env(safe-area-inset-bottom));
		z-index: 2000;
		background-color: #FFFFFF;
		.tablist-conatiner{
			width: 100%;
			height: 100rpx;
			.tabItems-container{
				.tabIcon-box{
					width: 48rpx;
					height: 48rpx;
				}
				.tabbar-text{
					font-size: 24rpx;
					font-weight: 400;
					color: #333333;
				}
			}
		}
	}
	/* #endif */
	/* #ifdef APP-NVUE */
	
	/* #endif */
	
</style>
