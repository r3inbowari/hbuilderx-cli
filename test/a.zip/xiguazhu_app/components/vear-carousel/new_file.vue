<template>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">hello<span
			 style="font-family:宋体">，小伙伴们好啊</span></span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">你们的小编又开始种草啦</span>~</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">话说时间过得挺快的</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">眼睛一眨一闭学期都已经过半了</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">相信不少童鞋开学之前买的</span>▼</span><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal">
		<div style="text-align: center;"><span style="font-family: 宋体; font-size: 10.5pt;">圆珠笔、修改带、笔记本等文具都用得差不多了吧</span></div><br />
	</p>
	<section class="_135editor" data-role="paragraph">
		<p style="text-align: center;"><img src="https://135editor.cdn.bcebos.com/files/users/599/5999135/202011/sktcJgb2_bxOs.gif"
			 _src="https://135editor.cdn.bcebos.com/files/users/599/5999135/202011/sktcJgb2_bxOs.gif" draggable="false" alt="timg.gif"
			 data-ratio="0.5407407407407407" data-w="540" /></p>
	</section>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体"><br /></span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"></span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">来来来</span>~<span style="font-family:宋体">这里给大家选了一些易消耗的文具</span></span><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span><br /></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">这些文具单价不高，大量囤也花不了多少钱</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">趁囤货还没彻底用完之前提前买好，不会用时方恨无！</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">家有小朋友上学的家长</span>OR<span style="font-family:宋体">学生党快去看看吧</span></span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p><br /></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p><img src="http://img-haodanku-com.cdn.fudaiapp.com/Fpwp5aq3qeqjEp5uUMJKcRvTkoaS-600" _src="http://img-haodanku-com.cdn.fudaiapp.com/Fpwp5aq3qeqjEp5uUMJKcRvTkoaS-600" /></o:p>
		</span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p>&nbsp;</o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">笔是学生蕞少不了的文具了</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">尤其是圆珠笔、铅笔还是彩色笔这三种</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">基本上每天都会用到，消耗是非常快的</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">所以这里给童鞋们选了几款笔</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p><img src="http://img-haodanku-com.cdn.fudaiapp.com/FgAmy1GCv9gbCEyvEVSwQcxinoN5-600" _src="http://img-haodanku-com.cdn.fudaiapp.com/FgAmy1GCv9gbCEyvEVSwQcxinoN5-600" /></o:p>
		</span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p>&nbsp;</o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">首先是我们蕞常用的子弹头中性笔</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">它的笔头是</span>0.5mm<span style="font-family:宋体">规格的</span></span><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">有黑、蓝、墨蓝、红四色可以选</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal">
		<div style="text-align: center;"><span style="font-family: 宋体; font-size: 10.5pt;">不管是平时写作业还是标重点都用得上</span></div><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><br /></span>
	</p>
	<div style="text-align: center;"><img src="http://img-haodanku-com.cdn.fudaiapp.com/FoIunZCTmj3VujEhN32tjP217otZ-600"
		 _src="http://img-haodanku-com.cdn.fudaiapp.com/FoIunZCTmj3VujEhN32tjP217otZ-600" style="font-size: 10.5pt;" /></div>
	<p></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体"><br /></span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">里面的墨水是日本油墨</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">具有快干、不溢墨、颜色亮丽等优点</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">现在</span>3<span style="font-family:宋体">支仅需￥</span><span style="font-family:Calibri">1.9</span><span
			 style="font-family:宋体">，买多更划算</span></span><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">大家可以进去选一选</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体"><br /></span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体"></span></p>
	<div class="single-content-one">
		<div class="single-info-one js_tobuy" id="itemid621184915952"><img src="https://img.alicdn.com/imgextra/i1/292438365/O1CN01kg1GXw2BfDjGp9kp1_!!292438365.jpg"
			 alt="" class="getitemid" data-itemid="621184915952" data-tkrates="20" data-itemsale="5437" />
			<div class="single-details-one"><span class="phone-title single-title-one">【晨光】大容量全针管签字笔3支</span>
				<div class="single-coupon-one"><span class="coupon-style"><span>券</span><span class="coupon">1</span></span><span>已售
						<span class="itemsale">5437</span></span></div>
				<div class="single-message single-message-one"><span class="single-price"><span>券后</span><span class="price">1.9</span></span><span
					 class="single-tkmoney"><span>佣金</span><span class="tkmoney">0</span></span><span class="single-tkrates"><span>营销</span><span
						 class="tkrates">20</span></span></div>
			</div>
			<div class="commodity-remove">
				<div class="trash-btn"><em class="am-icon-trash"></em></div>
			</div>
		</div>
	</div>
	<p></p>
	<p><br /></p>
	<p class="MsoNormal" style="text-align: center;"><img src="http://img-haodanku-com.cdn.fudaiapp.com/FghOJpa3-OzmwzrhE9KnCPYRjL4i-600"
		 _src="http://img-haodanku-com.cdn.fudaiapp.com/FghOJpa3-OzmwzrhE9KnCPYRjL4i-600" /></p>
	<p class="MsoNormal"><br /></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">考试、写数学、画画都少不了的</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">2B<span
			 style="font-family:宋体">铅笔</span></span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">它是用原木</span>+<span style="font-family:宋体">石墨铅笔芯制作而成</span></span><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">不易折断，用来写字画画也很流畅</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">而且笔芯的涂写出来的黑度较高</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">不用担心涂答题卡不明显而要反复涂浪费做题时间</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p><br /></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p><img src="http://img-haodanku-com.cdn.fudaiapp.com/FvCWhPvvNgdgOzh29N_SrU5wD9MK-600" _src="http://img-haodanku-com.cdn.fudaiapp.com/FvCWhPvvNgdgOzh29N_SrU5wD9MK-600" /></o:p>
		</span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p>&nbsp;</o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">它有从小用到大的六角绿杆铅笔</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">以及三角</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">凹洞</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">铅笔可选</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">如果你家孩子在读幼儿园或者小学</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">建议买三角款的，它上面有凹槽洞口设计</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">可以很自然的端正孩子握笔姿势</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">现在</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">10<span
			 style="font-family:宋体">支</span></span><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">低至</span>5.46<span style="font-family:宋体">元，价格可以说非常白菜了</span></span></p>
	<p class="MsoNormal"><span style="font-size: 10.5pt;font-family:宋体"><br /></span></p>
	<p class="MsoNormal"><span style="font-size: 10.5pt;font-family:宋体"></span></p>


	<div class="single-content-one">
		<div class="single-info-one js_tobuy" id="itemid616816366922"><img src="https://img.alicdn.com/imgextra/i2/2719855959/O1CN01kRD1Y51ttGmd3og3I_!!2719855959.jpg"
			 alt="" class="getitemid" data-itemid="616816366922" data-tkrates="20" data-itemsale="35683" />
			<div class="single-details-one"><span class="phone-title single-title-one">【晨光】10支2B铅笔洞洞铅笔</span>
				<div class="single-coupon-one"><span class="coupon-style"><span>券</span><span class="coupon">1</span></span><span>已售
						<span class="itemsale">35683</span></span></div>
				<div class="single-message single-message-one"><span class="single-price"><span>券后</span><span class="price">5.4</span></span><span
					 class="single-tkmoney"><span>佣金</span><span class="tkmoney">1</span></span><span class="single-tkrates"><span>营销</span><span
						 class="tkrates">20</span></span></div>
			</div>
			<div class="commodity-remove">
				<div class="trash-btn"><em class="am-icon-trash"></em></div>
			</div>
		</div>
	</div>


	<p></p>
	<p><br /></p>
	<p class="MsoNormal" style="text-align: center;"><img src="http://img-haodanku-com.cdn.fudaiapp.com/Fl4_kYQxA9sTFFDTBIsePkiR4faQ-600"
		 _src="http://img-haodanku-com.cdn.fudaiapp.com/Fl4_kYQxA9sTFFDTBIsePkiR4faQ-600" /></p>
	<p class="MsoNormal"><br /></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">做标记、画重点总少不了几支</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">荧光笔</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">如果你的荧光笔快用完了</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">可以看看得力这款</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">彩色荧光笔</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">一套有</span>5~6<span style="font-family:宋体">支，每一支是不同颜色</span></span><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">可以分不同科目或者不同类型知识点使用</span>~</span><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p><br /></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p><img src="http://img-haodanku-com.cdn.fudaiapp.com/FoRQm7Oc6AqDt3XfBzc3WR3_U73C-600" _src="http://img-haodanku-com.cdn.fudaiapp.com/FoRQm7Oc6AqDt3XfBzc3WR3_U73C-600" /></o:p>
		</span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p>&nbsp;</o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">荧光笔是斧头形笔头，</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">书写</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">可粗可细</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">方便多角度画出不同笔触</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">笔身是长方形体积，施力面大拿握稳当</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">加持小夹子笔壳设计，用完可以夹在笔记本或书上</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">这样可以随时使用也不用担心遗失</span></p>
	<p class="MsoNormal"><span style="font-size: 10.5pt;font-family:宋体"><br /></span></p>
	<p class="MsoNormal"><span style="font-size: 10.5pt;font-family:宋体"></span></p>
	<div class="single-content-one">
		<div class="single-info-one js_tobuy" id="itemid22430791937"><img src="https://img.alicdn.com/imgextra/i2/752144829/O1CN01Siug4X1lXj9kNB8i9_!!752144829.jpg"
			 alt="" class="getitemid" data-itemid="22430791937" data-tkrates="20" data-itemsale="143" />
			<div class="single-details-one"><span class="phone-title single-title-one">【得力】6色荧光笔双头彩色记号笔</span>
				<div class="single-coupon-one"><span class="coupon-style"><span>券</span><span class="coupon">3</span></span><span>已售
						<span class="itemsale">143</span></span></div>
				<div class="single-message single-message-one"><span class="single-price"><span>券后</span><span class="price">7</span></span><span
					 class="single-tkmoney"><span>佣金</span><span class="tkmoney">1</span></span><span class="single-tkrates"><span>营销</span><span
						 class="tkrates">20</span></span></div>
			</div>
			<div class="commodity-remove">
				<div class="trash-btn"><em class="am-icon-trash"></em></div>
			</div>
		</div>
	</div>
	<p></p>
	<p><br /></p>
	<p class="MsoNormal" style="text-align: center;"><span style="font-family: Calibri; font-size: 10.5pt;"><img src="http://img-haodanku-com.cdn.fudaiapp.com/FpqsaKalUu7L9lrFwaC3HzFwBiuJ-600"
			 _src="http://img-haodanku-com.cdn.fudaiapp.com/FpqsaKalUu7L9lrFwaC3HzFwBiuJ-600" /></span></p>
	<p class="MsoNormal"><span style="font-family: Calibri; font-size: 10.5pt;">&nbsp;</span><br /></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">每一个科目都需要笔记本来记笔记</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">有些学科还要准备两三本</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">这样一个学期下来就要用几十个笔记本</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">！</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal">
		<div style="text-align: center;"><span style="font-family: 宋体; font-size: 10.5pt;">也是消耗非常快的</span></div><br />
	</p>
	<p class="MsoNormal" style="text-align: center;"><img src="http://img-haodanku-com.cdn.fudaiapp.com/FgJln4EjmbNlLDo0hHt_IGHyZs78-600"
		 _src="http://img-haodanku-com.cdn.fudaiapp.com/FgJln4EjmbNlLDo0hHt_IGHyZs78-600" /></p>
	<p class="MsoNormal"><br /></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">需要囤货的童鞋可以来这里选一选</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">晨光多风格多封面笔记本</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">米黄色纸张厚实不易破也不易渗墨</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">每行间隔</span>10mm<span style="font-family:宋体">，舒适易书写</span></span><span style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><br /></span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><img
			 src="http://img-haodanku-com.cdn.fudaiapp.com/FrOseYzy0lUJ7K6UUJBRNJpZ0G2V-600" _src="http://img-haodanku-com.cdn.fudaiapp.com/FrOseYzy0lUJ7K6UUJBRNJpZ0G2V-600" /></span></p>
	<p class="MsoNormal"><br /></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">笔记本有多种封面可以选</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">可爱</span>&amp;<span style="font-family:宋体">养眼兼具，满足颜控的需求</span></span><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">有</span>4<span style="font-family:宋体">本</span><span style="font-family:Calibri">/8</span><span
			 style="font-family:宋体">本</span><span style="font-family:Calibri">/12</span><span style="font-family:宋体">本套装可选，低至</span><span
			 style="font-family:Calibri">6.9</span><span style="font-family:宋体">元超便宜的</span></span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><br /></span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"></span></p>
	<div class="single-content-one">
		<div class="single-info-one js_tobuy" id="itemid624153097824"><img src="http://img.alicdn.com/imgextra/i4/288902762/O1CN01X3C4p31WH2YBPY7DN_!!288902762.jpg"
			 alt="" class="getitemid" data-itemid="624153097824" data-tkrates="20" data-itemsale="803" />
			<div class="single-details-one"><span class="phone-title single-title-one">晨光系列笔记本记事本日记本手账本4/8本</span>
				<div class="single-coupon-one"><span class="coupon-style"><span>券</span><span class="coupon">3</span></span><span>已售
						<span class="itemsale">803</span></span></div>
				<div class="single-message single-message-one"><span class="single-price"><span>券后</span><span class="price">6.9</span></span><span
					 class="single-tkmoney"><span>佣金</span><span class="tkmoney">1</span></span><span class="single-tkrates"><span>营销</span><span
						 class="tkrates">20</span></span></div>
			</div>
			<div class="commodity-remove">
				<div class="trash-btn"><em class="am-icon-trash"></em></div>
			</div>
		</div>
	</div>
	<p></p>
	<p><br /></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><img
			 src="http://img-haodanku-com.cdn.fudaiapp.com/FhCbEpijshgPfZBeaQUAc7370Wsb-600" _src="http://img-haodanku-com.cdn.fudaiapp.com/FhCbEpijshgPfZBeaQUAc7370Wsb-600" /></span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体"><br /></span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">得力这款</span>“生活小调”系列笔记本</span><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span><br /></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">封面有可爱的卡通插画与艺术文字装饰</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">整体颜值也是非常高的</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p><br /></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p><img src="http://img-haodanku-com.cdn.fudaiapp.com/FjwuW3DqthMvCPKaUuok6E5GInzY-600" _src="http://img-haodanku-com.cdn.fudaiapp.com/FjwuW3DqthMvCPKaUuok6E5GInzY-600" /></o:p>
		</span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p>&nbsp;</o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">纸张也是柔和的米黄色</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">中间缝线装订，牢固不易掉页易平摊</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">一本有</span>40<span style="font-family:宋体">页挺耐用的，现在一套有</span><span style="font-family:Calibri">4</span><span
			 style="font-family:宋体">本才</span><span style="font-family:Calibri">11.8</span><span style="font-family:宋体">元</span></span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">喜欢这种风格笔记本的童鞋，可以戳进去看看</span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><br /></span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"></span></p>
	<div class="single-content-one">
		<div class="single-info-one js_tobuy" id="itemid521458175975"><img src="https://img.alicdn.com/imgextra/i2/1658618229/O1CN01QwbRQw2AevhVkIzRM_!!0-item_pic.jpg"
			 alt="" class="getitemid" data-itemid="521458175975" data-tkrates="20" data-itemsale="207" />
			<div class="single-details-one"><span class="phone-title single-title-one">【得力】缝线本B5学生作业软面抄本子</span>
				<div class="single-coupon-one"><span class="coupon-style"><span>券</span><span class="coupon">3</span></span><span>已售
						<span class="itemsale">207</span></span></div>
				<div class="single-message single-message-one"><span class="single-price"><span>券后</span><span class="price">11.8</span></span><span
					 class="single-tkmoney"><span>佣金</span><span class="tkmoney">2</span></span><span class="single-tkrates"><span>营销</span><span
						 class="tkrates">20</span></span></div>
			</div>
			<div class="commodity-remove">
				<div class="trash-btn"><em class="am-icon-trash"></em></div>
			</div>
		</div>
	</div>
	<p></p>
	<p><br /></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><img
			 src="http://img-haodanku-com.cdn.fudaiapp.com/FrgD-sOTQIIIV8NLcAh9WhDPAmza-600" _src="http://img-haodanku-com.cdn.fudaiapp.com/FrgD-sOTQIIIV8NLcAh9WhDPAmza-600" /></span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体"><br /></span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">做作业难免会写错，要涂涂改改</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span><br /></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">所以一些修改错别字、错题的文具也是必不可少的</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">不过</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">相比于修正液，</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">现在的</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">学生们更喜欢用修正带</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">它</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">不用像修正液那样等到凝固了才能写</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">而且</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">错哪里划哪里用起来</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">超</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">方便</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">的</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">不过它有一个</span>bug<span style="font-family:宋体">就是消耗得超级快</span></span><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">学期过半相信不少人之前的囤货都快用完了吧</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">不妨快这里囤些货吧</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p><br /></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p><img src="http://img-haodanku-com.cdn.fudaiapp.com/FkfkP9GmSeHQuVHMsaqL6xT0Abhh-600" _src="http://img-haodanku-com.cdn.fudaiapp.com/FkfkP9GmSeHQuVHMsaqL6xT0Abhh-600" /></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p>&nbsp;</o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">这里有一款好看又好用的</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">晨光静音修正带</span>~</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">外层是透明防脏保护盖</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">透明可视容量使用情况一目了然</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">内部则是</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">消音结构设计</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">的，拉带顺畅不易卡带</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">就算教室很安静也不会有烦人的</span>“</span><span style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">咔嚓</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">”</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;font-family:宋体">声</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p><br /></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p><img src="http://img-haodanku-com.cdn.fudaiapp.com/FiEipfltc1J_gHhbB552SoUXVOrz-600" _src="http://img-haodanku-com.cdn.fudaiapp.com/FiEipfltc1J_gHhbB552SoUXVOrz-600" /></o:p>
		</span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p>&nbsp;</o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">修正带粘贴紧密，粘性好</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">在需要修改的地方轻轻一按一拉即可覆盖</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">修改起来非常方便还不会弄脏手</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">而修正带正面多种笔都可以书写</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;"><span
			 style="font-family:宋体">一卷有</span>20m<span style="font-family:宋体">一份共</span><span style="font-family:Calibri">4</span><span
			 style="font-family:宋体">个，现在只需</span><span style="font-family:Calibri">13.9</span><span style="font-family:宋体">元</span></span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">需要的童鞋可以戳进去购买</span></p>
	<p class="MsoNormal"><span style="font-size: 10.5pt;font-family:宋体"><br /></span></p>
	<p class="MsoNormal"><span style="font-size: 10.5pt;font-family:宋体"></span></p>
	<div class="single-content-one">
		<div class="single-info-one js_tobuy" id="itemid609664274685"><img src="https://img.alicdn.com/imgextra/i1/274619780/O1CN01w6VtLP2M7I8Wobx5Y_!!274619780.jpg"
			 alt="" class="getitemid" data-itemid="609664274685" data-tkrates="20" data-itemsale="3664" />
			<div class="single-details-one"><span class="phone-title single-title-one">晨光文具静音修正带低噪音涂改带</span>
				<div class="single-coupon-one"><span class="coupon-style"><span>券</span><span class="coupon">3</span></span><span>已售
						<span class="itemsale">3664</span></span></div>
				<div class="single-message single-message-one"><span class="single-price"><span>券后</span><span class="price">13.9</span></span><span
					 class="single-tkmoney"><span>佣金</span><span class="tkmoney">2</span></span><span class="single-tkrates"><span>营销</span><span
						 class="tkrates">20</span></span></div>
			</div>
			<div class="commodity-remove">
				<div class="trash-btn"><em class="am-icon-trash"></em></div>
			</div>
		</div>
	</div>
	<p></p>
	<p><br /></p>
	<p class="MsoNormal">
		<div style="text-align: center;"><span style="font-family:Calibri"><span style="font-size: 14px;"><br /></span></span></div><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">
			<div style="text-align: center;"><span style="font-size: 10.5pt;">更多学习文具小编就不一一介绍了</span></div>
		</span>
	</p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">都给大家整理到下方咯</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal" style="text-align: center;"><span style="mso-spacerun:&#39;yes&#39;;font-family:宋体;mso-ascii-font-family:Calibri; mso-hansi-font-family:Calibri;mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt; mso-font-kerning:1.0000pt;font-family:宋体">童鞋们快去看看还有什么需要买的</span><span
		 style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p></o:p>
		</span></p>
	<p class="MsoNormal"><span style="mso-spacerun:&#39;yes&#39;;font-family:Calibri;mso-fareast-font-family:宋体; mso-bidi-font-family:&#39;Times New Roman&#39;;font-size:10.5000pt;mso-font-kerning:1.0000pt;">
			<o:p>&nbsp;</o:p>
		</span></p>
	<div class="am-g commodity-group">
		<div class="commodity-info js_tobuy even-commodity" id="itemid598034310595">
			<div class="adaptive-picture"><img src="http://img.alicdn.com/imgextra/i4/2201503447259/O1CN01QrWQu923UfaE38Equ_!!2201503447259.jpg"
				 alt="" class="getitemid" data-itemid="598034310595" data-tkrates="20" data-itemsale="1315" /></div>
			<div class="commodity-details"><span class="phone-title details-title">【得力】考试专用橡皮檫十块</span>
				<div class="commodity-message">
					<div class="message-left"><span class="commodity-price"><span>券后</span><span class="price">6.9</span></span><span
						 class="commodity-tkmoney"><span>佣金</span><span class="tkmoney">1</span></span><span class="commodity-tkrates"><span>营销</span><span
							 class="tkrates">20%</span></span></div>
					<div class="message-right"><span>已售 <span class="itemsale">1315</span></span><span class="coupon-style"><span>券</span><span
							 class="coupon">2</span></span></div>
				</div>
			</div>
			<div class="commodity-remove">
				<div class="trash-btn"><em class="am-icon-trash"></em></div>
			</div>
		</div>
		<div class="commodity-info js_tobuy even-commodity" id="itemid529180268239">
			<div class="adaptive-picture"><img src="https://img.alicdn.com/i2/2076717316/O1CN01be1l3O23um5brzXn5_!!2076717316.jpg"
				 alt="" class="getitemid" data-itemid="529180268239" data-tkrates="20" data-itemsale="652" /></div>
			<div class="commodity-details"><span class="phone-title details-title">得力固体胶办公固体手工胶棒12个</span>
				<div class="commodity-message">
					<div class="message-left">
						<span class="commodity-price">
							<span>券后</span>
							<span class="price">7</span>
						</span>
						<span class="commodity-tkmoney">
							<span>佣金</span>
							<span class="tkmoney">1</span>
						</span>
						<span class="commodity-tkrates">
							<span>营销</span>
							<span class="tkrates">20%</span>
						</span>
					</div>
					<div class="message-right"><span>已售 <span class="itemsale">652</span></span><span class="coupon-style"><span>券</span><span
							 class="coupon">1</span></span></div>
				</div>
			</div>
			<div class="commodity-remove">
				<div class="trash-btn"><em class="am-icon-trash"></em></div>
			</div>
		</div>
		<div class="commodity-info js_tobuy even-commodity" id="itemid629743579027">
			<div class="adaptive-picture"><img src="http://img.alicdn.com/imgextra/i2/24208867/O1CN01esg5WK2FN8XpGyJ2X_!!24208867.jpg"
				 alt="" class="getitemid" data-itemid="629743579027" data-tkrates="40" data-itemsale="165" /></div>
			<div class="commodity-details"><span class="phone-title details-title">得力70802双头马克笔套装</span>
				<div class="commodity-message">
					<div class="message-left"><span class="commodity-price"><span>券后</span><span class="price">14.9</span></span><span
						 class="commodity-tkmoney"><span>佣金</span><span class="tkmoney">5</span></span><span class="commodity-tkrates"><span>营销</span><span
							 class="tkrates">40%</span></span></div>
					<div class="message-right"><span>已售 <span class="itemsale">165</span></span><span class="coupon-style"><span>券</span><span
							 class="coupon">5</span></span></div>
				</div>
			</div>
			<div class="commodity-remove">
				<div class="trash-btn"><em class="am-icon-trash"></em></div>
			</div>
		</div>
		<div class="commodity-info js_tobuy even-commodity" id="itemid628430585672">
			<div class="adaptive-picture"><img src="https://img.alicdn.com/i1/2206710128613/O1CN01wJlxfB2DUnwODqQ6U_!!2206710128613.jpg"
				 alt="" class="getitemid" data-itemid="628430585672" data-tkrates="30" data-itemsale="10160" /></div>
			<div class="commodity-details"><span class="phone-title details-title">【晨光】多功能打印复印A4纸</span>
				<div class="commodity-message">
					<div class="message-left"><span class="commodity-price"><span>券后</span><span class="price">3.9</span></span><span
						 class="commodity-tkmoney"><span>佣金</span><span class="tkmoney">1</span></span><span class="commodity-tkrates"><span>营销</span><span
							 class="tkrates">30%</span></span></div>
					<div class="message-right"><span>已售 <span class="itemsale">10160</span></span><span class="coupon-style"><span>券</span><span
							 class="coupon">1</span></span></div>
				</div>
			</div>
			<div class="commodity-remove">
				<div class="trash-btn"><em class="am-icon-trash"></em></div>
			</div>
		</div>
		<div class="commodity-info js_tobuy even-commodity" id="itemid551706480143">
			<div class="adaptive-picture"><img src="http://img.alicdn.com/i6/O1CN01YBSQ2M26P7iUlJELc_!!0-item_pic.jpg" alt=""
				 class="getitemid" data-itemid="551706480143" data-tkrates="30" data-itemsale="21962" /></div>
			<div class="commodity-details"><span class="phone-title details-title">晨光孔庙祈福笔芯0.5黑色笔芯</span>
				<div class="commodity-message">
					<div class="message-left"><span class="commodity-price"><span>券后</span><span class="price">6.8</span></span><span
						 class="commodity-tkmoney"><span>佣金</span><span class="tkmoney">2</span></span><span class="commodity-tkrates"><span>营销</span><span
							 class="tkrates">30%</span></span></div>
					<div class="message-right"><span>已售 <span class="itemsale">21962</span></span><span class="coupon-style"><span>券</span><span
							 class="coupon">1</span></span></div>
				</div>
			</div>
			<div class="commodity-remove">
				<div class="trash-btn"><em class="am-icon-trash"></em></div>
			</div>
		</div>
		<div class="commodity-info js_tobuy even-commodity" id="itemid626418384861">
			<div class="adaptive-picture"><img src="http://img-haodanku-com.cdn.fudaiapp.com/oimg_626418384861_1606187697.jpg"
				 alt="" class="getitemid" data-itemid="626418384861" data-tkrates="20" data-itemsale="823" /></div>
			<div class="commodity-details"><span class="phone-title details-title">【晨光】双头马克笔绘画笔套装</span>
				<div class="commodity-message">
					<div class="message-left"><span class="commodity-price"><span>券后</span><span class="price">7.6</span></span><span
						 class="commodity-tkmoney"><span>佣金</span><span class="tkmoney">1</span></span><span class="commodity-tkrates"><span>营销</span><span
							 class="tkrates">20%</span></span></div>
					<div class="message-right"><span>已售 <span class="itemsale">823</span></span><span class="coupon-style"><span>券</span><span
							 class="coupon">1</span></span></div>
				</div>
			</div>
			<div class="commodity-remove">
				<div class="trash-btn"><em class="am-icon-trash"></em></div>
			</div>
		</div>
		<div class="commodity-info js_tobuy even-commodity" id="itemid597186746193">
			<div class="adaptive-picture"><img src="https://img.alicdn.com/imgextra/i4/12590764/O1CN01fOubuw1HVxDKZH22i_!!12590764.jpg"
				 alt="" class="getitemid" data-itemid="597186746193" data-tkrates="30" data-itemsale="2192" /></div>
			<div class="commodity-details"><span class="phone-title details-title">乐桃派对限定修正涂改带5个装</span>
				<div class="commodity-message">
					<div class="message-left"><span class="commodity-price"><span>券后</span><span class="price">12.8</span></span><span
						 class="commodity-tkmoney"><span>佣金</span><span class="tkmoney">3</span></span><span class="commodity-tkrates"><span>营销</span><span
							 class="tkrates">30%</span></span></div>
					<div class="message-right"><span>已售 <span class="itemsale">2192</span></span><span class="coupon-style"><span>券</span><span
							 class="coupon">1</span></span></div>
				</div>
			</div>
			<div class="commodity-remove">
				<div class="trash-btn"><em class="am-icon-trash"></em></div>
			</div>
		</div>
		<div class="commodity-info js_tobuy even-commodity" id="itemid619028780686">
			<div class="adaptive-picture"><img src="http://img-haodanku-com.cdn.fudaiapp.com/oimg_619028780686_1602069918.jpg"
				 alt="" class="getitemid" data-itemid="619028780686" data-tkrates="20" data-itemsale="14517" /></div>
			<div class="commodity-details"><span class="phone-title details-title">大牌【晨光】80页超厚线圈本</span>
				<div class="commodity-message">
					<div class="message-left"><span class="commodity-price"><span>券后</span><span class="price">5.4</span></span><span
						 class="commodity-tkmoney"><span>佣金</span><span class="tkmoney">1</span></span><span class="commodity-tkrates"><span>营销</span><span
							 class="tkrates">20%</span></span></div>
					<div class="message-right"><span>已售 <span class="itemsale">14517</span></span><span class="coupon-style"><span>券</span><span
							 class="coupon">1</span></span></div>
				</div>
			</div>
			<div class="commodity-remove">
				<div class="trash-btn"><em class="am-icon-trash"></em></div>
			</div>
		</div>
	</div>
	<p></p>
	<p><br /></p>
	<p><br /></p>
</template>

<script>
	export default {
		data() {},
		mounted() {
			axios({
				method: "post", //请求方式
				url: cl.apiServer + 'doumee/talentInfo/talent_article', //请求路径
				params: {
					"id": aa

				}

				//传递参数
				//使用 箭头表达式=> 在代替原有的function来做回调函数
			}).then(result => {
				data = result.data;
				console.log(JSON.stringify(result.data));
				this.content = data.data.articleLabel;
				this.articleBanner = data.data.articleBanner;
				this.talentName = data.data.talentName;
				this.headImg = data.data.headImg;
				this.addtime = data.data.addtime;
				this.name = data.data.name;
				this.$nextTick(() => {
					$(document).ready(function() {
						// 隐藏部分敏感数据
						$('.single-message').remove();

					})

					// 图片超出处理
					$(function() {
						var articleWidth = $('.article-page-write').width();
						$('p img').each(function() {
							if ($(this).width() > articleWidth) {
								$(this).css({
									width: '100%',
									height: 'auto'
								});
							}
						});
					});

					$(function() {
						// 多个宝贝 - 只展示券后价
						$('.commodity-message').each(function() {
							var mobilePrice = $(this).find('.price').text(); // 旧版专属

							var commodity_priceStr =
								'<span class="mobile-coupon">券后 <span class="mobile-price price"></span></span>' +
								'<span class="mobile-sold">已售 <span class="itemsale"></span></span>';
							var coupon_str = '<div class="coupon-box">' +
								'<span class="coupon-style"><span>券</span><span class="coupon"></span></span>' +
								'<span class="commodity-view">查看</span>' +
								'</div>';
							$(this).html(commodity_priceStr);
							$(this).after(coupon_str);

							if ($('.commodity-bottom').length > 0) {
								$(this).find('.price').text(mobilePrice + '元');
							}
						});

						// 单个宝贝一 - 只展示券后价
						$('.single-info-one').each(function() {
							var single_priceStr = '<span class="mobile-coupon">券后 <span class="mobile-price price"></span></span>' +
								'<span class="mobile-sold">已售 <span class="itemsale"></span></span>';
							var coupon_str = '<div class="coupon-box">' +
								'<span class="coupon-style"><span>券</span><span class="coupon"></span></span>' +
								'<span class="commodity-view">查看</span>' +
								'</div>';
							$(this).find('.single-coupon-one').html(single_priceStr);
							$(this).find('.single-coupon-one').after(coupon_str);
						});

						// 单个宝贝二 - 只展示券后价
						$('.single-info').each(function() {
							var single_priceStr = '<span class="mobile-coupon">券后 <span class="mobile-price price"></span></span>' +
								'<span class="mobile-sold">已售 <span class="itemsale"></span></span>';
							var coupon_str = '<div class="coupon-box">' +
								'<span class="coupon-style"><span>券</span><span class="coupon"></span></span>' +
								'<span class="commodity-view">查看</span>' +
								'</div>';
							$(this).find('.single-coupon-two').html(single_priceStr);
							$(this).find('.single-coupon-two').after(coupon_str);
						});

						// 兼容旧版本
						$('.commodity-bottom').each(function() {
							$(this).prev('.coupon-box').css('display', 'none');
							$(this).prevAll('.commodity-message').children('.mobile-sold').remove();
						})
					});

					$('.js_tobuy').click(function() {
						var itemid = $(this).children('div').children('img').attr('data-itemid');
						if (!itemid) {
							itemid = $(this).children('img').attr('data-itemid');
						}
						// alert("商品id" + itemid);
						// 判断是否为失效商品
						var loseArr = data.data.invalidList;
						if (loseArr.indexOf(itemid) > -1) {
							//失效商品 不让进详情
							alert("商品已下架");
							return;
						}
						//console.log(itemid);return false;
						// message[itemid]['tkrates'] = message[itemid]['tkrates']/100;
						//   messageinfo = JSON.stringify(message[itemid]);
						var ua = navigator.userAgent.toLowerCase();
						if (/iphone|ipad|ipod/.test(ua)) {
							//  window.webkit.messageHandlers.openProduct.postMessage({methodName:"openProduct","title":"文章详情","data":messageinfo,"type":0});
							alert("我是IOS,跳转详情");
						} else if (/android/.test(ua)) {
							//  window.android.openProduct('文章详情',messageinfo,0);
							cl.openWin({
								name: 'goods_deatils',
								pageParam: {
									id: itemid
								}
							})
						}
					});

					$(function() {
						var itemid = $('.js_tobuy').children('div').children('img').attr('data-itemid');

						var list = data.data.items;
						for (var i = 0; i < list.length; i++) {
							$('#itemid' + list[i].itemid + ' .price').text('￥' + Math.floor(list[i].itemendprice * 10) / 10);
							$('#itemid' + list[i].itemid + ' .coupon').text(list[i].couponmoney);
							$('#itemid' + list[i].itemid + ' .itemsale').text(list[i].itemsale);

							//拼接未失效宝贝
							var commodityStr = "<div class='commodity-item' data-itemid='" + list[i].itemid + "'><img src='" + list[i]
								.itempic + "' alt='' class='commodity-img'>" +
								"<div class='commodity-item-info' style='padding: 0 1rem;'>" +
								"<span class='commodity-title'>" + list[i].itemshorttitle + "</span>" +
								"<span class='commodity-item-price'>券后<span>" + Math.floor(list[i].itemendprice * 10) / 10 +
								"</span>元</span>" +
								"<div class='commodity-bottom'>" +
								"<span class='commodity-couponmoney'>" +
								"<span class='ommodity-ticket'>券</span><span class='commodity-coupon'>￥" + list[i].couponmoney +
								"</span>" +
								"</span>" +
								"<span class='commodity-sale'>已售 <span class='itemsale'>" + list[i].itemsale + "</span></span>" +
								"</div>" +
								"</div>" +
								"</div>";
							$('.commodity-list').append(commodityStr);
						};
					});


					//提示商品失效
					var lose = data.data.invalidList;
					if (lose != null && lose != '') {
						for (var i = 0; i < lose.length; i++) {
							if ($('#itemid' + lose[i] + ' .shadow').length == 0) {
								$('#itemid' + lose[i] + ' .getitemid').after('<div class="shadow"><span class="shadowtext"></span></div>');
							}
							$('#itemid' + lose[i] + ' .shadowtext').css('display', 'inline-flex');
							$('#itemid' + lose[i] + ' .shadowtext').text('已抢光');
							$('#itemid' + lose[i]).removeClass('js_tobuy');

							$('#itemid' + lose[i] + ' .price').text('￥' + "0");
							$('#itemid' + lose[i] + ' .coupon').text("0");
							$('#itemid' + lose[i] + ' .itemsale').text("999");

						}
					}



				})

			})
		}
	}
</script>

<style>

</style>
