<template>
	<view class="model-container colCen">
		<view class="title-box">
			请确认您的邀请人
		</view>
		<view class="subtitle-box">
			仅可填写一次，请核对邀请人信息
		</view>

		<view class="avatar-box defIcon">
			<image :src="inviterInfo.avatar" mode="aspectFill"></image>
		</view>

		<view class="username">
			{{inviterInfo.nickName}}
		</view>

		<view class="phoneInfo rowCenCen">
			<view>{{inviterInfo.account}}</view>
		</view>

		<view class="btn-bar rowCenBet">
			<view class="cancel rowCenCen" @tap="cancel()">
				<view>重新填写</view>
			</view>
			<view class="confirm rowCenCen" @tap="setinvite()">
				<view>确认添加</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				inviteCode: '',
				inviterInfo: ''
			}
		},
		created() {
			this.inviterInfo = uni.getStorageSync('inviterInfo')
		},
		methods: {
			setinvite() {
				this.$http.get('member/bindInviteCode',{
					inviteCode:this.inviterInfo.inviteCode
				}).then(res=>{
					uni.showToast({
						title:'绑定成功！',
						icon:'none'
					})
					this.$emit('setInvite')
				}).catch(res=>{
					console.log(res);
				})
			},
			cancel(){
				this.$emit('rewrite')
			}
		}
	}
</script>

<style lang="scss">
	.model-container {
		width: 500rpx;
		background: #FFFFFF;
		padding: 0 30rpx;

		.title-box {
			font-size: 30rpx;
			font-weight: bold;
			color: #333333;
			margin-top: 20rpx;
		}

		.subtitle-box {
			font-size: 24rpx;
			font-weight: 500;
			color: #333333;
			margin-top: 25rpx;
		}

		.avatar-box {
			width: 126rpx;
			height: 126rpx;
			overflow: hidden;
			border-radius: 50%;
			margin-top: 30rpx;
		}

		.username {
			font-size: 24rpx;
			font-weight: 500;
			color: #333333;
			margin-top: 20rpx;
		}

		.phoneInfo {
			width: 100%;
			height: 104rpx;
			background: #F7F7F7;
			border-radius: 8rpx;
			font-size: 36rpx;
			font-weight: bold;
			color: #333333;
			margin-top: 20rpx;
		}

		.btn-bar {
			width: 100%;
			margin-top: 30rpx;
			margin-bottom: 30rpx;

			.cancel {
				width: 196rpx;
				height: 72rpx;
				background: #E5E5E5;
				font-size: 30rpx;
				font-weight: 500;
				color: #333333;
				border-radius: 36rpx;
			}

			.confirm {
				width: 196rpx;
				height: 72rpx;
				background: #FD002F;
				border-radius: 36rpx;
				font-size: 30rpx;
				font-weight: 500;
				color: #FFFFFF;
			}
		}
	}
</style>
