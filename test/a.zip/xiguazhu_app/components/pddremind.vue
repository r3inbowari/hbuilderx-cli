<template>
	<view class="pddremind-container colCen">
		<view class="topbac rowStaCen">
			<image class="bac" src="../static/images/app/baccc.png" mode="aspectFill"></image>
			<view class="title">
				无佣金风险提醒
			</view>
		</view>
		<view class="tips-container colCen">
			<view class="grey-txt">
				该商品可能涉及比价，自购可能会无佣金
			</view>
			<view class="pink-txt">
				比价定义：您在拼多多APP/网站访问了该商品的详情，再通过本APP进行转链自购的行为
			</view>
		</view>
		<view class="btn-container rowCenCen" @tap="close()">
			<view>我已知晓</view>
		</view>
	</view>
</template>

<script>
	import util from '../utils/utils.js'
	const plug = uni.requireNativePlugin('Html5app-Baichuan')
	export default {
		data() {
			return {
				applogo: ''
			}
		},
		methods: {
			close() {
				this.$emit('closepdd')
			}
		}
	}
</script>

<style lang="scss">
	.pddremind-container {
		width: 600rpx;
		height: 630rpx;
		background: #FFFFFF;
		border-radius: 10rpx;
		padding: 0 45rpx;
		position: relative;

		.topbac {
			width: 600rpx;
			height: 350rpx;
			position: absolute;
			top: 0;
			left: 0;

			.bac {
				position: absolute;
				width: 100%;
				height: 100%;
			}

			.title {
				z-index: 10;
				font-size: 48rpx;
				font-weight: bold;
				color: #FFFFFF;
				margin-top: 100rpx;
			}
		}

		.tips-container {
			width: 100%;
			background: #FFFFFF;
			border-radius: 10rpx;
			margin-top: 215rpx;
			z-index: 100;
			padding: 50rpx 30rpx;
			font-size: 24rpx;
			font-weight: 500;
			line-height: 40rpx;
			text-align: center;
			box-shadow: 0rpx 5rpx 9rpx 3px rgba(0, 0, 0, 0.1);

			.grey-txt {
				color: #666666;
			}

			.pink-txt {
				color: #FD002F;
			}
		}

		.btn-container {
			width: 100%;
			height: 78rpx;
			background: #FD002F;
			box-shadow: 0px 5rpx 9rpx 0px rgba(253, 0, 47, 0.33);
			border-radius: 39rpx;
			font-size: 30rpx;
			font-weight: 500;
			color: #FFFFFF;
			margin-top: 50rpx;
		}
	}
</style>
