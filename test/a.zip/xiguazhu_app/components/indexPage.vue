<template>
	<view class="page-content">
		<scroll-view class="swiper-scroll" :refresher-background='headerColor' @scroll='pagescroll' :scroll-y="!hiddenPage"
		 :scroll-top='scrollindex' :scroll-anchoring='true' scroll-with-animation lower-threshold='500' @scrolltolower="getNextPage">

			<refresh @down="end" :heightRh='(Topheight) + "px"' :color='headerColor' :canrefresh="canrefresh">
				<slot>
					<view class="indexbody-index-wrapper colCen borderBox">
						<view class="topheaderCard-container colCen borderBox">
							<view class="ellipse" :style="'background:'+ headerColor +';'"></view>
						</view>
						<view class="pageBody-container colCen borderBox">
							<view class="column-container">
								<view class="bannerSwiper-container colCenCen borderBox" v-if="topBannerList.length>0">
									<swiper class="swiper-box" :current="swpidx" @change="changeColor" :autoplay="true" :interval="3000"
									 :duration="500" :indicator-dots="true" :indicator-active-color="'#fff'" circular>
										<swiper-item v-for="(items,index) in topBannerList" :key='index'>
											<view class="swiper-item defIcon" @click="goUrl(items)">
												<image :src="items.pic" mode="aspectFit"></image>
											</view>
										</swiper-item>
									</swiper>
								</view>

								<view class="centerSwiper-container colCenCen borderBox" v-if="singleLineList.length>0">
									<swiper class="swiper-box" :autoplay="true" :interval="5000" :duration="300" circular>
										<swiper-item v-for="(items,index) in singleLineList" :key='index'>
											<view class="swiper-item defIcon" @click="goUrl(items)">
												<image :src="items.pic" mode="aspectFit"></image>
											</view>
										</swiper-item>
									</swiper>
								</view>

								<view class="cardsList-container rowCenBet borderBox" v-if="doubleLineList.length>0">
									<block v-for="(items,index) in doubleLineList" :key='index'>
										<view class="card-items defIcon" @click="goUrl(items)">
											<image :src="items.pic" mode="aspectFill" lazy-load="true"></image>
										</view>
									</block>
								</view>


								<!-- 金刚区 -->
								<view class="navslider-box" v-if="navbarShowList.length > 0">
									<swiper class="swiper-type swiper-nav" :indicator-dots="navbarList.length > 10 ? true : false" indicator-color="#eaeaea"
									 indicator-active-color="#FE3A33" :duration="500" :style="sliderH">
										<swiper-item v-for="(sliderItem, index) in navbarShowList" :key="index">
											<view class="slider_itemslist rowSta">
												<view class="item colCen" v-for="(item, idx) in sliderItem" :key="idx" @click="goUrl(item)">
													<image :src="item.mpic" :lazy-load="true" mode="aspectFit"></image>
													<view class="desc">{{ item.mname }}</view>
												</view>
											</view>
										</swiper-item>
									</swiper>
								</view>

								<view class="bottomSwiper-container colCenCen borderBox" v-if="bottomBannerList.length>0">
									<swiper class="swiper-box" :autoplay="true" :interval="3000" :duration="300" circular>
										<swiper-item v-for="(items,index) in bottomBannerList" :key='index'>
											<view class="swiper-item defIcon" @click="goUrl(items)">
												<image :src="items.pic" mode="widthFix"></image>
											</view>
										</swiper-item>
									</swiper>
								</view>
							</view>
						</view>

						<view class="pagebottomBody-container colCen borderBox">
							<!-- 四个宫格 -->
							<view class="four-container rowCen">
								<view class="cell-container borderBox" @tap="goPDDone()">
									<view class="cell-title rowCen">
										<image class="tit-icon" src="../static/images/home/one.png" mode="aspectFit"></image>
										<view class="tit-tips rowCenCen">
											<view>独家福利</view>
										</view>
									</view>
									<view class="pic-content rowCenBet">
										<block v-for="(items,index) in beanCurd.PDDOne.slice(0,2)" :key="index">
											<view class="pic-items colCen">
												<image class="pic" :src="items.mainPic"></image>
												<view class="price-info">
													￥ {{items.actualPrice}}
												</view>
											</view>
										</block>
									</view>
								</view>
								<view class="cell-container borderBox">
									<view class="cell-title rowCen">
										<image class="tit-icon" src="https://hxshapp.oss-cn-beijing.aliyuncs.com/app/img/20210702/baokuan.png" mode="aspectFit"></image>
										<view class="tit-tips rowCenCen" style="background: linear-gradient(76deg, #FAC324, #FA9013);">
											<view>品牌特卖</view>
										</view>
									</view>
									<view class="pic-content rowCenBet" @tap="goJDsale()">
										<block v-for="(items,index) in beanCurd.JDMiaoSha.slice(0,2)" :key="index">
											<view class="pic-items colCen">
												<image class="pic" :src="items.mainPic"></image>
												<view class="price-info">
													￥ {{items.actualPrice}}
												</view>
											</view>
										</block>
									</view>
								</view>
								<view class="cell-container borderBox" @tap="godpage(0)">
									<view class="cell-title rowCen">
										<image class="tit-icon" src="../static/images/home/tbzb.png" mode="aspectFit"></image>
										<view class="tit-tips rowCenCen" style="background: linear-gradient(76deg, #FC6857, #FD364B);">
											<view>热销</view>
										</view>
									</view>
									<view class="pic-content rowCenBet">
										<block v-for="(items,index) in beanCurd.LiveGoods.slice(0,2)" :key="index">
											<view class="pic-items colCen">
												<image class="pic" :src="items.mainPic"></image>
												<view class="price-info">
													￥ {{items.actualPrice}}
												</view>
											</view>
										</block>
									</view>
								</view>
								<view class="cell-container borderBox" @tap="godpage(1)">
									<view class="cell-title rowCen">
										<image class="tit-icon" src="../static/images/home/butie.png" mode="aspectFit"></image>
										<view class="tit-tips rowCenCen" style="background: linear-gradient(76deg, #FC5536, #F63722);">
											<view>大牌补贴</view>
										</view>
									</view>
									<view class="pic-content rowCenBet">
										<block v-for="(items,index) in beanCurd.BaiYiBuTie.slice(0,2)" :key="index">
											<view class="pic-items colCen">
												<image class="pic" :src="items.mainPic"></image>
												<view class="price-info">
													￥ {{items.actualPrice}}
												</view>
											</view>
										</block>
									</view>
								</view>
							</view>

							<!-- 每日必买 -->
							<view class="everysBuying-container colCen" v-if="zdmList.length>0">
								<view class="box-bar-content rowCen">
									<view class="title-text">
										每日必买
									</view>
									<view class="tips-txt rowCenCen">
										<view>精选爆款</view>
									</view>
								</view>
								<view class="goodsScroll-container rowCen">
									<scroll-view class="scrollgoods-box" scroll-x scroll-with-animation>
										<view class="scrollList-content">
											<view class="goods-items" v-for="(items,index) in zdmList" :key="index" @tap="goDetail(items)">
												<view class="items-container colCen">
													<view class="image-content defIcon">
														<image style="border-radius: 8rpx;" :src="items.itempic" mode="aspectFill" :lazy-load="true"></image>
													</view>

													<view class="goodsinfo-content colCen borderBox">
														<view class="goodsName-box">
															{{items.itemshorttitle}}
														</view>
														<view class="coupons-container rowCen">
															<view class="couponbac-content rowCen">
																<view class="textsTip">
																	爆款
																</view>
																<view class="coupons-value">
																	{{items.couponmoney}}元券
																</view>
															</view>
														</view>
														<view class="price-info-container rowEnd">
															<view class="nowPrice-content rowEnd">
																<view class="rmbicon">
																	￥
																</view>
																<view class="nowprice">
																	{{items.itemendprice}}
																</view>
															</view>
															<view class="oldPrice-content rowEnd">
																<view class="oldprice">
																	￥{{items.itemprice}}
																</view>
															</view>
														</view>
													</view>
												</view>
											</view>
										</view>
									</scroll-view>
								</view>
							</view>

							<!-- 好货直降 -->
							<view class="goodsFalling-container colCen" v-if="fallingList.length>0">
								<view class="box-bar-content rowCen">
									<view class="title-text">
										好货直降
									</view>
									<view class="tips-txt rowCenCen">
										<view>低过聚划算.省过淘抢购</view>
									</view>
								</view>
								<view class="goodsScroll-container rowCen">
									<scroll-view class="scrollgoods-box" scroll-x scroll-with-animation>
										<view class="scrollList-content">
											<view class="goods-items" v-for="(items,index) in fallingList" :key="index" @tap="goDetail(items,true)">
												<view class="items-container colCen">
													<view class="image-content defIcon">
														<image style="border-radius: 8rpx;" :src="items.mainPic" mode="aspectFill" :lazy-load="true"></image>
														<view class="spec-box rowCenCen" v-if="items.specialText.length>0">
															<view>{{items.specialText[0]}}</view>
														</view>
													</view>

													<view class="goodsinfo-content colCen borderBox">
														<view class="goodsName-box">
															{{items.dtitle}}
														</view>
														<view class="price-info-container rowEnd">
															<view class="nowPrice-content rowEnd">
																<view class="rmbicon">
																	￥
																</view>
																<view class="nowprice">
																	{{items.actualPrice}}
																</view>
															</view>
															<view class="oldPrice-content rowEnd">
																<view class="oldprice">
																	￥{{items.originalPrice}}
																</view>
															</view>
														</view>
														<view class="saleNum-container rowCen">
															<view class="content-box rowCen">
																<view class="txt-tips rowCenBet">
																	爆款
																</view>
																<view class="salenum rowCenCen">
																	<view>{{items.monthSales}}件</view>
																</view>
															</view>
														</view>
														<view class="likeNum-container rowCen">
															<view class="like-num">
																{{items.twoHoursSales}}
															</view>
															<view class="txt">
																人想买
															</view>
														</view>
													</view>
												</view>
											</view>
										</view>
									</scroll-view>
								</view>
							</view>

							<!-- 福利抢购 -->
							<view class="welfare-container colCen">
								<view class="titlebar-container rowCenBet">
									<view class="left-content rowCen">
										<view class="titletext">
											福利抢购
										</view>
									</view>
								</view>

								<view class="goodsList-container colCen">
									<block v-for="(items,index) in phbList.slice(0,4)" :key="index">
										<view class="goods-items-container rowCen borderBox" @click="goDetail(items)">
											<view class="left-imagecontent defIcon">
												<image style="border-radius: 8rpx;" :src="items.mainPic" mode="aspectFill"></image>
											</view>

											<view class="right-goodsinfo-container colCenBet borderBox">
												<view class="top-content-box colCen">
													<view class="goodsnameinfo-content rowSta">
														<view class="typeIcon-content defIcon">
															<image :src="items.icon" mode="heightFix"></image>
														</view>
														<view class="tradename">
															{{items.dtitle}}
														</view>
													</view>

													<view class="desc-box">
														{{items.desc}}
													</view>
												</view>

												<view class="btm-content-box colCen">
													<view class="discounts-container rowCen borderBox">
														<view class="coupon-box rowCenCen">
															<view>
																{{items.couponPrice}}元券
															</view>
														</view>


														<view class="back-box rowCenCen">
															<view>
																返{{items.fanli}}元
															</view>
														</view>
													</view>

													<view class="price-saleNums-container rowEndBet">
														<view class="left-price-box rowEnd">
															<view class="nowpirce rowEnd">
																<view class="rmb">
																	￥
																</view>
																<view class="num">
																	{{items.actualPrice}}
																</view>
															</view>

															<s class="original-price">
																￥{{items.originalPrice}}
															</s>
														</view>

														<view class="saleNum-content">
															爆卖{{items.monthSales}}件
														</view>
													</view>
												</view>
											</view>
										</view>
									</block>
								</view>
							</view>

							<!-- 抖好券 -->
							<view class="Tiktok-container colCen">
								<view class="titlebar-container rowCenBet">
									<view class="left-content rowCen">
										<view class="titletext">
											抖好货
										</view>
										<view class="bubble-box rowCenCen">
											<view>精选爆款·抖音好物</view>
										</view>
									</view>
								</view>

								<view class="goodsTopList Tiktoklist rowCenBet">
									<scroll-view class="scrollgoods-box" scroll-x scroll-with-animation>
										<view class="scrollList-content">
											<view class="goods-items" v-for="(items,index) in dyList" :key='index'>
												<view class="items-container colCen" @tap="godydetails(items)">
													<view class="image-content defIcon">
														<image style="border-radius: 8rpx;" :src="items.dynamicImage" mode="aspectFill" :lazy-load="true"></image>
														<view class="playback-volume iconfont rowCenCen">
															<span>&#xe617;</span>{{items.dyVideoLikeCount}}
														</view>
														<view class="suspend defIcon rowCenCen">
															<image src="@/static/images/goods/suspend.png" mode=""></image>
														</view>
													</view>

													<view class="goodsinfo-content colCen borderBox">
														<view class="goodsName-box">
															{{items.itemshorttitle}}
														</view>
														<view class="coupons-container rowCen">
															<view class="couponbac-content rowCenCen">
																<view class="coupons-value">
																	{{items.couponmoney}}元券
																</view>
															</view>
														</view>
														<view class="price-info-container rowEnd">
															<view class="nowPrice-content rowEnd">
																<view class="rmbicon">
																	￥
																</view>
																<view class="nowprice">
																	{{items.itemendprice}}
																</view>
															</view>
															<view class="oldPrice-content rowEnd">
																<view class="oldprice">
																	￥{{items.itemprice}}
																</view>
															</view>
														</view>
													</view>
												</view>
											</view>
										</view>
									</scroll-view>
								</view>

								<view class="gomore-bar iconfont rowCenCen" @tap="goTik()">
									<view>查看更多抖好货商品 &#xe713;</view>
								</view>
							</view>
						</view>

						<view class="goods-bottom-List colCen borderBox">
							<view class="bottomTypebar-container colCen borderBox">
								<view class="typeList rowCenCen borderBox">
									<block v-for="(items,index) in typedataList" :key='index'>
										<view class="type-items-container colCenCen" @click="switchtype(items,index)" :class="bottomCurrent==index?'type-container-active':''">
											<view class="mainTitle">
												{{items.mainTitle}}
											</view>
											<view class="subtitle rowCenCen">
												<view>{{items.subTitle}}</view>
											</view>
										</view>
									</block>
								</view>
							</view>

							<view class="bottomGoods-list-container rowCenBet borderBox" v-if="bottomGoodsList.length>0">
								<block v-for="(items,index) in bottomGoodsList" :key="index">
									<view class="goods-items" @click="goDetails(items)">
										<colGoods :items="items"></colGoods>
									</view>
								</block>

								<aLoadMore :status="loadstatus" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
							</view>
						</view>
					</view>
				</slot>
			</refresh>
		</scroll-view>
		<slideTop v-if="scrollTop>1000" @toTop='scrolltoTops'></slideTop>
		
		<!-- taobao -->
		<u-popup v-model="empowerModel" mode="center" border-radius="12">
			<empowerModel @closemodel='closeMdl' @updataInfo='updataUser'></empowerModel>
		</u-popup>
	</view>
</template>

<script>
	var top = 0
	import refresh from './refresh.vue'
	import utils from '../utils/utils.js'
	import slideTop from './slideTop.vue'
	import colGoods from './colGoods.vue'
	import empowerModel from './empowerModel.vue'
	export default {
		props: {
			Topheight: {
				type: Number,
				default: 90
			},
			canrefush: {
				type: Boolean
			},
			hiddenPage: {
				type: Boolean,
				default: false
			}
		},
		components: {
			slideTop,
			colGoods,
			refresh,
			empowerModel
		},
		data() {
			return {
				pageHeight: '',
				headerColor: '',
				topBannerList: [],
				singleLineList: [],
				doubleLineList: [],
				bottomBannerList: [],
				navbarShowList: [],
				navbarList: [],
				sliderH: '',

				scrollTop: 0,
				scrollindex: 0,


				zdmList: [],
				phbList: [],
				dyList: [],

				typedataList: [{
						mainTitle: '推荐',
						subTitle: '为你推荐',
						type: 1
					},
					{
						mainTitle: '京东',
						subTitle: '官方保障',
						type: 2
					},
					{
						mainTitle: '拼多多',
						subTitle: '百亿补贴',
						type: 3
					},
					{
						mainTitle: '唯品会',
						subTitle: '大牌精选',
						type: 4
					}
				],
				bottomType: 1,
				bottomCurrent: 0,
				bottomGoodsList: [],
				loadingState: false,

				currentPage: 1,
				loadstatus: 'loading',

				beanCurd: {
					BaiYiBuTie: '',
					JDMiaoSha: '',
					LiveGoods: '',
					PDDOne: ''
				},

				fallingList: [],

				triggeredstate: true,
				swpidx: 0,
				canrefresh: 0,
				empowerModel:false
			}
		},
		watch: {
			navbarList(nval, oval) {
				let index = 0;
				while (index < nval.length) {
					this.navbarShowList.push(nval.slice(index, (index += 10)));
				}
				if (this.navbarList.length > 5) {
					this.sliderH = 'height:345rpx;';
				} else {
					this.sliderH = 'height:160rpx;';
				}
			},
			headerColor: {
				handler(nvl, ovl) {
					this.$emit('passColor', nvl)
				},
				immediate: true
			},
			canrefush(){
				console.log(this.canrefush);
				if(this.canrefush){
					this.canrefresh = 0
				}else{
					uni.$emit("reMsg", -1)
					this.canrefresh = 1
				}
			}
		},
		created() {
			this._freshing = false;
			uni.$emit('initpage')
			this.getBannerInfo();
			this.getHomeMenuList();
			this.getrecommendGoods();
			this.getbeanCurd()
			this.getGOODSfalling()
			this.getbottomGoodsList(this.bottomType);
		},
		mounted() {
			this.$emit('scrolltoTop')
			setTimeout(() => {
				this.getfixedHeight()
			}, 1500)
		},
		methods: {
			end(i) {
				// 这里写刷新业务
				this.getBannerInfo();
				this.getrecommendGoods();
				this.getbeanCurd()
				this.getGOODSfalling()
				this.getbottomGoodsList(this.bottomType);
			},
			pagescroll(e) {
				this.$emit('scrollNum', e.detail.scrollTop)
				this.scrollTop = e.detail.scrollTop
				if (e.detail.scrollTop > 0) {
					setTimeout(() => {
						this.canrefresh = 1
					})
				} else {
					this.canrefresh = 0
				}
			},

			godpage(title) {
				uni.navigateTo({
					url: '../active/commonList?type=' + title
				})
			},

			scrolltoTops() {
				this.scrollindex = this.scrollTop
				this.$nextTick(() => {
					this.scrollindex = 0
				})
			},

			getBannerInfo() {
				// banner数据
				this.$http.get('banner/list/1').then((res) => {
					this.topBannerList = res.topBannerList;
					this.swpidx = 0,
					this.headerColor = this.topBannerList[0].colour;
					this.singleLineList = res.singleLineList;
					this.doubleLineList = res.doubleLineList;
					this.bottomBannerList = res.bottomBannerList;
					setTimeout(() => {
						this.triggeredstate = false;
						this._freshing = false;
					}, 300)
				})
			},

			getbeanCurd() {
				// 豆腐块数据数据
				this.$http.post('tb/getBeancurdCube').then((res) => {
					this.beanCurd = res
				})
			},

			getGOODSfalling() {
				this.$http.post('tb/superDiscountGoods', {
					pageId: 1,
					pageSize: 10
				}).then((res) => {
					// console.log(res);
					this.fallingList = res
				})
			},

			goTik() {
				uni.navigateTo({
					url: '../active/tiktoklist'
				})
			},

			godydetails(itm) {
				const info = {}
				info.nowInfo = itm
				info.pageCurrent = 2
				info.type = 0
				info.storgeList = this.dyList
				utils.setCache('pathInfo', info)
				uni.navigateTo({
					url: '../active/dyvideoDetails'
				})
			},

			getHomeMenuList() {
				// 金刚区
				this.$http.post('homeMenu/getHomeMenuList', {
					type: 1
				}, 'application/json').then((res) => {
					this.navbarList = res;
				})
			},

			getrecommendGoods() {
				this.$http.post('tb/getMQD').then((res) => {
					// console.log(res);
					this.zdmList = res.zdm;
					this.phbList = res.phb;
					this.dyList = res.dygoods;
				})
			},

			getbottomGoodsList(type) {
				this.$http.post('tb/getGoodThing', {
					deviceType: getApp().globalData.platform == 'android' ? (getApp().globalData.systemLevel < 10 ? 'IMEI' : 'OAID') :
						'IDFA',
					deviceValue: getApp().globalData.equipmentNumber,
					pageId: 1,
					pageSize: 10,
					type: type
				}, 'application/json',true).then((res) => {
					uni.$emit("reMsg", -1)
					// console.log(res);
					if (res.length < 10) {
						this.loadingState = false
						this.loadstatus = 'nomore'
					} else {
						this.currentPage++
						this.loadstatus = 'loading'
						this.loadingState = true
					}
					this.bottomGoodsList = res
				}).catch(res=>{
					uni.$emit("reMsg", -1)
				})
			},

			getNextPage() {
				if (this.loadingState) {
					this.loadingState = false
					this.$http.post('tb/getGoodThing', {
						deviceType: getApp().globalData.platform == 'android' ? (getApp().globalData.systemLevel < 10 ? 'IMEI' : 'OAID') :
							'IDFA',
						deviceValue: getApp().globalData.equipmentNumber,
						pageId: this.currentPage,
						pageSize: 10,
						type: this.bottomType,
					}, 'application/json').then((res) => {
						if (res.length < 10) {
							this.loadingState = false
							this.loadstatus = 'nomore'
						} else {
							this.currentPage++
							this.loadstatus = 'loading'
							this.loadingState = true
						}
						this.bottomGoodsList = this.bottomGoodsList.concat(res)
					})
				}
			},

			switchtype(info, idx) {
				if (this.bottomCurrent != idx) {
					this.currentPage = 1;
					this.bottomType = info.type;
					this.getbottomGoodsList(this.bottomType);
					this.$nextTick(() => {
						this.$emit('scrolltoview')
						this.bottomCurrent = idx;
					})
				}
			},

			getfixedHeight(e) {
				uni.createSelectorQuery().in(this).select('.goods-bottom-List').boundingClientRect(data => {
					this.$emit('pushfixed', data.top)
				}).exec();
			},

			changeColor(e) {
				this.swpidx = e.detail.current
				this.topBannerList.forEach((itm, idx) => {
					if (idx == e.detail.current) {
						this.headerColor = itm.colour
					}
				})
			},

			goUrl(info) {
				utils.goUrl(info,this)
			},
			
			closeMdl() {
				this.empowerModel = false
				this.pddempowerModel = false
			},
			
			updataUser() {
				this.userInfo = utils.getCacheSync('userData')
				this.$http.get('member/getInfo', {}, true).then((res) => {
					console.log(res, '========>获取用户信息');
					this.userInfo = res
					utils.setCache('userData', res)
				})
			},

			// gojgqUrl(info) {
			// 	console.log(info);
			// 	if (info.urlType == '0') {
			// 		uni.navigateTo({
			// 			url: '../webView/webView?url=' + info.murl
			// 		})
			// 	} else if (info.urlType == 1) {
			// 		uni.navigateTo({
			// 			url: info.murl
			// 		})
			// 	} else if (info.urlType == '2') {
			// 		// #ifdef APP-PLUS
			// 		if (plus.os.name == 'Android') {
			// 			console.log(plus.os.name);
			// 			plus.runtime.openURL(info.murl, res => {
			// 				uni.navigateTo({
			// 					url: '../webView/webView?url=' + info.murl
			// 				})
			// 			}, 'com.taobao.taobao');
			// 		} else {
			// 			info.murl = info.murl.split('//')[1]
			// 			plus.runtime.openURL('taobao://' + info.murl, function(res) {
			// 				uni.navigateTo({
			// 					url: '../webView/webView?url=' + info.murl
			// 				})
			// 			}, 'taobao://');
			// 		}
			// 		// #endif
			// 	}
			// },

			goDetails(info) {
				if (this.bottomCurrent == 2) {
					info.searchSource = 2
				} else if (this.bottomCurrent == 1) {
					info.searchSource = 3
				} else if (this.bottomCurrent == 3) {
					info.searchSource = 4
				} else {
					info.searchSource = 1
				}
				this.$nextTick(() => {
					uni.navigateTo({
						url: '../goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(info))
					})
				})
			},
			
			goDetail(info,state){
				if (state) {
					info.searchSource = 1
				}
				this.$nextTick(() => {
					uni.navigateTo({
						url: '../goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(info))
					})
				})
			},

			goPDDone() {
				uni.navigateTo({
					url: '../active/everydayRecommend'
				})
			},
			goJDsale() {
				uni.navigateTo({
					url: '../active/vipsearch'
				})
			}
		}
	}
</script>

<style lang="scss">
	.loading-img {
		width: 100%;
		height: 150rpx;

		.imgbox {
			width: 208rpx;
			height: 126rpx;
			// max-height: 72rpx;
		}
	}

	.swiper-scroll {
		width: 100%;
		height: 100vh;
	}

	.hidebox {
		height: 100vh;
		overflow: hidden;
	}

	.indexbody-index-wrapper {
		width: 100%;

		.topheaderCard-container {
			width: 100%;
			height: 200rpx;
			position: absolute;

			.ellipse {
				width: 130%;
				height: 100%;
				border-radius: 0 0 50% 50%;
			}
		}

		.pageBody-container {
			width: 100%;
			background-color: #FFFFFF;

			.column-container {
				width: 100%;
				z-index: 10;

				.bannerSwiper-container {
					width: 100%;
					height: 280rpx;
					padding: 0 32rpx;
					margin-bottom: 20rpx;

					/deep/.swiper-box {
						width: 100%;
						height: 100%;

						.swiper-item {
							width: 100%;
							height: 100%;
							border-radius: 12rpx;
							overflow: hidden;
						}

						.uni-swiper-dot {
							width: 20rpx;
							height: 6rpx;
							border-radius: 3rpx;
						}
					}
				}


				.centerSwiper-container {
					width: 100%;
					height: 190rpx;
					padding: 0 32rpx;
					margin-bottom: 20rpx;

					.swiper-box {
						width: 100%;
						height: 100%;

						.swiper-item {
							width: 100%;
							height: 100%;
						}
					}
				}

				.cardsList-container {
					width: 100%;
					flex-wrap: wrap;
					padding: 0 32rpx;
					margin-bottom: 20rpx;

					.card-items {
						width: 340rpx;
						height: 135rpx;
						overflow: hidden;
						border-radius: 8rpx;
						margin-bottom: 10rpx;
					}
				}

				/deep/.navslider-box {
					width: 100%;

					.swiper-type {
						width: 100%;

						.slider_itemslist {
							width: 100%;
							flex-wrap: wrap;

							.item {
								width: 150rpx;
								margin-bottom: 30rpx;

								image {
									width: 80rpx;
									height: 80rpx;
									margin-bottom: 10rpx;
								}

								.desc {
									font-size: 28rpx;
									font-weight: 400;
									color: #333333;
								}
							}
						}
					}

					.uni-swiper-dot {
						width: 20rpx;
						height: 6rpx;
						border-radius: none;
					}
				}

				.bottomSwiper-container {
					width: 100%;
					height: 228rpx;
					padding: 0 32rpx;

					.swiper-box {
						width: 100%;
						height: 100%;

						.swiper-item {
							width: 100%;
							height: 100%;
						}
					}
				}
			}
		}

		.pagebottomBody-container {
			width: 100%;
			padding: 0 20rpx;
			margin: 20rpx 0;

			.four-container {
				width: 100%;
				height: 624rpx;
				background: #FFFFFF;
				flex-wrap: wrap;
				border-radius: 16rpx;
				margin-bottom: 20rpx;

				.cell-container {
					width: 50%;
					height: 312rpx;
					padding: 10rpx 21rpx;

					.cell-title {
						margin-top: 30rpx;

						.tit-icon {
							width: 153rpx;
							height: 30rpx;
						}

						.tit-tips {
							height: 30rpx;
							background: linear-gradient(76deg, #FA5F41, #FF3D27);
							border-radius: 14rpx 4rpx 14rpx 4rpx;
							font-size: 24rpx;
							font-weight: 500;
							color: #FFFFFF;
							margin-left: 20rpx;
							padding: 0 10rpx;
							white-space: nowrap;
						}
					}

					.pic-content {
						width: 100%;

						.pic-items {
							margin-top: 30rpx;

							.pic {
								width: 146rpx;
								height: 146rpx;
								border-radius: 8rpx;
							}

							.price-info {
								width: 100%;
								margin-top: 15rpx;
								font-size: 24rpx;
								font-weight: 500;
								color: #FE3738;
							}
						}
					}
				}
			}

			.everysBuying-container {
				width: 100%;
				height: 414rpx;
				border-radius: 16rpx;
				background-color: #FFFFFF;
				margin-bottom: 20rpx;

				.box-bar-content {
					width: 100%;
					padding: 0 20rpx;

					.title-text {
						font-size: 32rpx;
						font-weight: 500;
						color: #333333;
						margin: 20rpx 0;
					}

					.tips-txt {
						height: 30rpx;
						background: linear-gradient(-90deg, #7619EC, #A429F3);
						border-radius: 15rpx 15rpx 15rpx 0px;
						font-size: 24rpx;
						font-weight: 500;
						color: #FFFFFF;
						margin-left: 20rpx;
						padding: 0 20rpx;
					}
				}

				.goodsScroll-container {
					width: 100%;
					height: 310rpx;
					margin-top: 20rpx;

					.scrollgoods-box {
						width: 100%;
						height: 100%;

						.scrollList-content {
							white-space: nowrap;
							padding-left: 8rpx;

							.goods-items {
								display: inline-block;
								width: 220rpx;
								height: 310rpx;
								border-radius: 8rpx;
								overflow: hidden;

								.items-container {
									width: 100%;
									height: 100%;

									.image-content {
										width: 166rpx;
										height: 166rpx;
										margin-top: 10rpx;
									}

									.goodsinfo-content {
										width: 100%;
										height: 120rpx;
										padding: 0 10rpx;

										.goodsName-box {
											width: 100%;
											line-height: 34rpx;
											white-space: nowrap;
											overflow: hidden;
											text-overflow: ellipsis;
											font-size: 24rpx;
											font-weight: 400;
											color: #444444;
											margin-top: 5rpx;
										}

										.coupons-container {
											width: 100%;
											margin-top: 10rpx;

											.couponbac-content {
												width: 160rpx;
												height: 30rpx;
												background: url(../static/images/goods/quanbg.png) no-repeat;
												background-size: 100% 100%;
												border-radius: 5rpx;

												.textsTip {
													font-size: 20rpx;
													font-weight: 400;
													color: #FFFFFF;
													margin-left: 10rpx;
													white-space: nowrap;
												}

												.coupons-value {
													font-size: 20rpx;
													font-weight: 500;
													color: #FF4242;
													white-space: nowrap;
													margin-left: 30rpx;
												}
											}
										}

										.price-info-container {
											width: 100%;
											margin-top: 10rpx;

											.nowPrice-content {
												.rmbicon {
													font-size: 24rpx;
													font-weight: 400;
													color: #FF4242;
													line-height: 34rpx;
												}

												.nowprice {
													font-size: 26rpx;
													font-weight: bold;
													color: #FF4242;
													line-height: 34rpx;
												}
											}

											.oldPrice-content {
												margin-left: 10rpx;

												.oldprice {
													text-decoration: line-through;
													line-height: 34rpx;
													font-size: 24rpx;
													font-weight: 500;
													color: #999999;
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}

			.goodsFalling-container {
				width: 100%;
				height: 505rpx;
				background: #FFFFFF;
				border-radius: 16rpx;
				margin-bottom: 20rpx;

				.box-bar-content {
					width: 100%;
					height: 110rpx;
					padding: 0 20rpx;

					.title-text {
						font-size: 32rpx;
						font-weight: 500;
						color: #333333;
					}

					.tips-txt {
						height: 30rpx;
						background: linear-gradient(-90deg, #7619EC, #A429F3);
						border-radius: 15rpx 15rpx 15rpx 0px;
						font-size: 24rpx;
						font-weight: 500;
						color: #FFFFFF;
						margin-left: 20rpx;
						padding: 0 20rpx;
					}
				}

				.goodsScroll-container {
					width: 100%;
					height: 395rpx;

					.scrollgoods-box {
						width: 100%;
						height: 100%;

						.scrollList-content {
							white-space: nowrap;
							padding-left: 8rpx;

							.goods-items {
								display: inline-block;
								width: 226rpx;
								height: 390rpx;
								border-radius: 8rpx;
								overflow: hidden;
								margin-right: 20rpx;

								.items-container {
									width: 100%;
									height: 100%;

									.image-content {
										width: 226rpx;
										height: 226rpx;
										position: relative;
										border-radius: 8rpx;
										overflow: hidden;

										.spec-box {
											width: 100%;
											height: 30rpx;
											background: linear-gradient(86deg, #FD8E0E, #FFBD0A);
											border-radius: 0px 0px 8rpx 8rpx;
											font-size: 22rpx;
											font-weight: 500;
											color: #FFFFFF;
											position: absolute;
											bottom: 0;
										}
									}

									.goodsinfo-content {
										width: 100%;
										height: 160rpx;
										padding: 0 10rpx;

										.goodsName-box {
											width: 100%;
											line-height: 34rpx;
											white-space: nowrap;
											overflow: hidden;
											text-overflow: ellipsis;
											font-size: 24rpx;
											font-weight: 400;
											color: #444444;
											margin-top: 5rpx;
										}

										.price-info-container {
											width: 100%;

											.nowPrice-content {
												.rmbicon {
													font-size: 24rpx;
													font-weight: 400;
													color: #FF4242;
													line-height: 34rpx;
												}

												.nowprice {
													font-size: 26rpx;
													font-weight: bold;
													color: #FF4242;
													line-height: 34rpx;
												}
											}

											.oldPrice-content {
												margin-left: 10rpx;

												.oldprice {
													text-decoration: line-through;
													line-height: 34rpx;
													font-size: 24rpx;
													font-weight: 500;
													color: #999999;
												}
											}
										}

										.saleNum-container {
											width: 100%;
											margin-top: 5rpx;

											.content-box {
												height: 30rpx;
												background: #FAE7AD;
												border-radius: 5rpx;
												overflow: hidden;

												.txt-tips {
													font-size: 24rpx;
													font-weight: 500;
													color: #613309;
													padding: 0 6rpx;
												}

												.salenum {
													height: 30rpx;
													background: linear-gradient(9deg, #F63F4E, #FC5F13);
													padding: 0 14rpx;
													font-size: 24rpx;
													font-weight: 500;
													color: #FFFFFF;
													border-radius: 5rpx;
												}
											}
										}

										.likeNum-container {
											width: 100%;
											font-size: 24rpx;
											font-weight: 500;
											color: #FE3738;
											margin-top: 5rpx;

											.txt {
												color: #333333;
											}
										}
									}
								}
							}
						}
					}
				}
			}

			.welfare-container {
				width: 100%;
				background: #FFFFFF;
				border-radius: 16rpx;
				margin-bottom: 20rpx;

				.titlebar-container {
					width: 100%;
					height: 110rpx;
					padding: 0 20rpx;

					.left-content {
						.titletext {
							font-size: 32rpx;
							font-weight: 500;
							color: #333333;
						}
					}

					.right-arrowContent {
						font-size: 24rpx;
						font-weight: 400;
						color: #999999;
					}
				}

				.goodsList-container {
					width: 100%;

					.goods-items-container {
						width: 100%;
						height: 260rpx;
						padding-left: 10rpx;
						padding-right: 35rpx;
						background: #FFFFFF;
						border-radius: 16rpx;
						margin-bottom: 20rpx;

						.left-imagecontent {
							width: 220rpx;
							height: 220rpx;
							border-radius: 8rpx;
							overflow: hidden;
						}

						.right-goodsinfo-container {
							margin-left: 20rpx;
							width: 420rpx;
							height: 220rpx;

							.top-content-box {
								width: 100%;

								.goodsnameinfo-content {
									width: 100%;
									margin-bottom: 12rpx;

									.typeIcon-content {
										width: 60rpx;
										height: 24rpx;
										margin-right: 5rpx;
										margin-top: 8rpx;
									}

									.tradename {
										width: 400rpx;
										overflow: hidden;
										text-overflow: ellipsis;
										white-space: nowrap;
										font-size: 28rpx;
										font-weight: 400;
										color: #333333;
									}
								}

								.desc-box {
									width: 100%;
									height: 60rpx;
									font-size: 24rpx;
									font-weight: 500;
									line-height: 30rpx;
									color: #999999;
									overflow: hidden;
									text-overflow: ellipsis;
									display: -webkit-box;
									-webkit-box-orient: vertical;
									-webkit-line-clamp: 2;
								}
							}

							.btm-content-box {
								width: 100%;

								.discounts-container {
									width: 100%;
									margin-bottom: 15rpx;

									.coupon-box {
										width: 102rpx;
										height: 30rpx;
										background: url(@/static/images/goods/couponbac.png)no-repeat;
										background-size: 100% 100%;
										font-size: 20rpx;
										font-weight: 500;
										color: #FF4242;
									}

									.back-box {
										height: 30rpx;
										padding: 0 10rpx;
										background: linear-gradient(-90deg, #7619EC, #A429F3);
										border-radius: 5rpx;
										margin-left: 8rpx;
										font-size: 20rpx;
										font-weight: 500;
										color: #FFFFFF;
										white-space: nowrap;
									}
								}

								.price-saleNums-container {
									width: 100%;

									.left-price-box {
										.nowpirce {
											.rmb {
												font-size: 24rpx;
												font-weight: 600;
												color: #FF4242;
												line-height: 30rpx;
											}

											.num {
												font-size: 30rpx;
												line-height: 34rpx;
												font-weight: bold;
												color: #FF4242;
											}
										}

										.original-price {
											font-size: 24rpx;
											font-weight: 400;
											color: #999999;
											margin-left: 15rpx;
											line-height: 30rpx;
										}
									}

									.saleNum-content {
										font-size: 24rpx;
										font-weight: 500;
										color: #999999;
									}
								}
							}
						}
					}
				}
			}

			.Tiktok-container {
				width: 100%;
				height: 525rpx;
				padding: 0 20rpx;
				background-color: #FFFFFF;

				.titlebar-container {
					width: 100%;
					height: 110rpx;

					.left-content {
						.titletext {
							font-size: 32rpx;
							font-weight: 500;
							color: #333333;
						}

						.bubble-box {
							width: 200rpx;
							height: 25rpx;
							margin-left: 20rpx;
							background: linear-gradient(-90deg, #7619EC, #A429F3);
							border-radius: 12rpx 12rpx 12rpx 0px;
							font-size: 20rpx;
							font-weight: 400;
							color: #FFFFFF;
						}
					}

					.right-arrowContent {
						font-size: 24rpx;
						font-weight: 400;
						color: #999999;
					}
				}

				.goodsTopList {
					width: 100%;
					height: 340rpx;

					.scrollgoods-box {
						width: 100%;
						height: 340rpx;

						.scrollList-content {
							height: 360rpx;
							white-space: nowrap;
							padding-left: 8rpx;

							.goods-items {
								width: 220rpx;
								height: 340rpx;
								border-radius: 8rpx;
								margin-right: 10rpx;
								overflow: hidden;
								background-color: #FFFFFF;
								display: inline-block;

								.items-container {
									width: 100%;
									height: 100%;

									.image-content {
										width: 220rpx;
										height: 220rpx;
										position: relative;

										.playback-volume {
											position: absolute;
											z-index: 1;
											top: 14rpx;
											left: 14rpx;
											background: rgba(0, 0, 0, 0.5);
											padding: 5rpx 15rpx;
											border-radius: 15rpx;
											font-size: 20rpx;
											font-weight: 500;
											color: #FFFFFF;

											span {
												font-size: 28rpx;
											}
										}

										.suspend {
											position: absolute;
											top: 90;
											left: 90;
											width: 40rpx;
											height: 40rpx;
										}
									}

									.goodsinfo-content {
										width: 100%;
										height: 120rpx;

										.goodsName-box {
											width: 100%;
											line-height: 34rpx;
											white-space: nowrap;
											overflow: hidden;
											text-overflow: ellipsis;
											font-size: 24rpx;
											font-weight: 400;
											color: #444444;
											margin-top: 5rpx;
										}

										.coupons-container {
											width: 100%;
											margin-top: 10rpx;

											.couponbac-content {
												width: 100rpx;
												height: 30rpx;
												background: url(../static/images/goods/couponbac.png)no-repeat;
												background-size: 100% 100%;

												.coupons-value {
													font-size: 20rpx;
													font-weight: 500;
													color: #FF4242;
													white-space: nowrap;
												}
											}
										}

										.price-info-container {
											width: 100%;

											.nowPrice-content {
												.rmbicon {
													line-height: 34rpx;
													font-size: 20rpx;
													font-weight: 400;
													color: #FF4242;
												}

												.nowprice {
													font-size: 28rpx;
													font-weight: 400;
													color: #FF4242;
												}
											}

											.oldPrice-content {
												margin-left: 10rpx;

												.oldprice {
													line-height: 34rpx;
													text-decoration: line-through;
													font-size: 20rpx;
													font-weight: 400;
													color: #999999;
												}
											}
										}
									}
								}
							}
						}
					}
				}

				.gomore-bar {
					width: 100%;
					font-size: 26rpx;
					font-weight: 500;
					color: #666666;
					margin-top: 30rpx;
				}
			}
		}

		.goods-bottom-List {
			width: 100%;

			.bottomTypebar-container {
				width: 100%;
				height: 115rpx;

				.typeList {
					width: 100%;
					height: 100%;

					.type-items-container {
						width: 150rpx;
						height: 100%;

						.mainTitle {
							font-size: 30rpx;
							font-weight: 500;
							color: #333333;
							margin-bottom: 5rpx;
						}

						.subtitle {
							width: 110rpx;
							height: 36rpx;
							background: transparent;
							border-radius: 18rpx;
							font-size: 24rpx;
							font-weight: 500;
							color: #666666;
						}
					}

					.type-container-active {
						.mainTitle {
							color: #FE3738;
						}

						.subtitle {
							background: #FE3738;
							color: #FFFFFF;
						}
					}
				}

				.imbibition {
					width: 100%;
					height: 115rpx;
					z-index: 600;
					position: fixed;
					background-color: #FFFFFF;
				}
			}


			.bottomGoods-list-container {
				width: 100%;
				padding: 0 20rpx;
				flex-wrap: wrap;

				.goods-items {
					margin-bottom: 20rpx;
				}
			}
		}
	}
</style>
