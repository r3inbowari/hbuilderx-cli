<template>
	<view>

		<view @touchstart="test.touchstart" @touchmove="test.touchmove" :data-state="canrefresh" :change:prop="test.end" :prop="propValue" @touchend="test.touchend"
		 id="refresh-container">

			<!-- 起始会隐藏在导航栏里 -->
			<view class="flex-row-center" :style="{height:heightRh,width: '750rpx',background:color}">
				<view>
					<view class="loading-img rowCenCen">
						<view class="imgbox defIcon">
							<image src="../static/images/home/loading.gif" mode="aspectFill"></image>
						</view>
					</view>
				</view>
			</view>
			<!-- 后续内容 -->
			<slot></slot>

		</view>
	</view>
</template>



<script>
	export default {
		name: "refresh",
		props: {
			heightRh: {
				type: String,
				default: "70rpx"
			},
			color:{
				type: String,
				default: "#ffffff"
			},
			canrefresh:{
				type: Number,
				default: 0
			},
		},
		created() {
			uni.$on('reMsg', (data) => {
				this.propValue = !this.propValue
			})
		},
		data() {
			return {
				refreshText: "下拉刷新",
				propValue: true,
			}
		},
		methods: {
			refresh(i) {
				if(i==0){
					this.refreshText="松开刷新"
				}else if(i==1){
					// 这里写刷新业务
					this.refreshText="正在刷新"
					this.$emit('down',1)
				}else if(i==2){
					this.refreshText="下拉刷新"
				}
			}
		}
	}
</script>

<script module="test" lang="wxs">
	var startY = 0
	var top = 0
	var code = 0
	var mit = 0

	function touchstart(event, ins) {
		code = event.currentTarget.dataset.state
		console.log(code);
		if (code == 0) {
			mit = 0
			ins.callMethod('refresh', 2);
			var touch = event.touches[0] || event.changedTouches[0]
			startY = touch.pageY
		}
	}

	function end(newValue, oldValue, ownerInstance, instance) {
			console.log(oldValue);
			console.log(newValue);
			ownerInstance.selectComponent('#refresh-container').setStyle({
				'transform': 'translateY(0)',
				'transition': 'ease 0.3s'
			})
			code = 0
	}

	function touchend(event, ins) {
		code = event.currentTarget.dataset.state
		if (code == 0) {
			if (top < 75) {
				ins.selectComponent('#refresh-container').setStyle({
					'transform': 'translateY(0)',
					'transition': 'ease 0.3s'
				})
			} else {
				top = 0
				ins.callMethod('refresh', 1);
				code = 1
				ins.selectComponent('#refresh-container').setStyle({
					'transform': 'translateY(75px)',
					'transition': 'ease 0.3s'
				})

			}
		}
	}

	function touchmove(event, ins) {
		code = event.currentTarget.dataset.state
		if (code == 0) {
			var touch = event.touches[0] || event.changedTouches[0]
			var pageY = touch.pageY
			var vew = ins.selectComponent('#refresh-container')
			var dataset = vew.getDataset();
			top = pageY - startY
			console.log(top)
			if (top > 75) {
				if (mit == 0) {
					ins.callMethod('refresh', 0);
				}
				mit = 1
				top = 75
			}
			vew.setStyle({
				'transform': 'translateY(' + (top) + 'px)'
			})
		} else {
			startY = pageY
		}
	}
	module.exports = {
		end: end,
		touchend: touchend,
		touchstart: touchstart,
		touchmove: touchmove
	}
</script>
<style>
	.flex-row-center {
		display: flex;
		flex-direction: row;
		justify-content: center;
		align-items: flex-end;
	}

	.loading-img {
		width: 100%;
		height: 150rpx;
	}

	.imgbox {
		width: 138rpx;
		height: 84rpx;
	}

	/* 转圈动画 */
	.turn-load {
		animation: turnmy 0.6s linear infinite;
	}

	@keyframes turnmy {
		from {
			transform: rotate(0deg);
		}

		to {
			transform: rotate(360deg);
		}
	}
</style>
