<template>
	<view class="empower-container colCen">
		<view class="applogo-title rowCenCen">
			<image class="applogo" :src="applogo" mode="aspectFill"></image>
			<image class="jiantou" src="../static/images/app/jiantou.png" mode="aspectFill"></image>
			<image class="applogo" src="../static/images/app/pdd.png" mode="aspectFill"></image>
		</view>
		
		<view class="txt-tit">
			申请拼多多授权
		</view>
		
		<view class="txt-desc">
			应拼多多官方要求，获取推广收益前需要先进行官方授权，授权后方可告知您此商品是否涉及比价
		</view>
		
		<view class="pink-txt">
			比价定义：您在拼多多APP/网站访问了该商品的详情，再通过本APP进行转链自购的行为
		</view>
		
		<view class="blod-txt">
			比价订单，自购无佣金
		</view>

		<view class="btn-container rowCenBet">
			<view class="close-btn rowCenCen" @click="close()">
				<view>关闭</view>
			</view>
			<view class="confirm-btn rowCenCen" @tap="confirm()">
				<view>前往拼多多授权</view>
			</view>
		</view>
	</view>
</template>

<script>
	import util from '../utils/utils.js'
	const plug = uni.requireNativePlugin('Html5app-Baichuan')
	export default {
		data() {
			return {
				applogo: ''
			}
		},
		created() {
			this.applogo = getApp().globalData.appinfo.logo
		},
		methods: {
			confirm() {
				this.$http.get('pddgoods/checkPddAuth').then(res=>{
					console.log(res);
					var pddurl = res.authInfo.schemaUrl
					var h5pddurl = res.authInfo.mobileUrl
					this.close()
					// #ifdef APP-PLUS
					if (plus.os.name == 'Android') {
						plus.runtime.openURL(pddurl, res => {
							console.log(res);
							uni.showModal({
								content: "本机未检测到拼多多客户端，是否打开浏览器访问？",
								success: res => {
									if (res.confirm) {
										plus.runtime.openURL(h5pddurl)
									}
								}
							})
						});
					} else {
						plus.runtime.launchApplication({
							action: "pinduoduo://com.xunmeng.pinduoduo/" + pddurl.replace(/https:\/\/.*\//, "")
						}, res => {
							uni.showModal({
								content: "本机未检测到拼多多客户端，是否打开浏览器访问？",
								success: res => {
									if (res.confirm) {
										plus.runtime.openURL(h5pddurl)
									}
								}
							})
						})
					}
					// #endif
				})  
			},
			close() {
				this.$emit('closemodel')
			}
		}
	}
</script>

<style lang="scss">
	.empower-container {
		width: 564rpx;
		height: 720rpx;
		background: #FFFFFF;
		border-radius: 32rpx;
		padding: 0 20rpx;

		.applogo-title {
			margin-top: 60rpx;

			.applogo {
				width: 92rpx;
				height: 92rpx;
				border-radius: 50%;
			}
			.jiantou{
				width: 56rpx;
				height: 30rpx;
				margin: 0 30rpx;
			}
		}

		.txt-tit {
			margin-top: 30rpx;
			font-size: 34rpx;
			font-weight: bold;
			color: #333333;
		}

		.txt-desc {
			margin-top: 30rpx;
			width: 100%;
			padding: 0 45rpx;
			font-size: 24rpx;
			font-weight: 500;
			line-height: 46rpx;
			color: #333333;
		}
		.pink-txt{
			width: 100%;
			padding: 0 45rpx;
			font-size: 24rpx;
			font-weight: 500;
			line-height: 46rpx;
			color: #FD002F;
		}
		
		.blod-txt{
			width: 100%;
			padding: 0 45rpx;
			font-size: 24rpx;
			font-weight: bold;
			line-height: 46rpx;
			color: #FD002F;
		}

		.btn-container {
			width: 100%;
			margin-top: 30rpx;
			font-size: 30rpx;
			font-weight: 500;
			color: #FFFFFF;

			.close-btn {
				width: 158rpx;
				height: 76rpx;
				background: #E5E5E5;
				box-shadow: 0px 5rpx 9rpx 0px rgba(229, 229, 229, 0.33);
				opacity: 0.97;
				border-radius: 38rpx;
			}

			.confirm-btn {
				width: 260rpx;
				height: 76rpx;
				background: #FD002F;
				box-shadow: 0px 5rpx 9rpx 0px rgba(253, 0, 47, 0.33);
				opacity: 0.97;
				border-radius: 38rpx;
			}
		}
	}
</style>
