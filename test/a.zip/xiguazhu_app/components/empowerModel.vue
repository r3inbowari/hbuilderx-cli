<template>
	<view class="empower-container colCen">
		<view class="applogo-title rowCenCen">
			<image class="applogo" :src="applogo" mode="aspectFill"></image>
			<image class="jiantou" src="../static/images/app/jiantou.png" mode="aspectFill"></image>
			<image class="applogo" src="../static/images/app/tb.png" mode="aspectFill"></image>
		</view>
		<view class="txt-tit">
			申请淘宝授权
		</view>
		<view class="txt-desc">
			应淘宝要求，获得返现前请先进行官方授权备案(淘宝账号一经绑定无法修改，请谨慎操作！如需更改，请联系客服！)
		</view>

		<view class="btn-container rowCenBet">
			<view class="close-btn rowCenCen" @click="close()">
				<view>关闭</view>
			</view>
			<view class="confirm-btn rowCenCen" @tap="confirm()">
				<view>前往淘宝授权</view>
			</view>
		</view>
	</view>
</template>

<script>
	import config from '../utils/config.js'
	import util from '../utils/utils.js'
	const plug = uni.requireNativePlugin('Html5app-Baichuan')
	export default {
		data() {
			return {
				applogo: ''
			}
		},
		created() {
			this.applogo = getApp().globalData.appinfo.logo
		},
		methods: {
			confirm() {
				plug.login({}, result => {
					console.log(result);
					var nick = result.userinfo.nick
					if (result.code == 0) {
						plug.taobaoOauth({
							"url": config.tbEmpower
						}, ret => {
							console.log(ret);
							if(ret.retcode==1){
								plug.logout({}, result => {
									console.log(result);
									this.$emit('closemodel')
								});
							}else{
								this.$http.post('member/savePublisher', {
									tbAccount: nick,
									accessToken: ret.access_token
								}, 'application/json').then(res => {
									this.$emit('updataInfo')
									this.$emit('closemodel')
									uni.navigateTo({
										url:'/pages/mine/setting/accountAuthorization?status=1'
									})
								}).catch(res=>{
									console.log(res);
									plug.logout({}, result => {
										console.log(result);
									});
									this.$emit('closemodel')
									uni.navigateTo({
										url:'/pages/mine/setting/accountAuthorization?status=0&res='+res
									})
								})
							}
						});
					}else{
						plug.logout({}, result => {
							console.log(result);
						});
					}
				});
			},
			close() {
				this.$emit('closemodel')
				plug.logout({}, result => {
					console.log(result);
				});
			}
		}
	}
</script>

<style lang="scss">
	.empower-container {
		width: 564rpx;
		height: 540rpx;
		background: #FFFFFF;
		border-radius: 24rpx;
		padding: 0 20rpx;

		.applogo-title {
			margin-top: 60rpx;

			.applogo {
				width: 92rpx;
				height: 92rpx;
				border-radius: 50%;
			}
			.jiantou{
				width: 56rpx;
				height: 30rpx;
				margin: 0 30rpx;
			}
		}

		.txt-tit {
			margin-top: 30rpx;
			font-size: 34rpx;
			font-weight: bold;
			color: #333333;
		}

		.txt-desc {
			margin-top: 30rpx;
			width: 100%;
			padding: 0 45rpx;
			font-size: 24rpx;
			font-weight: 500;
			line-height: 46rpx;
			color: #666666;
		}

		.btn-container {
			width: 100%;
			margin-top: 30rpx;
			font-size: 30rpx;
			font-weight: 500;
			color: #FFFFFF;

			.close-btn {
				width: 158rpx;
				height: 76rpx;
				background: #E5E5E5;
				box-shadow: 0px 5rpx 9rpx 0px rgba(229, 229, 229, 0.33);
				opacity: 0.97;
				border-radius: 38rpx;
			}

			.confirm-btn {
				width: 240rpx;
				height: 76rpx;
				background: #FD002F;
				box-shadow: 0px 5rpx 9rpx 0px rgba(253, 0, 47, 0.33);
				opacity: 0.97;
				border-radius: 38rpx;
			}
		}
	}
</style>
