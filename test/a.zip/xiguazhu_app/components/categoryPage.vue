<template>
	<scroll-view class="swiper-scroll" :scroll-y="true" :scroll-top='scrollindex' @scroll='pagescroll'
	 lower-threshold='500' @scrolltolower='scrollmorePage'>

		<refresh @down="end" :heightRh='(Topheight) + "px"' :canrefresh="canrefresh">
			<slot>
				<!-- 你的业务 -->
				<view class="category-page-wrapper colCen borderBox wrapperLayer">
					<view class="secondary-classification-container colCen">
						<view class="classificationList-container rowCen borderBox">
							<block v-for="(items,index) in classificationList" :key="index">
								<view class="classification-item colCen" @tap="goPath(items)">
									<view class="items-container colCen">
										<view class="defIcon classpic">
											<image :src="items.cpic" mode="aspectFill"></image>
										</view>
										<view class="className-box">
											<view>{{items.cname}}</view>
										</view>
									</view>
								</view>
							</block>
						</view>
					</view>


					<view class="bottomGoodslist-container colCen borderBox">
						<view class="hotgoods colCen borderBox">
							<view class="titlebar-container rowCenCen">
								<image class="titlepic" src="../static/images/home/titpic.png" mode="aspectFill"></image>
							</view>
							<view class="hot-goods-content rowCenBet">
								<view class="hotgoods-items colCen" v-for="(items,index) in hotList" :key='index' @click="goDetails(items)">
									<view class="image-container defIcon">
										<image style="border-radius: 8rpx;" :src="items.mainPic" mode=""></image>
									</view>
									<view class="goodsInfo colCen borderBox">
										<view class="goodsName-box">
											{{items.dtitle}}
										</view>
										<view class="goods-price rowCen">
											<view class="font rowCenCen">
												<view>券后价</view>
											</view>
											<view class="price">
												￥{{items.actualPrice}}
											</view>
										</view>
									</view>
								</view>
							</view>
						</view>
						<view class="sortbar-container rowCenBet borderBox">
							<block v-for="(items,index) in sortList" :key="index">
								<view class="sortItems-container rowCenCen" :class="sortCurrent==index?'sortItems-container-active':''" @click="selectSort(index)">
									<view class="sortname">
										{{items.sortname}}
									</view>
									<view class="defIcon directionbox" v-if="index==3">
										<image v-if="sortCurrent!=3 " src="https://cmsstatic.ffquan.cn//wap_new/search/images/sort.svg" mode=""></image>
										<block v-else>
											<image v-if="priceUp" src="https://cmsstatic.ffquan.cn//wap_new/search/images/asce.svg" mode=""></image>
											<image v-else src="https://cmsstatic.ffquan.cn//wap_new/search/images/desc.svg" mode=""></image>
										</block>
									</view>
								</view>
							</block>
						</view>

						<view class="colCen borderBox goodsList-container">
							<view class="listbox rowCenBet borderBox">
								<block v-for="(items,index) in goodsList" :key="index">
									<view class="goods-items" @click="goDetails(items)">
										<colGoods :items="items"></colGoods>
									</view>
								</block>
							</view>
							<aLoadMore status="loading" mode="loading3" :showTitle='true' color="#999999"></aLoadMore>
						</view>
					</view>
				</view>
			</slot>
		</refresh>
	</scroll-view>
</template>

<script>
	var top = 0
	import refresh from './refresh.vue'
	import colGoods from './colGoods.vue'
	export default {
		components: {
			colGoods,
			refresh
		},
		props: {
			Topheight: {
				type: Number,
				default: 90
			},
			parentId: [Number, String],
			canrefush: {
				type: Boolean,
				default: false
			}
		},
		data() {
			return {
				sortCurrent: 0,
				priceUp: false,
				classificationList: [],
				sortList: [{
						sortname: '人气',
						type: 'mood'
					},
					{
						sortname: '最新',
						type: 'newest'
					},
					{
						sortname: '销量',
						type: 'salesvolume'
					},
					{
						sortname: '价格',
						type: 'price'
					}
				],
				sortType: 0,
				goodsList: [],
				hotList: [],

				canloadmore: false,
				currentPage: 1,
				loadstatus: 'loading',

				scrollindex: 0,
				canrefresh: true,
				triggeredstate: true,
				canrefresh: 0,
			}
		},
		watch: {
			loaddata(nval, oval) {
				if (nval) {
					this.currentPage = 1
					this.canloadmore = false
					this.getcateList()
					this.getGoodsList();
				}
			},
			canrefush(){
				if(this.canrefush){
					this.canrefresh = 0
				}else{
					this.canrefresh = 1
				}
			}
		},
		created() {
			this.currentPage = 1
			this.canloadmore = false
			this.loadstatus = 'loading'
			this.getGoodsList()
			this.getcateList()
		},
		methods: {
			end(i) {
				// 这里写刷新业务
				this.getcateList();
				this.getGoodsList();
			},

			pagescroll(e) {
				if (e.detail.scrollTop < 1) {
					this.canrefresh = 0
				} else {
					if (this.canrefresh != 1) {
						this.canrefresh = 1
					}
				}
			},

			getGoodsList() {
				this.$http.post('tb/getGoodsList', {
					cids: this.parentId,
					pageId: 1,
					pageSize: 10,
					sort: this.sortType,
				}, 'application/json').then((res) => {
					uni.$emit("reMsg", -1)
					if (res.goodsList.length < 10) {
						this.loadstatus = 'nomore'
						this.canloadmore = false
					} else {
						this.loadstatus = 'loading'
						this.canloadmore = true
						this.currentPage++
					}
					setTimeout(() => {
						this.triggeredstate = false;
						this._freshing = false;
					}, 100)
					this.goodsList = res.goodsList;
					this.hotList = res.topGoodsList.slice(0, 3);

				}).catch(res=>{
					uni.$emit("reMsg", -1)
				})
			},


			scrollmorePage() {
				if(this.canloadmore){
					this.canloadmore = false
					console.log(1231321);
					this.$http.post('tb/getGoodsList', {
						cids: this.parentId,
						pageId: this.currentPage,
						pageSize: 10,
						sort: this.sortType,
					}, 'application/json').then((res) => {
						if (res.goodsList.length < 10) {
							this.loadstatus = 'nomore'
							this.canloadmore = false
						} else {
							this.loadstatus = 'loading'
							this.currentPage++
							this.canloadmore = true
						}
						if (this.currentPage > 1) {
							this.goodsList = this.goodsList.concat(res.goodsList)
						} else {
							this.goodsList = res.goodsList;
						}
					})
				}
			},


			getcateList() {
				this.$http.post('tb/getTopClass', {
					ctype: 1,
					parentId: this.parentId
				}, 'application/json').then((res) => {
					this.classificationList = res;
				})
			},

			selectSort(idx) {
				this.sortCurrent = idx
				this.currentPage = 1
				this.canloadmore = false
				if (idx != 3) {
					if (idx != this.sortType) {
						this.sortType = idx;
					}
				} else {
					this.priceUp = !this.priceUp;
					if (this.priceUp) {
						console.log('true');
						this.sortType = 6
					} else {
						this.sortType = 5
					}
				}
				this.$nextTick(() => {
					this.getGoodsList();
				})
			},

			goDetails(info) {
				info.searchSource = 1
				uni.navigateTo({
					url: '../goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(info))
				})
			},

			goPath(info) {
				uni.navigateTo({
					url: './categories?cid=' + info.cid + '&title=' + info.cname
				})
			}
		}
	}
</script>

<style lang="scss">
	.hidebox {
		height: 100vh;
		overflow: hidden;
	}

	.category-page-wrapper {
		width: 100%;

		.secondary-classification-container {
			width: 100%;
			background-color: #FFFFFF;

			.classificationList-container {
				flex-wrap: wrap;
				margin-top: 20rpx;
				padding: 0 5rpx;

				.classification-item {
					width: 185rpx;

					.items-container {
						margin-bottom: 40rpx;

						.classpic {
							width: 95rpx;
							height: 95rpx;
						}

						.className-box {
							font-size: 24rpx;
							font-weight: 400;
							color: #333333;
							margin-top: 15rpx;
						}
					}
				}
			}
		}

		.bottomGoodslist-container {
			width: 100%;

			.sortbar-container {
				width: 100%;
				height: 100rpx;
				background-color: #FFFFFF;
				padding: 0 50rpx;

				.sortItems-container {
					width: 90rpx;

					.sortname {
						font-size: 24rpx;
						font-weight: 400;
						color: #333333;
					}

					.directionbox {
						width: 25rpx;
						height: 35rpx;
						margin-left: 5rpx;
					}
				}

				.sortItems-container-active {
					.sortname {
						color: #FF4242;
					}
				}
			}

			.hotgoods {
				width: 100%;
				padding: 0 16rpx;
				background-color: #FFFFFF;

				.titlebar-container {
					width: 100%;

					.titlepic {
						width: 348rpx;
						height: 27rpx;
					}
				}

				.hot-goods-content {
					width: 100%;
					margin-top: 35rpx;
					padding-bottom: 20rpx;

					.hotgoods-items {
						width: 232rpx;

						.image-container {
							width: 232rpx;
							height: 232rpx;
							overflow: hidden;
							border-radius: 8rpx;
						}

						.goodsInfo {
							width: 100%;

							.goodsName-box {
								width: 232rpx;
								margin: 15rpx 0rpx;
								font-size: 28rpx;
								line-height: 34rpx;
								font-weight: 400;
								color: #333333;
								white-space: nowrap;
								overflow-x: hidden;
								text-overflow: ellipsis;
							}

							.goods-price {
								width: 100%;

								.font {
									width: 72rpx;
									height: 30rpx;
									background: linear-gradient(-90deg, #FF311C, #FF9102);
									border-radius: 5rpx;
									font-size: 20rpx;
									font-weight: 500;
									color: #FFFFFF;
								}

								.price {
									margin-left: 10rpx;
									font-size: 28rpx;
									font-weight: bold;
									color: #FF4242;
								}
							}
						}
					}
				}
			}

			.goodsList-container {
				width: 100%;

				.listbox {
					width: 100%;
					flex-wrap: wrap;
					margin-top: 20rpx;
					padding: 0 20rpx;

					.goods-items {
						margin-bottom: 20rpx;
					}
				}
			}
		}
	}
</style>
