import Vue from 'vue';
import App from './App';
import uView from "uview-ui";
import titleBar from './components/backTitlebar.vue';
import aLoadMore from "./components/a_loadMore.vue";
import request from './utils/http.js'

Vue.config.productionTip = false
Vue.prototype.$http = request

Vue.component('aLoadMore',aLoadMore)
Vue.component('titleBar', titleBar)
Vue.use(uView);

App.mpType = 'app'

const app = new Vue({
    ...App
})
app.$mount()
