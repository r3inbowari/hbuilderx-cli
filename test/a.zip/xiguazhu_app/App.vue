<script>
	import utils from './utils/utils.js'
	// #ifdef APP-PLUS
	import idfa from './utils/idfa.js'
	import APPUpdate from "@/utils/appUpdate.js";
	import getClipboard from '@/utils/getClipboard.js'
	// import drawtab from './utils/mineTab.js'
	// #endif
	export default {
		onLaunch: function() {
			// drawtab()
			// #ifdef APP-PLUS

			//推送开始
			var info = plus.push.getClientInfo()
			// 获取当前设备的客户端id,传给后台,实现指定用户
			info && uni.setStorageSync('clientInfo', info)
			// 使用5+App的方式进行监听消息推送
			//消息点击事件  
			//【APP在线】，收到透传消息通过，不会提醒至通知栏目，需要发送本地消息，再进行点击触发的点击事件。  
			//【APP离线】，收到离线透传消息，必须通过Java后台的Intent字符串携带payload，且符合格式才能触发click事件，格式不符合不会触发。  
			plus.push.addEventListener("click", function(msg) {
				console.log('click', JSON.stringify(msg))
				// IOS
				if (uni.getSystemInfoSync().platform == 'ios') {
					var payload;
					if (msg.type == "click") { //APP离线点击包含click属性，这时payload是JSON对象  
						payload = msg.payload;
					} else { //APP在线，收到消息不会包含type属性,这时的payload是JSON字符串，需要转为JSON对象  
						payload = JSON.parse(msg.payload);
					}
					if (payload != null || payload != undefined) {
						// var messageType = payload.messageType; 
						// onLaunch 生命周期里，页面跳转有问题,跳不过去
						// 应该是页面还没加载，加上定时后，就可以了；
						setTimeout(() => {
							uni.navigateTo({
								url: payload
							})
						}, 1000)
					}
				} else { // Android
					var payload = msg.payload;
					if (payload != null || payload != undefined) {
						// onLaunch 生命周期里，页面跳转有问题,跳不过去
						// 应该是页面还没加载，加上定时后，就可以了； 
						setTimeout(() => {
							uni.navigateTo({
								url: payload
							})
						}, 1000)
					}
				}
			}, false);
			//收到透传消息  
			//只有APP在线时，才会触发receive事件，透传消息不会触发系统消息,需要创建本地消息  
			plus.push.addEventListener("receive", function(msg) {
				//业务代码
				// IOS
				if (uni.getSystemInfoSync().platform == 'ios') {
					//【APP离线】收到消息，但没有提醒（发生在一次收到多个离线消息时，只有一个有提醒，但其他的没有提醒）  
					//【APP在线】收到消息，不会触发系统消息,需要创建本地消息，但不能重复创建。必须加msg.type验证去除死循环              
					if (msg.type == "receive") {
						//创建本地消息,发送的本地消息也会被receive方法接收到，但没有type属性，且aps是null  
						plus.push.createMessage(msg.content, JSON.stringify(msg), {
							title: messageTitle
						});
					}
				} else { // Android
					var payload = JSON.parse(msg.content);
					var messageTitle = payload.title;
					var messageContent = payload.content;
					plus.push.createMessage(messageContent, payload, {
						title: messageTitle
					})
				}

			}, false);
			//消息推送结束


			plus.push.addEventListener('click', res => {
				console.log(res);
			});
			if (plus.os.name == 'iOS') {
				if (plus.runtime.isApplicationExist({
						action: 'weixin://'
					}) && plus.runtime.isApplicationExist({
						action: 'taobao://'
					})) {
					this.globalData.ifwt = 0
				} else {
					this.globalData.ifwt = 1
				}
			}
			APPUpdate();
			// #endif
			console.log('App Launch')
			console.log('Nice to meet you ~_~')
			this.getAppInfo()
			uni.getSystemInfo({
				success: e => {
					// #ifdef APP-PLUS
					if (e.platform == 'android') {
						this.globalData.platform = 'android'
						this.globalData.systemLevel = e.system
						if (e.system < 10) {
							plus.device.getInfo({
								success: e => {
									console.log(e);
									//这里获取到imei 剩下的逻辑也写在这里面
									var a = e.imei.indexOf(",")
									if (a < 0) {
										this.globalData.equipmentNumber = e.imei
									} else {
										this.globalData.equipmentNumber = e.imei.substring(0,
											a);
									}
									//里面写接下来的逻辑
									console.log('imei=' + imei); //这里是能获取imei的
								}
							})
						} else {
							plus.device.getOAID({
								success: e => {
									console.log('getOAID success: ' + e.oaid);
									this.globalData.equipmentNumber = e.oaid;
								}
							});
						}

						


					} else {
						this.globalData.platform = 'ios';
						this.globalData.systemLevel = e.system;
						this.globalData.equipmentNumber = idfa.value()


						this.checkArguments();
						plus.globalEvent.addEventListener('newintent', (e) => {
							this.checkArguments();
						});
					};
					// #endif
				}
			})
		},
		globalData: {
			platform: '',
			systemLevel: '',
			equipmentNumber: '',
			userInfo: {},
			canlisten: true,
			isZhuanlian: true,
			ifwt: 0,
			appinfo: {},
			hasMode: true
		},
		onShow: function() {
			console.log('App Show')
			var routes = getCurrentPages();
			if (routes.length > 0) {
				var route = routes[routes.length - 1].route
			}
			// #ifdef APP-PLUS
			if (this.globalData.canlisten && route != 'pages/mine/tools/turnChain' && !this.globalData.hasMode) {
				console.log(123);
				getClipboard()
			}

			if (plus.os.name == "Android") {
				/**
				 * 点击通知栏跳转
				 */
				const main = plus.android.runtimeMainActivity();
				const Intent = plus.android.importClass("android.content.Intent");
				const intent = main.getIntent();
				let path = intent.getStringExtra("path"); // list 里面的 path
				//根据 path路径 进行跳转
				console.error(path);
				if (path === null) return;
				//使用 $nextTick 延时跳转，避免在 tabBar 页面出现 BUG
				this.$nextTick(function() {
					uni.navigateTo({
						url: path,
						success() {
							console.log('成功');
							//移除跳转路径，避免重复跳转
							intent.removeExtra("path");
						},
						fail() {
							console.log('失败');
						}
					});
				})
				/**
				 * 点击通知栏跳转 结束
				 */
			}

			// #endif
		},
		onHide: function() {
			console.log('App Hide')
		},
		methods: {
			getAppInfo() {
				this.$http.post('cpssystemConfig/getAPPInfo').then(res => {
					console.log(res);
					this.globalData.appinfo = res
					utils.setCache('appInfo', res)
				})
			},
			checkArguments() {
				console.log('Shortcut-plus.runtime.launcher: ' + plus.runtime.launcher);
				if (plus.runtime.launcher == 'shortcut') {
					try {
						var cmd = JSON.parse(plus.runtime.arguments);
						console.log('Shortcut-plus.runtime.arguments: ' + plus.runtime.arguments);
						var type = cmd && cmd.type;
						// 可以自行根据type 处理 你的业务逻辑  

						setTimeout(r => {
							switch (type) {
								case 'takeout':
									uni.navigateTo({
										url: '/pages/active/takeoutFood'
									});
									break;
							}
						}, 800);
					} catch (e) {
						console.log('Shortcut-exception: ' + e);
					}
				}
			},
		},
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	/* #ifndef APP-NVUE */
	@import url('./static/css/main.css');
	@import url('./colorui/main.css');
	@import url('./colorui/icon.css');
	@import "uview-ui/index.scss";

	page {
		color: #333333;
		font-size: 30rpx;
		font-family: PingFangSC-Regular, PingFang SC;
		font-weight: 500;
		background-color: #F6F6F6;
	}

	.height-box {
		height: 100rpx;
		height: calc(100rpx + constant(safe-area-inset-bottom));
		height: calc(100rpx + env(safe-area-inset-bottom));
	}

	/* #endif */
</style>
