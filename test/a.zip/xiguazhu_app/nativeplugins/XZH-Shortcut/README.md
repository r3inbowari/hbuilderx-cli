本插件是android原生插件，仅支持Android app版本的 uni-app 项目使用。

本插件最低支持 android 7.1

本插件适配性未确定，因为我只有一台手机，暂时已知通过机型小米6。

本插件的使用方法在插件包里的 index.vue、app.vue 有详细使用说明

关于原生插件使用方法 ：

[官方文档](https://uniapp.dcloud.io/api/extend/native-plugin)
