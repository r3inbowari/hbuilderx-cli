// // #ifdef APP-PLUS


const nativeView = new plus.nativeObj.View("mineTab", { //创建底部图标菜单
	tag: "rect",
	bottom: "0px",
	left: "80%",
	height: "50px",
	width: "20%",
});

nativeView.addEventListener("click", function(e) {
	var info = uni.getStorageSync('userInfo')
	console.log(info);
	if (info.memberId) {
		uni.switchTab({
			url: '/pages/mine/mine',
			complete: (res) => {
				console.log(res);
			}
		})
	} else {
		uni.navigateTo({
			url: '/pages/login/login',
			complete: (res) => {
				console.log(res);
			}
		})
	}
})

export default {
	nativeView
}

// // #endif
