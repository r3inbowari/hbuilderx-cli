import http from './http.js'
var common = {};
common.getCache = function(key) {
	return new Promise((succ, error) => {
		uni.getStorage({
			key: key,
			success: res => {
				succ(res.data)
			},
			fail: res => {
				console.log(res);
				error(res)
			}
		})
	})
}

common.getCacheSync = function(key) {
	try {
		const value = uni.getStorageSync(key);
		if (value) {
			return value
		}
	} catch (e) {
		return ''
	}
}

common.setCache = function(key, data) {
	return new Promise((succ, error) => {
		uni.setStorage({
			key: key,
			data: data,
			success: res => {
				succ(res.data)
			},
			fail: res => {
				console.log(res);
				error(res)
			}
		})
	})
}

common.goUrl = function(info,_this) {
	var userinfo = common.getCacheSync('userInfo')
	if (userinfo) {
		if (info.urlType == '0') {
			uni.navigateTo({
				url: '/pages/webView/webView?url=' + (info.url?info.url:info.murl)
			})
		} else if (info.urlType == 1) {
			uni.navigateTo({
				url: info.url?info.url:info.murl
			})
		} else if (info.urlType == '2') {
			let vm = _this
			const userData = uni.getStorageSync('userData')
			console.log(userData);
			if (userData.tbAccount) {
				http.post('tb/activityLink', {
					promotionSceneId: info.parameter
				}, 'application/json').then(res => {
					console.log(res);
					const plug = uni.requireNativePlugin('Html5app-Baichuan')
					plug.detailPage({
						url: res.clickUrl,
						"openType": 1
					}, result => {
						console.log(result);
					});
				})
			} else {
				uni.showModal({
					title: '提示',
					content: '您还没有绑定淘宝账号，是否去绑定？',
					success: (res)=> {
						console.log(this);
						if (res.confirm) {
							vm.empowerModel = true
						} else if (res.cancel) {
							console.log('用户点击取消');
						}
					}
				})
			}
		} else if (info.urlType == 3) {
			const data = {}
			data.goodsId = info.parameter
			data.searchSource = 3
			uni.navigateTo({
				url: '/pages/goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(data))
			})
		} else if (info.urlType == 4) {
			const data = {}
			data.goodsId = info.parameter
			data.searchSource = 2
			uni.navigateTo({
				url: '/pages/goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(data))
			})
		} else if (info.urlType == 5) {
			const data = {}
			data.goodsId = info.parameter
			data.searchSource = 4
			uni.navigateTo({
				url: '/pages/goods/goodsDetail?info=' + encodeURIComponent(JSON.stringify(data))
			})
		} else if (info.urlType == 6) {
			uni.navigateTo({
				url: '/pages/index/commonPage?interface=' + info.parameter + '&platform=1' + '&pageTitle=' +
					info.name + '&pic=' + info.pic
			})
		} else if (info.urlType == 7) {
			console.log(info.parameter);
			http.post('jd/getUnionurl', {
				goodsId: info.parameter,
			}, 'application/json', true).then(res => {
				console.log(res);
				var url = res.link
				// #ifdef APP-PLUS
				plus.runtime.openURL('openApp.jdMobile://virtual?params=' + encodeURIComponent(
					'{"des":"m","url":"' + res.link +
					'","category":"jump"}'), res => {
					console.log(res);
					uni.navigateTo({
						url: '../webView/webView?url=' + url
					})
				}, 'com.jingdong.app.mall');
				// #endif
			})
		} else if (info.urlType == 8) {
			uni.navigateTo({
				url: '/pages/goods/goodsDetail?id=' + info.parameter
			})
		}else if (info.urlType == 9) {
			let vm = _this
			const userInfo = uni.getStorageSync('userData')
			console.log(userInfo);
			if (userInfo.tbAccount) {
				if(info.url.indexOf("?") != -1){
					info.url = info.url + encodeURIComponent('&memberId='+userInfo.memberId + '&relationId='+userInfo.relationId+'&commonRelationId='+userInfo.commonRelationId+'&pid='+userInfo.pid)
					uni.navigateTo({
						url: '../webView/webView?url=' + info.url
					})
				}else{
					info.url = info.url + encodeURIComponent('?memberId='+userInfo.memberId + '&relationId='+userInfo.relationId+'&commonRelationId='+userInfo.commonRelationId+'&pid='+userInfo.pid)
					uni.navigateTo({
						url: '../webView/webView?url=' + info.url
					})
				}
			} else {
				uni.showModal({
					title: '提示',
					content: '您还没有绑定淘宝账号，是否去绑定？',
					success: (res)=> {
						console.log(this);
						if (res.confirm) {
							vm.empowerModel = true
						} else if (res.cancel) {
							console.log('用户点击取消');
						}
					}
				})
			}
		}else if(info.urlType==10){
			http.get('pddgoods/resourceUrlGen',{
				resourceType:info.parameter
			}).then(res=>{
				console.log(res);
				uni.navigateTo({
					url:'../webView/webView?url='+res.shortUrl
				})
			})
		}else if (info.urlType == 11 || info.urlType == 13) {
			http.post('mthomeMenu/zhuanlian', {
				activityType: info.activityType
			}).then(zhuanlianres => {
				console.log(zhuanlianres);
				if(info.urlType == 13){
					uni.navigateTo({
						url: '../webView/webView?url=' + zhuanlianres.murl
					})
				}else{
					
					var isAppletJump =  getApp().globalData.appinfo.isAppletJump;
					if(isAppletJump){
						plus.share.getServices(function(res) {
							var sweixin = null;
							for (var i = 0; i < res.length; i++) {
								var t = res[i];
								if (t.id == 'weixin') {
									sweixin = t;
								}
							}
							if (sweixin) {
								sweixin.launchMiniProgram({
									id: zhuanlianres.appid,
									type: 0, //0 正式 1 测试 2 体验  小程序的版本
									path: zhuanlianres.appPath //这里你要跳的路径，可以传值
								});
							}
						}, function(res) {
							console.log(JSON.stringify(res));
						}); 
						
					}else{
						
						if(zhuanlianres.deeplink){
							plus.runtime.openURL(zhuanlianres.deeplink, res => {
								uni.navigateTo({
									url: '../webView/webView?url=' + zhuanlianres.murl
								})
							});
						}else{
						uni.navigateTo({
							url: '../webView/webView?url=' + zhuanlianres.murl
						})
						}
					}
					
					
				
				
				}
			})
		}else if (info.urlType==12){
			plus.share.getServices(function(res) {
				var sweixin = null;
				for (var i = 0; i < res.length; i++) {
					var t = res[i];
					if (t.id == 'weixin') {
						sweixin = t;
					}
				}
				if (sweixin) {
					sweixin.launchMiniProgram({
						id: info.appid,
						type: 0, //0 正式 1 测试 2 体验  小程序的版本
						path: info.appPath //这里你要跳的路径，可以传值
					});
				}
			}, function(res) {
				console.log(JSON.stringify(res));
			});
		}
	} else {
		uni.navigateTo({
			url: '/pages/login/login'
		})
	}
}



export default common
