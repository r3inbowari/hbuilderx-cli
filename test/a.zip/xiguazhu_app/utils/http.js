import config from './config.js';
// const AgentDetection = uni.requireNativePlugin('Karma617-AgentDetection');

var requestheader;
var TOKEN;
var request = {}
var mobileInfo;
var appVersion;
// #ifdef APP-PLUS
mobileInfo = plus.os.name
appVersion = plus.runtime.version;
// #endif


request.post = function(url, data, requestheader, showlaoding, complete) {
	requestheader = requestheader || "application/x-www-form-urlencoded";
	console.log("POST-URL：" + url, data);
	if (showlaoding) {
		uni.showLoading({
			title: ''
		})
	}

	uni.getNetworkType({
		success: res => {
			console.log(res.networkType);
			if (res.networkType == 'none') {
				uni.navigateTo({
					url: '/pages/index/noNet'
				})
			}
		}
	})

	try {
		const value = uni.getStorageSync('userInfo');
		if (value.token) {
			TOKEN = value.token
		} else {
			TOKEN = ''
		}
	} catch (e) {
		TOKEN = ''
	}


	var startTime = new Date();
	return new Promise((succ, error) => {
		uni.request({
			url: config.httpUrl + url,
			data: data,
			method: "POST",
			header: {
				"content-type": requestheader,
				"token": TOKEN,
				"mobileInfo": mobileInfo,
				"appVersion": appVersion,
				"wt": getApp().globalData.ifwt
			},
			success: function(result) {
				if (typeof succ == "function") {
					// console.log(result.data);
					if (result.data.code == 0) {
						succ(result.data.data)
					} else if (result.data.code == 401) {
						uni.removeStorage({
							key: 'userInfo'
						})
						error(result.data.data)
						uni.navigateTo({
							url: '/pages/login/login'
						})
					} else {
						error(result.data.data)
						uni.showToast({
							title: result.data.message,
							icon: 'none',
							position: 'bottom',
							duration: 3000
						});
					}
				}
			},
			fail: function(e) {
				console.log(e);
				if (typeof error == "function") {
					error(e)
				}
			},
			complete: function(c) {
				uni.hideLoading()
				var endTime = new Date();
				// console.log('request time ' + new Date(endTime - startTime).getTime());
				if (typeof complete == "function") {
					complete(c);
				}
			}
		})
	})
}


request.get = function(url, data, showlaoding) {
	uni.getNetworkType({
		success: res => {
			console.log(res.networkType);
			if (res.networkType == 'none') {
				uni.navigateTo({
					url: '/pages/index/noNet'
				})
			}
		}
	})
	requestheader = requestheader || "application/x-www-form-urlencoded";
	if (showlaoding) {
		uni.showLoading({
			title: ''
		})
	}
	try {
		const value = uni.getStorageSync('userInfo');
		if (value.token) {
			TOKEN = value.token
		} else {
			TOKEN = ''
		}
	} catch (e) {
		TOKEN = ''
	}
	return new Promise((succ, error) => {
		uni.request({
			url: config.httpUrl + url,
			data: data,
			method: "GET",
			header: {
				"content-type": requestheader,
				"token": TOKEN,
				"mobileInfo": mobileInfo,
				"appVersion": appVersion,
				"wt": getApp().globalData.ifwt
			},
			success: function(result) {
				uni.hideLoading()
				if (typeof succ == "function") {
					// console.log(result.data);
					if (result.data.code == 0) {
						succ(result.data.data)
					} else if (result.data.code == 401) {
						uni.removeStorage({
							key: 'userInfo'
						})
						error(result.data.data)
						uni.navigateTo({
							url: '/pages/login/login'
						})
					} else {
						error(result.data.data)
						uni.showToast({
							title: result.data.message,
							icon: 'none',
							position: 'bottom',
							duration: 3000
						});
					}
				}
			},
			fail: function(e) {
				uni.hideLoading()
				if (typeof error == "function") {
					error(e)
				}
			},
		})
	})
}

request.upload = function(url, file, showlaoding) {
	requestheader = requestheader || "application/x-www-form-urlencoded";
	if (showlaoding) {
		uni.showLoading({
			title: ''
		})
	}
	try {
		const value = uni.getStorageSync('userInfo');
		if (value.token) {
			TOKEN = value.token
		} else {
			TOKEN = ''
		}
	} catch (e) {
		TOKEN = ''
	}
	return new Promise((succ, error) => {
		uni.uploadFile({
			url: config.httpUrl + url,
			filePath: file,
			name: 'file',
			formData: {
				'token': TOKEN
			},
			success: (uploadFileRes) => {
				uni.hideLoading()
				succ(JSON.parse(uploadFileRes.data))
			},
			fail: function(e) {
				uni.hideLoading()
				if (typeof error == "function") {
					error(e)
				}
			},
		});
	})
}

export default request
