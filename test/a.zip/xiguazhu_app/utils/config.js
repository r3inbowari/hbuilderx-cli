//const httpUrl = "https://hx.java3.cn/"; // 接口域名
 const httpUrl = "http://192.168.0.105:8096/"; // 接口域名
const salt = "jdy2020"; // 盐值
const tbEmpower = "https://oauth.taobao.com/authorize?response_type=token&client_id=29487613&state=1212&view=wap"//淘宝授权配置，client_id更换为自己的APPKEY
const shareHttp = "http://jdy.java3.cn:8080/" //分享及达人说接口地址
const shareKey = "huaxiang" //分享标识

export default {
	httpUrl:httpUrl,
	salt:salt,
	tbEmpower:tbEmpower,
	shareHttp:shareHttp,
	shareKey:shareKey
}
