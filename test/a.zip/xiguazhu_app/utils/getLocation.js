export default function getLocation(_this) {
	/**
	 *获取用户当前地理位置
	 */
	var vm = _this
	vm.locaStatus = '正在获取位置信息...'
	return new Promise((resolve, reject) => {
		var qqmapsdk;
		var me = this;
		uni.getLocation({
		    type: 'gcj02',
			geocode:true,
		    success: function (res) {
		        resolve(res)
		    },
			fail(err) {
				console.log(err);
				vm.locaStatus = '获取定位信息失败，请检查是否开启定位权限或当前GPS信号强度！'
				uni.showToast({
					title:'获取定位信息失败，请检查是否开启定位权限或当前GPS信号强度！',
					icon:'none'
				})
				reject(err)
			}
		});
	})
}